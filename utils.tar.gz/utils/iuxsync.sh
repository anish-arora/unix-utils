#!/usr/dt/bin/dtksh
# Author: Bolek Mynarski <bmynars@ncsus.jnj.com>
# Location: NCS Raritan, NJ USA
#
# $Revision: 1.11 $
# $Date: 2010/04/01 19:58:43 $
# $Header: /ncs/cvsroot/ncsbin/utils/iuxsync.sh,v 1.11 2010/04/01 19:58:43 bmynars Exp $
# $Id: iuxsync.sh,v 1.11 2010/04/01 19:58:43 bmynars Exp $
# $Locker:  $
# History: Check the bottom of the file for revision history
# ----------------------------------------------------------------------------

typeset -x PRGNAME=${0##*/}
typeset -x PRGDIR=${0%/*}
typeset -x PATH=$PATH:/usr/sbin:/sbin:/usr/bin

[[ $PRGDIR == . || $PRGDIR != /* ]] && PRGDIR=$(pwd)

# The purpose of this script is to syncronize central Ignite server repository
# with Ignite system dispersed around the Globe.  The idea is to have it
# automated as much as possible without having a manual intervention.

typeset -r miuxsrv=ncsiux02.na.jnj.com # Master Ignite server.  It's located in Raritan, NJ USA
typeset glb=/var/opt/ignite/depots/GLOBAL # Main location of global depots
typeset swlist=/usr/sbin/swlist
typeset swcopy=/usr/sbin/swcopy
typeset swremove=/usr/sbin/swremove
typeset host=$(hostname)

# There are two arrays set below:
#   1 - this array contains locations to various depots on $miuxsrv server
#   2 - this array contains product names associated with dep[@] arrays
# If modifications are done to either of the arrays, PLEASE, make sure they are
# in sync!  dep[0] will correspond to prd[0] and so on.

# Depot array
# ----------------------------------------------------------------------------

# If your local depot location is different from the master depot, add it to
# the right of the colon (:).  Make sure there are no extra spaces.
# Syntax:
#    Master Depot
#    : (seperator)
#    Local Depot
# If your local depot location is the same as Master depot, you do not
#  have to do anything.

dep[1]="$glb/NCS:"
dep[2]="$glb/CPR:"
dep[3]="$glb/Ignite-UX:"
dep[4]="$glb/OVO/11.00:"
dep[5]="$glb/OVO/11.11:"
dep[6]="$glb/OVO/11.23:"
dep[7]="$glb/SSH/11.00:"
dep[8]="$glb/SSH/11.11:"
dep[9]="$glb/SSH/11.23:"
dep[10]="$glb/software/vpars-IA-402:"
dep[11]="$glb/software/vpars302-parisc:"
dep[12]="$glb/java/ia"
dep[13]="$glb/java/pa"

# Product array
# -----------------------------------------------------------------------------

prd[1]="NCS_UTILS NCS_ACCT NCS_UVSCAN"
prd[2]=NCSSCPR
prd[3]="IGNITE Ignite-UX-11-11 Ignite-UX-11-23 Ignite-UX-11-31"
prd[4]=ITOAgent
prd[5]=${prd[4]}
prd[6]=${prd[4]}
prd[7]=T1471AA
prd[8]=${prd[7]}
prd[9]=${prd[7]}
prd[10]=T1335BC
prd[11]="T1335AC VPARMGR"
prd[12]="B9788AA B9789AA Java15JDK Java15JRE T1456AA T1457AA"
prd[13]="B9788AA B9789AA Java15JDK Java15JDKadd Java15JRE Java15JREadd Java15PTCH T1456AA T1456AAaddon T1457AA T1457AAaddon"

# -----------------------------------------------------------------------------
#                                   FUNCTIONS
# -----------------------------------------------------------------------------

function _check {
	typeset depot=$1
	typeset prod=$2
	typeset rec=version=""

	$swlist -s $depot $prod 2> /dev/null |\
	while read -A rec; do
		if [[ ${rec[1]} == $prod ]]; then
			version=${rec[2]}; break
		else
			continue
		fi
	done

	if [ -n "$version" ]; then
		print $version
	else
		set -A p $(echo $depot | tr '/' '\n')
		typeset i=${#p[@]} # Total number of elements in array p
		typeset prec="${p[(( $i - 2 ))]}/${p[(( $i - 1 ))]}" # Acquire last two elements
		print "${n}--$prec" # set in the 'Main Body section of this script.'
	fi

	unset prec i depot prod rec version
}

# Retreive product version from the remote server
function _rCheck {
	typeset depot=$1
	typeset prod=$2
	_check "$miuxsrv:$depot" "$prod"
}

# Retrieve product version from the local server
function _lCheck {
	typeset depot=$1
	typeset prod=$2
	_check "$depot" "$prod"
}

function _scopyArch {
	typeset dir="$1"
	typeset prod="$2"
	$swcopy -x mount_all_filesystems=false -s $dir $prod @ $dir/arch > /dev/null 2>&1
	return $?
}

function _srm {
	typeset dir="$1"
	typeset prod="$2"
	$swremove -x mount_all_filesystems=false -d $prod @ $dir > /dev/null 2>&1
	return $?
}

function _du {
	typeset rdepot="$1"
	typeset ldepot="$2"
	typeset prod="$3"
	typeset a b c j
	typeset -i rsize=lsize=0
	typeset -i total=used=avail=curusage=0
	typeset -i topLmt=95 # If current utilization is 95%, we will abort

	# Acquiring size of the remote depot.  We want to make sure that
	# we have enough space on the local system to copy a new version.
	# We will not allowed for coppying if after all is done there is less
	# than 5% space left on the local system.

	$swlist -a size -s $rdepot $prod |\
	while read a b c; do
		if [[ $b == $prod ]]; then
			rsize=$(( $c / 1024 )) # sizes are given in bytes.  We have to convert it to Kb
		fi
	done

	# Acquring space on the local system
	# ${sIze[3]} -> available space on the local file system

	bdf $ldepot |\
	while read -A sIze; do
		[[ ${sIze[0]} == Filesystem ]] && continue

		if (( ${#sIze[@]} == 6 )); then
				total=${sIze[1]}
				used=${sIze[2]}
				avail=${sIze[3]}
		elif (( ${#sIze[@]} == 5 )); then
				total=${sIze[0]}
				used=${sIze[1]}
				avail=${sIze[2]}
		else
			continue
		fi
	done

	# Adding check for correct value designation

	#for j in \$used \$total; do
	#	echo "        -- Evaluating $j: \c"
	#	typeset m=$(print eval $j); echo "$m"
	#	case $m in
	#		+([0-9]))
	#			if [[ $j == *used ]]; then
	#				: # That's OK.  We might have nothing used here
	#			else
	#				if [ $m -eq 0 ]; then
	#					_note "$PRGNAME ($LINEO): Error: did not obtain value for total bytes used"
	#					exit
	#				fi
	#			fi
	#	esac
	#done


	# Calculating current usage
	curusage=$(( $used * 100 / $total )) # Percent used currently

	if (( $curusage >= $topLmt )); then
		return 1
	fi

	# Calculating usage after updating local depots
	used=$(( $used + $rsize ))
	curusage=$(( $used * 100 / $total ))

	if (( $curusage >= $topLmt  )); then
		return 1
	fi
iuxsync.sh
	unset sIze
	return 0
}

function _mail {
	mailx -s "${PRGNAME}: $*" root < /dev/null
}

function _note {
	echo " ** $*"
}

# ------------------------------------------------------------------------------
#                                   MAIN BODY
# ------------------------------------------------------------------------------

typeset -i i
typeset n=NoDepot
#typeset -ft _du

for (( i = 0; i <= ${#dep[@]}; i++ )); do
	pkg=${prd[$i]}
	rdep=${dep[$i]%:*} # Extract remote depot path
	ldep=${dep[$i]#*:} # Extract local depot path

	[ -n "$ldep" ] || ldep="$rdep"

	for j in $pkg; do # to handle multiple products from the same depot
		rdepot=$(_rCheck "$rdep" "$j")
		ldepot=$(_lCheck "$ldep" "$j")

		if [[ $rdepot == ${n}--* || $ldepot == ${n}--* ]]; then
			case $n in
				${rdepot%--*}) msg="remote [${rdepot#*--}]" ;;
				${ldepot%--*}) msg="local [${ldepot#*--}]" ;;
				*) msg="unknown" ;;
			esac

			print
			_note "$PRGNAME ($LINENO): [$j] package or $msg depot not present"
			unset msg
			continue
		else
			print "\nMaster: $rdepot - Local: $ldepot"

			if [[ $rdepot == $ldepot ]]; then
				_note "$PRGNAME ($LINENO): [$j] is up-to-date."
			else
				_note "$PRGNAME ($LINENO): [$j] requires an update on $host"

				# We need to update current depot
				if [ ! -d "$ldep" ]; then
					_note "$PRGNAME ($LINENO) creating [$ldep/arch] on $host: \c"
					mkdir $ldep/arch && echo "[  OK  ]" || {
						echo "[FAILED]"
						print " +++ Could not create [$ldep/arch] on $host"
						print "     Exiting now."
						_mail "could not create [$ldep/arch] on $host"
						exit 1
					}
				fi

				# Before new copy of a package is copied, we will archive it
				# first
				_note "$PRGNAME ($LINENO): archiving [$j] depot package on $host: \c"
				_scopyArch "$ldep" "$j" && print "[  OK  ]" || {
					print "[FAILED]"
					print " +++ Could not archive [$j] on $host"
					print "     Exiting now."
					_mail "could not archive [$j] on $host"
					exit 1
				} # End of logical OR check for swcopy action.

				# Finally, we will remove old package to ensure clean slate
				_note "$PRGNAME ($LINENO): removing [$j] depot package on $host: \c"
				_srm "$ldep" "$j" && print "[  OK  ]" || {
					print "[FAILED]"
					print " +++ Could not remove [$j]."
					print "     Exiting now."
					_mail "could not remove [$j]"
					exit 1
				} # End of logical OR check for swremove action.

				# This is the heart of the script.  Now, we are synchronizing
				# local depot with current verison on the Master server

				# First, let's check to see we have enough space
				_du "$miuxsrv:$rdep" "$ldep" "$j" || {
					print " +++ $PRGNAME ($LINENO): not enough room on $host to update [$ldep].  Skipping.."
					_mail "not enough room on $host to update [$ldep]"
					continue
				} # End of logical OR for disk space usage.

				_note "$PRGNAME ($LINENO): acquiring master copy of [$j] depot package from $miuxsrv:"
				$swcopy -x enforce_dependencies=false -x mount_all_filesystems=false -s \
				$miuxsrv:$rdep $j @ $ldep

			fi # Is local depot the same as remote?
		fi # Depot check condition
	done # This is a product loop
done # This is a depot loop.

# ----------------------------------------------------------------------------
# $Log: iuxsync.sh,v $
# Revision 1.11  2010/04/01 19:58:43  bmynars
# Removed tracing
#
# Revision 1.10  2010/03/23 19:25:21  bmynars
# Added NCS_UVSCAN to iuxsync.sh script
#
# Revision 1.9  2007/08/27 14:06:15  bmynars
# Fixed the issue of logical volume name wrapping around
#
# Revision 1.8  2007/08/23 01:34:36  bmynars
# Added Java Depots to the list
#
# Revision 1.7  2006/12/20 03:05:46  bmynars
# Added _mail function to send appropriate notification to
# system admins in case of errors while running iuxsync.sh.
#
# Revision 1.6  2006/12/17 03:36:21  bmynars
# Address a potential issue of a split 'bdf' line if a long
# file system is present.  Now, our check will properly handle it as well.
#
# Revision 1.5  2006/12/16 22:11:46  bmynars
# Final version of the script.  At its completion, following is done:
#   - compare master and local depots
#   - see if there are differences in release numbers between them both
#   - rotate local depots creating their corresponding archives
#   - check for available space on the local depot before pulling new version
#     from master
#
# Revision 1.4  2006/12/16 04:09:09  bmynars
# Second commit of a working version.  Improved commenting.
#
# Revision 1.3  2006/12/16 03:23:34  bmynars
# This is first working copy of a script that actually rotates packages and
# updates local depots with master server versions.
#
# Revision 1.2  2006/12/15 03:38:36  bmynars
# This is a second check in.  This version is already a working copy
# that can be fully used in comparison of master and local repositories
# on Ignite server.  Next step is to create a routine that will auto-
# matically update local version of a product if needed.
#
# Revision 1.1  2006/12/14 18:41:17  bmynars
# Initial commit
#
# $RCSfile: iuxsync.sh,v $
# $Source: /ncs/cvsroot/ncsbin/utils/iuxsync.sh,v $
# $State: Exp $
# ----------------------------------------------------------------------------
