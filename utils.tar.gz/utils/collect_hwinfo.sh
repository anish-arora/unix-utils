#!/bin/sh
# Author: Bolek Mynarski <bmynars@ncsus.jnj.com>
#
# $Revision: 1.1 $
# $Date: 2006/04/25 15:30:14 $
# $Header: /ncs/cvsroot/ncsbin/utils/collect_hwinfo.sh,v 1.1 2006/04/25 15:30:14 bmynars Stab $ 
# $Id: collect_hwinfo.sh,v 1.1 2006/04/25 15:30:14 bmynars Stab $
# $Locker:  $
# History: Check the bottom of the file for revision history
# ----------------------------------------------------------------------------

typeset -x PRGNAME=${0##*/}
typeset -x PRGDIR=${0%/*}
typeset -x PATH=$PATH:/usr/sbin:/sbin

# ------------------------------------------------------------------------------
#                                   MAIN BODY
# ------------------------------------------------------------------------------

echo "map; wait; selall; wait; info; wait; infolog; view; done" | cstm

# ----------------------------------------------------------------------------
# $Log: collect_hwinfo.sh,v $
# Revision 1.1  2006/04/25 15:30:14  bmynars
# Initial Commit
#
# $RCSfile: collect_hwinfo.sh,v $
# $Source: /ncs/cvsroot/ncsbin/utils/collect_hwinfo.sh,v $
# $State: Stab $
# ----------------------------------------------------------------------------
