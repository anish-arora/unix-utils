#!/bin/sh

revision="@(#) Type H 04/13/06"   # April 13, 2006

#####################################################################
#
# The purpose of this script is to collect various pieces of 
# information from a system.
# 
# Under normal circumstances are no options required, however
# the script can also be used to collect data from a system with defects..
#
# In those situations can the following options be used:
#
# -cron		Don't send any output ( to a terminal ), as it might not be 
#		there, like being run from cron
#
# -large  	Temporary files are normally created under /tmp.
#               The available space is reported.
#		This might not be enough for large files in /var/adm/syslog.
# 		With this option is the largest available location on the
#		system used.
#
# -no_hw	running 'dd' and lvlnboot on a missing disk might 'hang'
#               this option prevents these commands.
#               The option will be set when ioscan reports NO-HW
#
# -no_SC	Service Guard-clusters with Business Copies may give lots
#               of warnings without the requested Node_Timeout
#
#               Only when the Node_Timeout-value is fine AND at your
#               own risk might this option be used !!
#
# -ps:  	preprocess syslog
#
#
#
#
#####################################################################
#
#/var/stm/config/sys directory for HealthCheck.cfg (contains customer info)
#
# if output needs to go to another directory, change the next line!
outputdir=/var/stm/logs		# directory where gz files will be saved
#
# use mailx to send mail

cron=0
large=0
typeset -i day
typeset -i month
typeset -i year
typeset -i first

#*** ADDED for HAO purpose ***
psopt=0
no_hw=0
no_SC=0
PREPSYSL=`dirname $0`/duplilog

# process commandline arguments
while [ "$1" != "" ]
do
  case $1 in
    -cron)  cron=1
            shift;;
    -ps)    if [ ! -x $PREPSYSL ]
            then
              echo "$PREPSYSL not found or not executable"
              exit 1
            fi
            psopt=1
            shift;;
    -large) large=1
            shift;;
    -no_hw) no_hw=1
            shift;;
    -no_SC) no_SC=1
            shift;;
    # other options
    *)      printf "Usage: $0 [-cron] [-ps] [-large] [-no_hw] [-no_SC]"
    exit 1
  esac
done
#*** END ADD ***

workingdir=`pwd`
if [ $workingdir = '/.root' ]
then
  cron=1
  workingdir=$outputdir
else			# not on cron
  if [ $# -eq 1 ]	# used to run from cron
  then
    if [ $1 = "cron" ]	# Not on cron, but will run without questions!
    then
      cron=1
    else
      echo Only cron parameter is supported!
      exit
    fi
  fi
fi
creationDate=`date "+_%y%m%d_%H%M"`
proc_error=0
mesa=0
mesaVersion="Unknown"
eod='************ eod ***************'
np='Not present'
NAME=$workingdir/`uname -n`$creationDate
if [ cron -eq 1 ]
then
  if [ -d /var/stm/logs ]
  then
    exec 1>$NAME.out    # redirect all output
    exec 2>$NAME.err    # redirect all errors
  else
    echo Running on cron but output directory /var/stm/logs not present!
    exit
  fi
fi
#
##############################################################
# Files.                                                     #
#                                                            #
# This script creats a number of files, all in $TEMPDIR.     #
#                                                            #
# In case of an error or hang occurs is their contents       #
# required in finding it's cause.                            #
#                                                            #
# Name                        Purpose                        #

  CONFIG=/var/stm/config/sys/HealthCheck.cfg
  file_length=`cat $CONFIG 2>/dev/null | wc -l `

# when the script ran fine is the length of the $CONFIG-file 7 lines
# when the script is aborted is it's length 8 lines
# the name of the temporary-directory is in the 8th line.

  if [ $file_length -gt 7 ] 
  then
    aborted=1
    TEMPDIR=`cat - << EOF | ed -s $CONFIG
    8
    q
    EOF`
  
    echo "\nThis script has been aborted during the last run"
    echo "Will combine all previous collected data from $TEMPDIR\n"

    ll $TEMPDIR
  else
    aborted=0
  fi

  if [ aborted -eq 0 ]
  then
    if [ large -eq 0 ]
    then 
      TEMPDIR=`mktemp -d /tmp`   # name of temporary directory
      if [ -d $TEMPDIR ]
      then
        rm -r $TEMPDIR
      fi
      mkdir $TEMPDIR
       TMP0=$TEMPDIR/tmp_0       # temporary/scratch file
      echo `bdf |grep tmp`"\n"                          > $TMP0
    else
      TMP0=`mktemp -d /tmp`
      bdf -l | grep -v -i "filesystem" | sort -r -k 4,4 > $TMP0
  
      # retrieve the name of the mointpoint with the largest
      # available space
  
      TMPLOC=`awk '
             { first_line=first_line+1
               if ( first_line == 1 ) { print $6 }
             }' $TMP0`
      TEMPDIR=`mktemp -d $TMPLOC`
      if [ -d $TEMPDIR ]
      then
        rm -r $TEMPDIR
      fi
      mkdir $TEMPDIR
    fi
  fi

  TMPNAME=$TEMPDIR/`uname -n`$creationDate".txt"
      AR1=/opt/hparray/bin
      VA1=/etc/opt/sanmgr/commandview/server/config
      VA2=/opt/sanmgr/hostagent/sbin
      VA3=/opt/sanmgr/hostagent/config
      VA4=/opt/sanmgr/commandview/client/sbin
      VA5=/opt/sanmgr/commandview/client/sbin/logprn
      VA6=/var/opt/sanmgr/commandview/server/data
      VA7=/etc/opt/sanmgr/hostagent/config/
    ARDSP=$TEMPDIR/ardsp       # autoraid-information
 BADBLOCK=$TEMPDIR/badblock    # badblock-information
     RTBT=$TEMPDIR/boot_root   # combined root boot etc info
   CASDSP=$TEMPDIR/casdsp      # Casini-information
 CM_ERROR=$TEMPDIR/cm_err      # std.error of cmgetconf
     DISK=$TEMPDIR/disk        # disk-information
CHECK_LAN=$TEMPDIR/check_lan   # script to check for hanging lanadmin-process
    DMESG=$TEMPDIR/dmesg       # output of the dmesg-command
      EMS=$TEMPDIR/ems         # output of the ems messages
 EMS_INFO=$TEMPDIR/ems_info    # output of the ems status
    ERROR=$TEMPDIR/error       # error-output of various commands
      EVA=$TEMPDIR/eva         # output of securepath EVA.
     FC60=$TEMPDIR/fc60_info   # fc60-information
       FS=$TEMPDIR/fs          # general file-system information
      GSP=$TEMPDIR/gsp         # get ccerrlog and ccbootlog
   IOSCAN=$TEMPDIR/ioscan      # output of ioscan
     PSEF=$TEMPDIR/psef        # output of ps -ef
    FIBRE=$TEMPDIR/fibre       # fibre-channel-information
   KERNEL=$TEMPDIR/kernel      # kernel information
      LAN=$TEMPDIR/lan         # lanscan and lanadmin info
      LIF=$TEMPDIR/lif         # lif-information from the disks
      LVM=$TEMPDIR/lvm         # lvm-information
     LVLN=$TEMPDIR/lvlnboot    # lvlnboot-information
     LVOL=$TEMPDIR/lvol        # lvol-information
     MESA=$TEMPDIR/mesa        # output of cstm
    NO_HW=$TEMPDIR/no_hw       # file with missing disks
    PARTS=$TEMPDIR/parts       # selected parts of ioscan
PARTS_ERR=$TEMPDIR/parts_err   # selected parts of ioscan with errors
 PROGRESS=$TEMPDIR/progress    # file with the running function
   PVDISP=$TEMPDIR/pvdisp      # pvdisplay-output
 RED_CCER=$TEMPDIR/reduce_cc   # c-program to reduce the ccerrlog-file
       SG=$TEMPDIR/sg_info     # node-timeout value of SG-cluster
  SWLIST1=$TEMPDIR/swlist.prod # output of swlist -l product
  SWLIST2=$TEMPDIR/swlist.file # output of swlist -l fileset -a state
   SYSTEM=$TEMPDIR/system      # general system information
   SYSLOG=$TEMPDIR/syslog      # copy of /var/adm/syslog/syslog.log
   XPINFO=$TEMPDIR/xpinfo      # xpinfo -ld output
TOMBSTONE=$TEMPDIR/tombstone   # Last ts99 Tombstone info
   VAINFO=$TEMPDIR/vainfo      # config and parameters for VA arrays
   VADISK=$TEMPDIR/vadisk      # disk details VA disk arrays
   ARDISK=$TEMPDIR/ardisk      # disk details AR disk arrays
   VXLIST=$TEMPDIR/vxlist      # vxdisk list output
  RAID4SI=$TEMPDIR/raid4si     # raid4si card output
      SAN=$TEMPDIR/san         # San related parms
     TMP1=$TEMPDIR/tmp_1       # temporary/scratch file
     TMP2=$TEMPDIR/tmp_2       # temporary/scratch file
     TMP3=$TEMPDIR/tmp_3       # temporary/scratch file
      EOK="\r                                                  OK"
  
#
########################################################
# Note: the text '"$DD"' replaces the variable $DD     #
# in the awk-script                                    #
########################################################

########################################################
# General routines                                     #
########################################################

set_date_minus3()
{ day=`date "+%d"`
  month=`date "+%m"`
  year=`date "+%y"`
  if [ $day -gt 3 ]; then let day=day-3
  else
    let day=day+27
    if [ $month -eq 3 ];then let day=day-2; fi
    if [ $month -gt 1 ];then let month=month-1
      else
        let month=12; let year=year-1; fi
  fi
}
empty_file()
{
# make sure the intended file is empty
  if [ -f $1 ]
  then
    rm $1
  fi
  touch $1
}

check_sum()
{ CKSUM="83061107002519"
  cksum=`cat $0|wc -c``cat $0|wc -w``cat $0|wc -l`
  if [ "$cksum" != "$CKSUM" ]
  then
    echo file has changed, checksum is "$cksum" but should be "$CKSUM".
    exit
  fi
}

check_root()
{
#*** You must be superuser to run this script ***
  if [ `/usr/bin/id -u` != 0 ]; then
    set_output_redirection
    echo "You must be superuser to run this script"
    exit_cron_with_mail
    exit
  fi
}

set_output_redirection()
{ if [ cron -eq 1 ]
  then
    exec 1>$NAME.err    # redirect all output to stderr
  fi
}

exit_cron_with_mail()
{
   if [ cron -eq 1 ]
   then
     # send mail to user telling error exist
     exit
   fi
}
#
check_SC()
{ 
  #*** Check if this is a serviceguard cluster     ***
  #*** If so NODE_TIMEOUT should be > 4999999 msec ***
  #*** Some older PDC versions block the CPU for   ***
  #*** periods up-to 4 seconds, package switch can ***
  #*** occure if CPU block > NODE_TIMEOUT value!   ***
  #
  echo "***  progress information    ***"			>  $PROGRESS
  echo "`date +%y%m%d_%H%M`: check_SC"				>> $PROGRESS
  echo "\n***      SG information      ***"			>  $SG
  if [ `cat $PSEF |grep -v grep|grep /usr/lbin/cmcld | wc -l` -eq 1 ]
  then
    echo "This is a active Serviceguard cluster"                >> $SG
    echo "\nThis is a active Serviceguard cluster, checking NODE_TIMEOUT!"
    echo "Checking this using cmgetconf can take up to 10 minutes!"
    echo "If cmgetconf hangs or does not find the NODE_TIMEOUT, then run"
    echo "cmgetconf and check if serious errors are displayed!"
    echo "As workaround use the no_SC option except if this is a Kclass"
    echo "running PDC older then 39.12 (S/N A3284A-12)!"
    if [ ! -f "/usr/sbin/cmgetconf" ]
    then
      set_output_redirection
      echo "\n/usr/sbin/cmgetconf not found on this system, may need update!"
      echo "Update the serviceguardcluster software possibly required!"
      echo "Call your nearest HP support center for advise!"
        exit_cron_with_mail
      exit
    fi
    /usr/sbin/cmgetconf 2> $CM_ERROR | grep -v '# ' | grep NODE_TIMEOUT > $TMP0
    if [ -s $CM_ERROR ]
    then
      echo "cmgetconf reported an error" 	                >> $SG
      # The command failed, this is quite common for systems that use
      # Business Copies.
      # Look for the ascii-file, assuming that it is properly applied.
      # The output form cmgetconf should be empty, check it.
      if [ ! -s $TMP0 ]
      then
	echo "\nNo data from cmgetconf, looking for existing ascii-file(s)"
        find /etc -local -print | grep ".ascii" > $TMP1
        if [ `cat $TMP1 | wc -l` -eq 1 ]
        then
          # Only 1 file found, retrieve the value from the XXX.ascii-file
          echo "retrieving NODE_TIMEOUT from `cat $TMP1`"       >> $SG
          echo "retrieving NODE_TIMEOUT from `cat $TMP1`"
          grep NODE_TIMEOUT `cat $TMP1` | grep -v '#' >$TMP0
        else
          echo "No or too many files XXX.ascii found, cannot continue..."
          echo "No or too many files XXX.ascii found, cannot continue..." >> $SG
          empty_file $TMP0
        fi
      else
        echo "\n$TMP0 is NOT empty. Cannot continue, strange.."
      fi
    else
      echo "cmgetconf reported the NODE_TIMEOUT"               >> $SG
    fi
    if [ `cat $TMP0|wc -w` -eq 0 ]   # For some reason no NODE_TIMEOUT found
    then
      set_output_redirection
      echo "\nNODE_TIMEOUT variable not displayed during /usr/sbin/cmgetconf!"
      echo "Possible a Serviceguard error situation!"
      echo "Run /usr/sbin/cmgetconf which will display the error!"
      echo "If help is needed, contact the nearest HP response center!\n" 
        exit_cron_with_mail
      exit
    fi
    echo "file not empty" > $TMP1
    awk -v sg=$SG ' /NODE_TIMEOUT/ {
        if ($1 == "NODE_TIMEOUT")
        { printf "Current SC Timeout value is "$2" Microseconds" >> sg
          if ($2 < 5000000)
          { printf "\nCurrent SC Timeout value is "$2" Microseconds\n"
            printf "If this is a Kclass with PDC < 39.12 then update PDC!"
            printf "\nCould cause package switch on K series with PDC < 39.12\n"
            printf "See service note A3284A-12!\n\n"
            system("echo "" > '"$TMP1"' ")       # test later if file empty
          }
          else 
            printf "Current SC Timeout value is "$2" Microseconds\n\n"
        }
    }' $TMP0
    if [ `cat $TMP1|wc -w` -eq 0 ]             # we cleared the file so stop?
    then
      if [ cron -eq 1 ]	# Stop if processing from cron
      then
        set_output_redirection
        echo Problems found while retrieving SG cluster node timeout!
        exit_cron_with_mail
      fi
      echo "Do you wish to continue y/n? : \c"
      read tmp
      if [ "$tmp" = "n" -o "$tmp" = "N" ]
      then
        exit
      fi
    fi
  else
    echo "This is NOT an active Serviceguard cluster"           >> $SG
  fi
  echo "\n$eod"							>> $SG
}


#
check_tmp()
{
  #*** All files will be created in the directory named $TEMPDIR ***
  if [ -d /tmp ]
  then 
    clear
    echo "                   ********************************"
    echo "                   *** Script to check firmware ***"
    echo "                   *** PDC etc.                 ***"
    echo "                   ***" $revision          "    ***"
    echo "                   ********************************"

    echo "\n     Files will be created in : $TEMPDIR"
    echo "     Available space          : \c"
          awk '{ first_line=first_line+1
                 if ( first_line == 1 ) { print $4 " Kb"}
               }' $TMP0
    echo "     Logical volume           : \c"
          awk '{ first_line=first_line+1
                 if ( first_line == 1 ) { print $1 }
               }' $TMP0
  else
    set_output_redirection
    echo "/tmp directory does not exists, create it first!"
      exit_cron_with_mail
    exit
  fi
}

#
########################################################################
# A collection of functions for MESA, also called STM, or Diagnostics  #
########################################################################

check_mesa()
{
  echo "`date +%y%m%d_%H%M`: check_mesa"			>> $PROGRESS
  if [ -f /usr/sbin/cstm ]
  then
    mesa=1	# Mesa present
  else
    mesa=0      # Mesa not present
    set_output_redirection
    echo "Mesa/STM diagnostic not present on the system,"
    echo "this script will give little output!"
      exit_cron_with_mail
    echo "Do you wish to continue y/n? : \c"
    read tmp
    if [ "$tmp" = "n" -o "$tmp" = "N" ]
    then
      exit
    fi
    echo "\n***     mesa information     ***"			>  $MESA
    echo "** mesa not present on system **"			>> $MESA
    echo "$eod"							>> $MESA
  fi
}

#
retrieve_mesa_info()
{ 
  echo "`date +%y%m%d_%H%M`: retrieve_mesa_info"		>> $PROGRESS
  #*** mesa exists, we can use it to retrieve PDC etc ***
  echo "\nWhen cstm hangs , stop the script using control c then do:"
  echo "cstm then map and find the device that has Information Running!"
  echo "Then do select path xx, where xx is the path of device in run state"
  echo "Then do info, infolog and ial, send this info to HP!"
  echo "Workaround is reboot or remove wait command in script!"
  echo "Mesa/cstm is retrieving detailed info             \c"
  echo "vers" | cstm |grep 'Version ' > $TMP0
  set `cat $TMP0`
  if [ $1 = "Version" ]
  then
    mesaVersion="$2"
  fi
  echo "\n***     mesa information     ***"			>  $MESA
  echo "sel all
        info;wait
        infolog" | /usr/sbin/cstm				>> $MESA
  if [ `cat $MESA | wc -l` -lt 150 ]
  then
    echo "Mesa/STM exists, but very little information."
    echo "Might be caused by a very old release!"
    echo "Better re-install mesa and run this script again!"
  fi
  echo "$eod"							>> $MESA
  set `ls -ld $MESA| sed 's/-/x/'`
  mesaSize=$5
  if [ mesaSize -lt 1500 ]
  then
    set_output_redirection
    printf "\nMesa diagnostic output is only $mesaSize bytes.\n"
    printf "Without diagnostic output the script output is not so useful!\n"
    printf "Maybe Mesa was not yet started, please retry later again!\n"
     exit_cron_with_mail
    echo "\nDo you wish to continue y/n? : \c"
    read answer
    if [ "$answer" = "n" -o "$answer" = "N" ]
    then
      exit
    fi
  else
    echo "OK"
  fi
}

#
########################################################
# Retrieve information for Response Center             #
########################################################
set_healthcheck_data()
{ 
  Htext[1]="Company name             : "
  Htext[2]="Name                     : "
  Htext[3]="Email address            : "
  Htext[4]="Telephone number         : "
  Htext[5]="System model number      : "
  Htext[6]="System serial number     : "
  Htext[7]="Systems system handle    : "
  config_present=0		# assume file not present
  if [ -f $CONFIG ]
  then
    file_length=`cat $CONFIG | wc -l`
    if [ $file_length -eq 7 -o $file_length -eq 8 ] 
    then 
      config_present=1		# file is present and has 7 or 8 lines
      exec 3< $CONFIG
      for i in 1 2 3 4 5 6 7
      do
        read -u3 Hdata[$i]
      done
      exec 3<&-
    fi
  fi
}

#
re_enter_data()
{
  FREPLY="Y"
  if [ $config_present -eq 1 ]  # file of 7 lines is present
  then
    while [ "$FREPLY" = "y" -o "$FREPLY" = "Y" ]
    do
      echo ""
      for i in 1 2 3 4 5 6 7
      do
        echo "     ${Htext[$i]}""${Hdata[$i]}"
      done
      echo "\nDo you wish to change the data as displayed? y/[n] : \c"
      read -r
      FREPLY=$REPLY
      if [ "$REPLY" = "y" -o "$REPLY" = "Y" ]
      then
        config_change=1
        echo "\nUse enter for no change, or enter new data!\n"
        for i in 1 2 3 4 5 6 7
        do
          echo "Old:" "${Htext[$i]}""${Hdata[$i]}"
          echo "New:" "${Htext[$i]}\c"
          read -r
          if [ ${#REPLY} -ne 0 ]
          then
            Hdata[$i]=$REPLY
          fi
        done
      fi
    done 
  fi
}

#
gather_system_info()
{ 
  echo "`date +%y%m%d_%H%M`: gather_system_info"		>> $PROGRESS
  if [ ! -d /var/stm/config/sys ]  # needed for config file HealthCheck.cfg
  then
    set_output_redirection
    echo Directory /var/stm/config/sys does not exist!
    echo Should exist if diagnostic is installed, please create directory!
      exit_cron_with_mail
    exit
  fi
  config_change=0
  set_healthcheck_data
  #*** Gather information for RC ***
  if [ $config_present -eq 1 ]	# file of 7 lines is present
  then
    if [ cron -eq 0 ] # File present and cron not running!
    then
      re_enter_data
    fi
  else				# file not present or not 7 lines
    if [ cron -eq 1 ]
    then
      set_output_redirection
      echo File "$CONFIG" not present job will abort!
      exit_cron_with_mail
    else			# First time customer data is entered
      config_change=1
      echo "\n     No info found about this system."
      echo "     Please enter the requested information :\n"
      for i in 1 2 3 4 5 6 7
      do
        echo "    " "${Htext[$i]}""\c"
        read Hdata[$i]
        if [ ${#Hdata[$i]} -eq 0 ]
        then
          Hdata[$i]="No data avail!"
        fi
      done
    fi
  fi

  if [ $config_change -eq 1 ]	# configuration has changed, rewrite file
  then
    empty_file $CONFIG
    for i in 1 2 3 4 5 6 7
    do
      echo "${Hdata[$i]}"					>> $CONFIG
    done
  fi
  #print the information
  echo "*** system information       ***"			>  $SYSTEM
  echo "*** Script to check firmware ***"			>> $SYSTEM
  echo "*** PDC etc.                 ***"			>> $SYSTEM
  if [ cron -eq 1 ]
  then
    echo "***" $revision   "(cron)   ***"			>> $SYSTEM
  else
    echo "***" $revision   "(manual) ***"			>> $SYSTEM
  fi
  echo ""							>> $SYSTEM
  for i in 1 2 3 4 5 6 7
  do
    echo "${Htext[$i]}"  "${Hdata[$i]}"				>> $SYSTEM
  done

  echo "Date this script ran     : " `date`			>> $SYSTEM

  #*** Print system relavant information ***
  echo ""							>> $SYSTEM
  echo "license                  = " `uname -l`			>> $SYSTEM
  echo "SW-ID                    = " `uname -i`			>> $SYSTEM
  if [ -f "/usr/bin/model" ]
  then
    echo "Model string             = " `/usr/bin/model`		>> $SYSTEM
  else
    echo "Model                    = " `uname -m`		>> $SYSTEM
  fi
  echo "node name                = " `uname -n`			>> $SYSTEM
  echo "SW rev                   = " `uname -r`			>> $SYSTEM
  echo "SW vers.level            = " `uname -v`			>> $SYSTEM
  echo "$eod"							>> $SYSTEM
  echo "*** detected errors          ***"			>  $ERROR
  # write the name of the tempdir to the config-file.
  echo $TEMPDIR >> $CONFIG
}

#
gather_patch_information()
{ 
  echo "`date +%y%m%d_%H%M`: gather_patch_information"		>> $PROGRESS
  echo "\ncollecting patch information                      \c"
  echo "\n***  patch info on product   ***"			>  $SWLIST1
  swlist -l product						>> $SWLIST1
  echo "$eod"							>> $SWLIST1

  echo "\n***  patch info on fileset   ***"    >  $SWLIST2
  swlist -l fileset -a state | grep -v "#" | grep -iv configured>> $SWLIST2
  echo "$eod"							>> $SWLIST2
  echo "OK"
}

#
########################################################
# I/O and Mass-Storage related functions               #
########################################################

get_io_information()
{ 
  echo "`date +%y%m%d_%H%M`: get_io_information"		>> $PROGRESS
  #*** get full ioscan into file $IOSCAN ***
  echo "\nioscan is started                                 \c"
  echo "\n***    ioscan information    ***"			>  $IOSCAN
  ioscan -fn							>> $IOSCAN
  echo "$eod"							>> $IOSCAN
  echo "OK"
  if [ `cat $IOSCAN | grep SCAN | wc -l` -gt 0 ]
  then
    set_output_redirection
    echo "Some devices are in SCAN state, better to wait until scanning is completed"
      exit_cron_with_mail
    exit
  fi
  if [ `cat $IOSCAN | grep NO_HW | grep disk | wc -l` -gt 0 ]
  then
    no_hw=1
    empty_file $NO_HW
    awk '{
      while (1) {
        if (( $1 == "disk" )  && ( $5 == "NO_HW" )) {
          getline
          system("basename  " $1 " >> '"$NO_HW"' " )
        }
        if ( getline != 1 ) break
      }
    }' $IOSCAN
  fi
  if [ $no_hw -eq 1 ]
  then
    echo "*** -no_hw  option forced    ***"                    >> $SYSTEM
  fi
}

#
get_autoraid_information()
{
  echo "`date +%y%m%d_%H%M`: get_autoraid_information"		>> $PROGRESS
  echo "\n***   autoraid information   ***"			> $ARDSP
  echo "\nretrieving Autoraid diskarray info                \c"
  if [ `cat $IOSCAN | grep -e C3586A -e C5447A | wc -l` -gt 0 ]
  then
    echo ""
    #*** there are autoraids present model 12 or 12H ***
    if [ `cat $PSEF |grep -v grep|grep ARMServer | wc -l` -ne 1 ]
    then
      set_output_redirection
      echo "\nThe ARMServer is not running please start the ARMServer!"
      echo "To start use /sbin/init.d/hparray start"
        exit_cron_with_mail
      exit
    fi
    echo "\n - If the process hangs, stop the script using Ctrl c"
    echo " - then use /sbin/init.d/hparray stop and start,"
    echo " - to get the ARMServer running"

    echo "\n***     autoraid patches     ***"			>> $ARDSP
    cat  $SWLIST1 | grep AutoRAID				>> $ARDSP
    set `what /opt/hparray/bin/ARMServer|grep Version`
    if [ $2 = "Version:" ]
    then
      echo "real ARMServer Version is " $3			>> $ARDSP
    fi
    echo "$eod"							>> $ARDSP
    echo "\n***     autoraid logfiles    ***"			>> $ARDSP
    $AR1/logprint -t disk -t ctrlr -t change | \
    grep -v -e L00 -e Log -e File -e Found	>  $TMP0
    # remove empty-lines
    cat  $TMP0 | grep ' '					>> $ARDSP
    echo "$eod"							>> $ARDSP

    # get array info using awk and arraydsp
    $AR1/arraydsp -i | grep S/N:		>  $TMP1
    echo "\n***        arraydsp          ***"			>> $ARDSP
    awk '{ 
         system("'"$AR1"'/arraydsp -a "$4" >> '"$ARDSP"' ")
         }' $TMP1

    empty_file $TMP0
    awk -v tmp0=$TMP0 ' BEGIN { serial =""; }
    { serial=$4
      printf "Autoraid disk array serialnumber " serial "\n" >> tmp0
      system("'"$AR1"'/arraydsp -d "serial" |grep slot >> '"$TMP0"' ")
    }' $TMP1

    empty_file $TMP2
    echo ""
    awk -v crn=$cron -v tmp2=$TMP2 ' BEGIN { serial="";}
    { if ( $1 == "Autoraid") { printf $0 >> tmp2; serial=$5 }
      if ( $1 == "Information" )
      { disk=substr($6,0,length($6)-1)
        if (crn==0) printf "\r - Gathering information for disk %s   ",disk
        system("'"$AR1"'/arraylog -d "disk" "serial" >>'"$TMP2"' ")
        printf "==EOD==" >> tmp2
      }
    }' $TMP0

    #No entries in Grown Defect List
    #Grown Defect List
    #Cylinder  Head      Sector
    #2657      1         147       

    echo "\n***    autoraid disk info    ***"  > $ARDISK
    awk -v ardisk=$ARDISK ' BEGIN { defects=0
    diskheader="\nO*Nodelay  *withdel *  retry  *Corrected  * ECC used  *    MB xfer *Uncor"}
    { while (( $1 != "Autoraid" ) && ($1 != "Disk")) if (getline == 0) exit
      if ($1 == "Autoraid") {printf "\n"$0 >> ardisk}
      while ( $1 != "Disk" ) if (getline == 0) exit
      disk=$4; getline; getline; product=$5; getline
      firmware=$4
      while ( $1 != "Write" ) if ( getline != 1 ) break
      getline
      for (i=0; i< 7; i++)
      { w[i]=substr($0,index($0,"=")+1); getline }
      while ( $1 != "Read" ) if ( getline != 1 ) break; getline
      for (i=0; i< 7; i++)
      { r[i]=substr($0,index($0,"=")+1); getline }
      while ( $1 != "Verify" ) if ( getline != 1 ) break
      getline
      for (i=0; i< 7; i++)
      { v[i]=substr($0,index($0,"=")+1); getline }
      while ( $1 != "Nonmedium" ) if ( getline != 1 ) break
      getline; nmErrors=$5
      while (( $1 != "Grown") && ( $4 != "Grown")) if ( getline != 1) break
      xline=sprintf("\nDisk= %s FW= %s Type= %s NM_Err= %s defects= %s",\
                disk,firmware,product,nmErrors,defects)
      printf xline >> ardisk
      printf diskheader >> ardisk
      xline=sprintf("\nW%11s          %9s %11s %11s %12s %4s",
                   w[0],w[1],w[2],w[3],w[4],w[5])
      printf xline >> ardisk
      xline=sprintf("\nR%11s %8s %9s %11s %11s %12s %4s",
            r[0],r[1],r[2],r[3],r[4],r[5],r[6])
      printf xline >> ardisk
      xline=sprintf("\nV%11s %8s %9s %11s %11s %12s %4s",
                   v[0],v[1],v[2],v[3],v[4],v[5],v[6])
      printf xline >> ardisk
      if ( ($1 == "Grown")  || ( $4 == "Grown") )
        if ( $1 == "Grown") # defects present
        { getline
          #while (($1 != "Primary") && ( $1 != "Autoraid") )
          while ($1 != "==EOD==") 
          { printf "\n"$0>> ardisk
            if ( getline != 1) break
          }
        }
      if ($1 == "Autoraid") {printf "\n"$0 >> ardisk}
    }' $TMP2
    rm $TMP1
    rm $TMP2

    echo "$EOK"
  else
    echo "$np"
    echo "*** no autoraid info present ***"			>> $ARDSP
    echo "\n***    autoraid disk info    ***"			> $ARDISK
  fi
  echo "$eod"							>> $ARDSP
  echo "\n$eod"							>> $ARDISK
}

#
get_fc60_information()
{ 
  echo "`date +%y%m%d_%H%M`: get_fc60_information"		>> $PROGRESS
  echo "\n***     FC60 information     ***"			> $FC60
  echo "\nretrieving FC60 diskarray info                    \c"
  if [ `cat $IOSCAN | grep A5277A              | wc -l` -gt 0 ]
  then
    #*** there are FC60 arrays present ***
    if [ `cat $PSEF | grep -v grep|grep AM60S | wc -l` -ne 1 ]
    then
      set_output_redirection
      echo "\nThe AM60Srvr is not running please start the AM60Srvr!"
      echo "To start use /sbin/init.d/hparamgr start"
        exit_cron_with_mail
      exit
    fi
    echo "Collecting data\n"
    echo " - If the process hangs, stop the script using Ctrl c"
    echo " - then use /sbin/init.d/hparamgr stop and start,"
    echo " - to get the AM60Srvr running"

    echo "\n***       FC60 patches       ***"			>> $FC60
    cat  $SWLIST1 | grep Manager/60				>> $FC60
    set `what /opt/hparray/bin/AM60Srvr|grep Version`
    if [ $2 = "Version:" ]
    then
      echo "real A60Srvr Version is " $3			>> $FC60
    fi
    echo "$eod"							>> $FC60
    echo "\n***       FC60 logfiles      ***"			>> $FC60
    datum=`printf "%.2d%.2d0000%.2d" $month $day $year`
    if [ -f /var/opt/hparray/log/AMMCATLG ]
    then
      /opt/hparray/bin/amlog -s "$datum" -t ctrlr -t mel|\
        grep -v -e AMM -e Log -e File -e Found	> $TMP0
    else
      /opt/hparray/bin/amlog| is "$datum"\
        grep -v -e AML -e Log -e File -e Found	> $TMP0
    fi
    # remove empty-lines
    cat  $TMP0 | grep ' '					>> $FC60
    echo "$eod"							>> $FC60

    # get array info using awk and amdsp
    /opt/hparray/bin/amdsp -i | grep S/N:	> $TMP1
    echo "\n***        fc60dsp           ***"			>> $FC60
    awk '
    { system("/opt/hparray/bin/amdsp -a "$4" >> '"$FC60"' ")
    }' $TMP1
    rm $TMP1
    echo "$EOK"
  else
    echo "$np"
    echo "***   no FC60 info present   ***"			>> $FC60
  fi
  echo "$eod"							>> $FC60
}

#
get_va7x00_information()
{ 
 echo "`date +%y%m%d_%H%M`: get_va7x00_information"		>> $PROGRESS
 vaPresent=0
 jbodPresent=0
 commandviewActive=1
 echo "\nretrieving Virtual array (7100/7400) info         \c"
 echo "\n***    casini information    ***"			> $CASDSP
 echo "\n*** casini config and parms  ***"			> $VAINFO
 if [ `cat  $SWLIST1 | grep -e CMDVIEW  -e HPCVVASVR |wc -l` -gt 0 ]
 then
  if [ `cat $IOSCAN | grep -v grep |grep -e A618 -e A6218A |wc -l` -gt 0 ]
  then  #*** there are VA7X00 array(s) present! ***
   vaPresent=1
   echo "Collecting data\n"
   echo " - If the process hangs, stop the script using Ctrl c"
   echo " - then use HA_Dial_Stop and HA_Dial_Start,"
   echo " - to get HostAgent and dial running"
   if [ ! -f "$VA4/armdsp" ]  # commandline interface not present!
   then
     echo "VA array present, but Commandline interface not!"
     commandviewActive=0
   fi
   if [ `$VA4/armdsp -i | grep Serial | wc -l` -lt 1 ]
   then
     echo "\nioscan found a VA array on the system, but armdsp -i did not!"
     echo "Try armdiscover or use HA_Dial_Stop and HA_Dial_Stop!"
     echo "/opt/sanmgr/commandview/client/sbin/HA_Dial_Start"
     #
     echo "ioscan found a VA array on the system, but armdsp -i not!" >>$ERROR
     echo "Try armdiscover or use HA dial_trigger stop/start!"        >>$ERROR
     echo "/opt/sanmgr/commandview/client/sbin/HA_Dial_Start"         >>$ERROR
     commandviewActive=0
   fi
   if [ `cat $PSEF |grep -v grep|grep -e diald| wc -l` -lt 1 ]
   then
     set_output_redirection
     echo "\nThe HostAgent or diald process is not running!"
     echo "Check HostAgent and dial process, should both be running!"
     echo "Use /opt/sanmgr/commandview/client/sbin/HA_Dial_Start!"
     #
     echo "The HostAgent or diald process is not running!"            >>$ERROR
     echo "Check HostAgent and dial process, should both be running!" >>$ERROR
     echo "Use /opt/sanmgr/commandview/client/sbin/HA_Dial_Start!"    >>$ERROR
     commandviewActive=0
   fi
   if [ commandviewActive -eq 0 ]
   then
     echo "\nCommandview for VA not working!                   No info"
     echo "*** no VA7X00 info present ***"                      >> $CASDSP
     echo "$eod"                                                >> $VAINFO
     echo "$eod"                                                >> $CASDSP
     return
   fi
  fi
 fi
 echo "\n***     casini patches       ***"			>> $CASDSP
 cat  $SWLIST1 | grep -e CMDVIEW -e HPCVVASVR			>> $CASDSP
 if [ -f "VA2/diald" ]
 then
   #what $VA2/HostAgent|grep H1363A				>> $CASDSP
   what $VA2/diald|grep H1363A					>> $CASDSP
 fi
 echo "$eod"							>> $CASDSP

 if [ -f "$VA4/armdsp" ]
 then
   echo "----------- armdsp -i ------------------"		>> $VAINFO
   $VA4/armdsp -i						>> $VAINFO
 fi
 if [ -f "$VA7/access.dat" ]
 then
   echo "----------- access.dat -----------------"		>> $VAINFO
   cat  $VA7/access.dat						>> $VAINFO
   echo "------------ dial.cfg ------------------"		>> $VAINFO
   cat  $VA7/dial.cfg						>> $VAINFO
   echo "--------- HostAgent.cfg ----------------"		>> $VAINFO
   cat  $VA7/HostAgent.cfg					>> $VAINFO
 else
   if [ -f "$VA3/access.dat" ]
   then
     echo "----------- access.dat -----------------"		>> $VAINFO
     cat  $VA3/access.dat					>> $VAINFO
     echo "------------ dial.cfg ------------------"		>> $VAINFO
     cat  $VA3/dial.cfg						>> $VAINFO
     echo "--------- HostAgent.cfg ----------------"		>> $VAINFO
     cat  $VA3/HostAgent.cfg					>> $VAINFO
   fi
 fi

 if [ -f "$VA1/PanConfigParams.txt" ]
 then
   echo "------- PanConfigParams.txt ------------"		>> $VAINFO
   cat  $VA1/PanConfigParams.txt				>> $VAINFO
 fi

 if [ -f "$VA6/DeviceDBFile" ]
 then
   echo "---------- DeviceDBFile ----------------"		>> $VAINFO
   cat  $VA6/DeviceDBFile					>> $VAINFO
 fi

 if [ vaPresent -eq 1 ]
 then
  $VA4/armdsp -i | grep Serial	>  $TMP1
  echo "\n***     casini logfiles      ***"			>> $CASDSP
  datum=`printf "%.2d%.2d000120%.2d" $month $day $year`
  echo "\n - Breaking locks and gathering logsfiles of the last 3 days!"
  awk ' BEGIN { serial =""; }
  { if ( $2=="Number:" ) {serial=$3} else {serial=substr($2,8)}
    system("'"$VA4"'/armmgr -b CreateLun  "serial" > '"$TMP2"' ") #break locks
    system("'"$VA4"'/armmgr -b FwDownload "serial" > '"$TMP2"' ")
    system("'"$VA4"'/armmgr -b Security   "serial" > '"$TMP2"' ")
    system("'"$VA4"'/armmgr -b Select     "serial" > '"$TMP2"' ")
    system("'"$VA4"'/armmgr -b PassThru   "serial" > '"$TMP2"' ")
    system("'"$VA4"'/armmgr -b HostPort   "serial" > '"$TMP2"' ")
    system("'"$VA5"' -t Device -a "serial" -s '"$datum"' -v>>'"$CASDSP"'")
  }' $TMP1
  echo "$eod"							>> $CASDSP

  # get array info using awk and armdsp
  echo "\n***        armdsp            ***"			>> $CASDSP
  awk ' BEGIN { serial =""; }
  { if ( $2=="Number:" ) {serial=$3} else {serial=substr($2,8)}
    system("'"$VA4"'/armdsp -a "serial" >> '"$CASDSP"' ")
  }' $TMP1

  echo "---------- Host behavior ----------------"		>> $VAINFO
  awk -v vainfo=$VAINFO -v tmp2=$TMP2 ' BEGIN { serial =""; }
  { if ( $2=="Number:" ) {serial=$3} else {serial=substr($2,8)}
    printf "array %s\n",serial >> vainfo
    printf "" > tmp2
    system("'"$VA4"'/armdsp -a "serial"|grep -e tings -e Beh|grep -v VFP|grep -v J >> '"$VAINFO"' ")
    system("'"$VA4"'/armhost -r -f '"$TMP2"' "serial" > '"$TMP0"'")
    system("cat '"$TMP2"' >> '"$VAINFO"' ")
  }' $TMP1

  echo "---------- Security info ----------------"		>> $VAINFO
  awk -v vainfo=$VAINFO -v tmp2=$TMP2 ' BEGIN { serial =""; }
  { if ( $2=="Number:" ) {serial=$3} else {serial=substr($2,8)}
    printf "array %s\n",serial >> vainfo
    printf "" > tmp2
    stat=system("'"$VA4"'/armsecure -r -f '"$TMP2"' -p AUTORAID "serial" 2> '"$TMP0"' > '"$TMP0"' ")
    if (stat == 0 ) 
      system("cat '"$TMP2"' >> '"$VAINFO"' ")
    else 
      printf "Cannot retrieve secure info, customer changed password!\n">>vainfo
  }' $TMP1


  empty_file $TMP0
  awk -v tmp0=$TMP0 ' BEGIN { serial =""; }
  { if ( $2=="Number:" ) {serial=$3} else {serial=substr($2,8)}
    printf "Virtual disk array serialnumber " serial "\n" >> tmp0
    system("'"$VA4"'/armdsp -d "serial" |grep Disk >> '"$TMP0"' ")
  }' $TMP1

  # collect disk information
  empty_file $TMP2
  empty_file $TMP3
  awk -v crn=$cron -v tmp2=$TMP2 -v tmp3=$TMP3 ' BEGIN { serial="";}
  { if ( $1 == "Virtual") 
    { printf $0 >> tmp2; printf "n0: %s\n",$5 >> tmp3; serial=$5 }
    if ( $2 == "at" )
    { disk=substr($3,0,length($3)-1)
      if (crn==0) printf "\r - Gathering information for disk %s   ",disk
      system("'"$VA4"'/armlog -d "disk" "serial" >>'"$TMP2"' ")
      printf "x0: " disk "\n" >> tmp3
      system("'"$VA4"'/armlog -d "disk" -p 13 "serial" >>'"$TMP3"' ")
      printf "z0:\n" >> tmp3
    }
  }' $TMP0
  echo ""
  echo "-------- casini disk info --------------"		>> $VADISK
  awk -v vadisk=$VADISK ' BEGIN { defects=0
  diskheader="\nO*Nodelay  *withdel *  retry  *Corrected  * ECC used  *    MB xfer *Uncor"}
  { while (( $1 != "Virtual" ) && ($1 != "FRU")) if (getline == 0) exit
    if ($1 == "Virtual") {printf "\n"$0 >> vadisk}
    while ( $1 != "FRU" ) if (getline == 0) exit
    disk=$5; getline; getline; capacity=$5"Gb"; getline
    firmware=$6; getline; product=$6
    while ( $1 != "Write" ) if ( getline != 1 ) break
    getline
    for (i=0; i< 6; i++)
    { w[i]=substr($0,index($0,"=")+1); getline }
    while ( $1 != "Read" ) if ( getline != 1 ) break; getline
    for (i=0; i< 7; i++)
    { r[i]=substr($0,index($0,"=")+1); getline }
    while ( $1 != "Verify" ) if ( getline != 1 ) break
    getline
    for (i=0; i< 7; i++)
    { v[i]=substr($0,index($0,"=")+1); getline }
    while ( $2 != "non-medium" ) if ( getline != 1 ) break
    nmErrors=$5
    while ( $1 != "Defect" ) if ( getline != 1 ) break; getline
    if ($1 == "There") defects=$3; else defects="None"
    xline=sprintf("\nDisk= %s FW= %s Type= %s cap= %s NM_Err= %s defects= %s",\
                disk,firmware,product,capacity,nmErrors,defects) 
    printf xline >> vadisk 
    printf diskheader >> vadisk
    xline=sprintf("\nW%11s          %9s %11s %11s %12s %4s",
                   w[0],w[1],w[2],w[3],w[4],w[5])
    printf xline >> vadisk
    xline=sprintf("\nR%11s %8s %9s %11s %11s %12s %4s",
            r[0],r[1],r[2],r[3],r[4],r[5],r[6])
    printf xline >> vadisk
    xline=sprintf("\nV%11s %8s %9s %11s %11s %12s %4s",
                   v[0],v[1],v[2],v[3],v[4],v[5],v[6])
    printf xline >> vadisk
    if ($1 == "There")
    { getline; defects=0
      while ($1 == "Defect") 
      { if (defects < 10 ) printf "\n"$0>> vadisk; 
        defects++;  if (getline != 1 ) break
        if (defects == 10 ) printf "\nRemaining defects not printed" >>vadisk
      } 
    }
    if ($1 == "Virtual") {printf "\n"$0 >> vadisk}
  }' $TMP2
  cat $TMP3 |grep 0: > $TMP2
  empty_file $TMP3
  cat $VADISK						 	>> $VAINFO
  echo "\n-------- VA disk array port info --------------"	>> $VAINFO
  awk -v tmp3=$TMP3 ' BEGIN { ind=0; i=0; serial="" } 
  { if ( $1 == "n0:" ) serial=$2
    if ( $1 == "x0:" ) # disk header found
    { info[0]=$2; info[5]="0x0063"; ind=1
      for (i=0; i<3; i++) {a[i]="0x000003E7"; b[i]="0x000003E7"} #9999
    }
    else
    if ($1 == "z0:") # disk trailer found
    { temp="0x"info[5]
      for (i=1; i<ind; i++)
      { if (info[i] == "8100") a[0]=sprintf "0x%s%s",info[i+2],info[i+3]
	if (info[i] == "8101") a[1]=sprintf "0x%s%s",info[i+2],info[i+3]
	if (info[i] == "8105") a[2]=sprintf "0x%s%s",info[i+2],info[i+3]
	if (info[i] == "8110") b[0]=sprintf "0x%s%s",info[i+2],info[i+3]
	if (info[i] == "8111") b[1]=sprintf "0x%s%s",info[i+2],info[i+3]
	if (info[i] == "8115") b[2]=sprintf "0x%s%s",info[i+2],info[i+3]
      }
      printf "\n%s %s %s %s %s %s %s %s %s",\
	    serial,info[0],temp,a[0],a[1],a[2],b[0],b[1],b[2] >> tmp3
    }
    else for( i=2; i<6; i++)
    { if ( (length($i) == 4 ) || (length($i) == 8 ) )
      { { info[ind]=substr($i,0,4); ind++ }
        if ( length($i) == 8) { info[ind]=substr($i,5);
        ind++ }
      }
    }
  } ' $TMP2
  printf "serial          Disk  temp linkf-A  Loss-A  CRC-A linkf-B  Loss-B  CRC-B\n" >> $VAINFO
  printf "%12s %7s %5d %7d %7d %6d %7d %7d %6d\n" `cat $TMP3`	>> $VAINFO
  rm $TMP1
  rm $TMP2
  rm $TMP3
  echo "$EOK"
 fi
 if [ vaPresent -eq 0 ]
 then
   echo "$np"
   echo "*** no VA7X00 info present ***"			>> $CASDSP
   echo "\n***     casini logfiles      ***"			>> $CASDSP
   echo "$eod"							>> $CASDSP
   echo "\n***        armdsp            ***"			>> $CASDSP
 fi
 echo "\n$eod"							>> $VAINFO
 echo "$eod"							>> $CASDSP
}


#
get_misc_ioscan()
{
  echo "`date +%y%m%d_%H%M`: get_misc_ioscan"			>> $PROGRESS
  #*** report all busses on the system ***
  echo "\n***        bus info          ***"			>  $PARTS
  cat $IOSCAN|grep ext_bus					>> $PARTS
  echo "$eod"							>> $PARTS

  #*** report all SCSI interfaces on the system ***
  echo "\n***     SCSI interfaces      ***"			>> $PARTS
  cat $IOSCAN|grep Initiator					>> $PARTS
  echo "$eod"							>> $PARTS

  #report all processors in the system
  echo "\n***      processor info      ***"			>> $PARTS
  cat $IOSCAN|grep processor					>> $PARTS
  echo "$eod"							>> $PARTS
  
  #*** report all memory on the system ***
  echo "\n***       memory info        ***"			>> $PARTS
  cat $IOSCAN|grep memory					>> $PARTS
  echo "$eod"							>> $PARTS
  
  #*** report all unclaimed devices ***
  echo "\n***     unclaimed devices    ***"			>  $PARTS_ERR
  cat $IOSCAN|grep UNCLAIMED					>> $PARTS_ERR
  echo "$eod"							>> $PARTS_ERR
  
  #*** report all devices that have no hardware installed currently ***
  echo "\n***   no hardware installed  ***"			>> $PARTS_ERR
  cat $IOSCAN|grep NO_HW					>> $PARTS_ERR
  echo "$eod"							>> $PARTS_ERR
}

#
get_fibre_information()
{
  echo "`date +%y%m%d_%H%M`: get_fibre_information"		>> $PROGRESS
  empty_file $TMP1
  #   Copy only fibrechannel information
  echo "\n*** fibrechannel information ***"			>  $FIBRE
  echo "\nprocessing Fibre channel information              \c"
  cat $IOSCAN | grep -e /dev/fcms -e /dev/td -e /dev/fcd > $TMP0
  if [ -s $TMP0 ]
  then
    #*** remove and create file for error reporting ***
    awk ' BEGIN{ i=0; dev_file=""}
    { i=1
      while (length($i) -ne 0 )
      { if ( (substr($i,1,7) == "/dev/td"  ) ||
             (substr($i,1,9) == "/dev/fcms") ||
             (substr($i,1,8) == "/dev/fcd") )
        { dev_file=$i; break }
        i++
      }
      system("echo \""dev_file"\"                              >> '"$FIBRE"' ")
      if ( substr(dev_file,1,7) == "/dev/td")
        system("/opt/fcms/bin/tdutil "dev_file" read 0x008 pci >> '"$FIBRE"' ")
      system("/opt/fcms/bin/fcmsutil "dev_file"                >> '"$FIBRE"' ")
      if (substr($i,1,8) == "/dev/fcd")
        system("/opt/fcms/bin/fcmsutil "dev_file" vpd          >> '"$FIBRE"' ")
      system("/opt/fcms/bin/fcmsutil "dev_file" read_cr        >> '"$FIBRE"' ")
      system("/opt/fcms/bin/fcmsutil "dev_file" stat           >> '"$FIBRE"' ")
      if ( substr($i,1,9) != "/dev/fcms" )
      { system("echo \""dev_file"\" >> '"$TMP1"' ")
        system("/opt/fcms/bin/fcmsutil "dev_file" get remote all >> '"$TMP1"' ")
      }
    }' $TMP0
    echo "OK"
  else
    echo "$np"
    echo "\n***  no Fibre info present   ***"			>>  $FIBRE
  fi
  echo "$eod"							>> $FIBRE
  echo "***      get remote all      ***"			>> $FIBRE
  cat $TMP1|grep -e ' =' -e '/dev/'				>> $FIBRE
  echo "$eod"							>> $FIBRE
}

#
collect_disk_information()
{ 
  echo "`date +%y%m%d_%H%M`: collect_disk_information"		>> $PROGRESS
  #   Copy only disk and diskarray information to file $DISK
  cat $IOSCAN | grep -e /dev/rdsk -e disk			> $DISK
  echo "\nprocessing disk information."
  echo " - Diskdrives that are not present or"
  echo " - not on-line may display errors:                \c"

  empty_file $TMP0
  empty_file $TMP1					# empty if no errors
  answer="n"
  awk -v tmp=$TMP0 ' 
  { while (endOfFile == 0 )
    { while ( $1 != "disk" ) if ( getline != 1 )	# must start with disk!
      { endOfFile=1
        break
      }
      if ( endOfFile != 0 ) break			# EOF found
      if ( ( substr($8,0,2) == "DV"  ) ||		# skip dvd players
           ( substr($8,0,2) == "DW"  ) ||		# skip dvd players
           ( index($0,"DVD") > 0     ) ||		# skip DVD players
           ( substr($8,0,2) == "CD"  ) ||		# skip CDROM players
           ( index($0,"ROM") > 0     ) ||		# skip new type DVD
           ( $8 == "DISK-SUBSYSTEM"  ) ||		# skip dummy FC device
           ( $5 == "NO_HW" )           ||		# skip no hardware
           ( index($0,"PSEUDO") > 0  ) ||		# skip OEM PSEUDO dev
           ( substr($8,length($8)-2,3)=="UNB") )	# skip Nike unbound
      { if ( getline != 1) { endOfFile=1; break; }
        continue
      } else break					# valid entry
    }
    if ( endOfFile != 0 ) break				# EOF found
    instance=$2
    hw_path=$3
    sw_stat=$5
    scsi_id=$8
    if ( getline != 1 ) break
    if ( substr($1,1,5) != "/dev/" )
    { printf "\nDevice files missing for disk on path %s.",hw_path
      system("echo Error >> '"$TMP1"' ")
      continue						# Skip to next entry
    }

    # find the right variable, which contains the character-special-file
    i=1; dev_file=""
    while (length($i) -ne 0 )
    { if ( substr($i,1,9) == "/dev/rdsk" ) { dev_file=$i; break }
      i++
    }
    # create the name of the block-special-file
    bdev_file="/dev/dsk"substr(dev_file,10)
  
    # retrieve diskinfo-information
    stat=system("diskinfo -v \""dev_file"\"| grep -e /dev/rdsk -e vendor -e product -e size -e level                                          >> '"$TMP0"' ")
    if (stat == 0)
    { printf "%s %s %s %s %s\n", 
		instance, hw_path, sw_stat, scsi_id,dev_file >> tmp
    } else
    { printf "\nDiskinfo of %s failed\n", dev_file
      system("echo \""dev_file"\" failed diskinfo command >> '"$TMP1"' ")
    }
  }' $DISK
  if [ `cat $TMP1 | wc -w` -gt 0 ] 			# errors found
  then
    set_output_redirection
    echo "\n"`cat $TMP1 | wc -w` "\c"
    echo "errors found in this part (diskinfo) of the script!"
    echo "It is probably better to stop,correct the situation and run again!"
      exit_cron_with_mail
    echo "\nDo you wish to continue y/n? : \c"
    read answer
    if [ "$answer" = "n" -o "$answer" = "N" ]
    then
      exit
    fi
  fi
  
  #   Gather all diskinfo to file $DISK one line per device
  # dev_file, instance, hw_path, vendor, id, capacity, firmware, ir, qd, timeout
  #
  #    disk information record layout
  #1:  SCSI describe of /dev/rdsk/c1t6d0:
  #2:               vendor: SEAGATE 
  #3:           product id: ST39102LC       
  #4:                 size: 8891556 Kbytes
  #5:            rev level: HP01
  #6:  0 0/0/2/0.6.0 CLAIMED ST39102LC /dev/rdsk/c1t6d0
  empty_file $TMP2
  empty_file $TMP1				# file empty if no errors
  awk '
  { dev_file=substr($4,1,length($4)-1)	# remove : from string
    getline					# get line 2
    vendor=$2
    getline					# get line 3
    product_id=$3
    getline					# get line 4
    size=$2
    getline					# get line 5
    level=$3
    getline					# get line 6
    dev_test=$5
    instance=$1
    path=$2
    #
    #  Skip dummy entries for the FC60 (volumeset addressing)
    #
    if ((product_id == "A5277A") && (size == "0")) continue
    if ((substr(product_id,0,2) == "OP") && (size == "0")) continue
    if ( dev_file == dev_test)    # device files match
    { x_line=sprintf "%s %s %s %s %s %s %s",\
		dev_file, instance,path,vendor,product_id,size,level
      system("echo \""x_line"\" >> '"$TMP2"' ")
      stat=system("scsictl -a "dev_file" >> '"$TMP2"' ")
      if (stat != 0)
      { system("echo immediate_report = 0\; queue_depth = 0>> '"$TMP2"' ")
        system("echo Error >> '"$TMP1"' ")
        system("echo scsictl fails on device "dev_file" ")
      }
    }
  }' $TMP0
  echo "\n***     disk information     ***"			> $DISK
  if [ `cat $TMP1 | wc -w` -gt 0 ]		# errors found
  then
    set_output_redirection
    echo "\n"`cat $TMP1 | wc -w` "\c"
    echo "errors found in this part (scsictl) of the script!"
    echo "It is probably better to stop,correct the situation and run again!"
      exit_cron_with_mail
    echo "\nDo you wish to continue y/n? : \c"
    read answer
    if [ "$answer" = "n" -o "$answer" = "N" ]
    then
      exit
    fi
  else
    echo "OK"
  fi

  #   file $TMP2 contents
  #1: /dev/rdsk/c1t6d0 0 0/0/2/0.6.0 SEAGATE ST39102LC 8891556 HP01
  #2: immediate_report = 0; queue_depth = 8
  awk '
  { dev_file=substr($4,1,length($4)-1)
    dev_file=$1
    instance=$2
    path=$3
    vendor=$4
    product_id=$5
    size=$6
    level=$7
    getline			# get line 2
    ir=substr($3,1,length($3)-1)
    qd=$6
    x_line=sprintf "%s %s %s %s %s %s %s %s %s", dev_file, instance,
          path, vendor, product_id, size, level, ir, qd
    system("echo \""x_line"\" >> '"$DISK"' ")
  }' $TMP2
  echo "$eod"							>> $DISK
}

#
get_filesystem_info()
{ 
  echo "`date +%y%m%d_%H%M`: get_filesystem_info"		>> $PROGRESS
  echo "\nretrieving file-system-information                \c"
  echo "\n***          bdf             ***"			>  $FS
  bdf								>> $FS
  echo "$eod"							>> $FS

  echo "\n*** vg-directory information ***"			>> $FS
  for vg in $(ls -R /dev/*/group | xargs -i dirname {})
  do
    echo $vg							>> $FS
    ll $vg							>> $FS
    echo							>> $FS
  done
  echo "$eod"							>> $FS

  echo "\n***  lvlnboot    information ***"			>> $FS
  if [ $no_hw -eq 0 ]
  then
    lvlnboot -v                                      2>>$ERROR  >> $LVLN
    cat $LVLN	                 				>> $FS
  else
    echo "Skipped lvlnboot"                                     >> $FS
    echo "Skipped lvlnboot"
    echo "                                                  Due to missing disks !!"
  fi
  echo "$eod"							>> $FS

  echo "\n***  swapinfo    information ***"			>> $FS
  swapinfo							>> $FS
  echo "$eod"							>> $FS

  if [ $no_hw -eq 0 ]
  then
    echo "OK"
  fi
}

#
get_kernel_information()
{
  echo "`date +%y%m%d_%H%M`: get_kernel_information"		>> $PROGRESS
  echo "\nretrieving info from the kernel                   \c"
  empty_file $TMP2

  echo "\n*** kernel driver info       ***"			>  $KERNEL
  echo "*system_data/s" | adb /stand/vmunix /dev/kmem >  $TMP1

  awk '
  { first_line=first_line+1
    if ( first_line == 1 )
    { if ( length($2) != 0 )
      { position=index($0,$2)
        print substr($0,position)
      }
    }
    else
      print $0
  }' $TMP1 >> $TMP2

  cat $TMP2							>> $KERNEL
  if [ -f "/usr/sbin/kctune" ]
  then
    echo "\n--- kernel tunable parameters ---"			>> $KERNEL
    /usr/sbin/kctune						>> $KERNEL
  else
    if [ -f "/usr/sbin/kmtune" ]
    then
      echo "\n--- kernel tunable parameters ---"		>> $KERNEL
      /usr/sbin/kmtune						>> $KERNEL
    fi
  fi
  if [ -f "/usr/sbin/sysdef" ]
  then
    echo "\n--- kernel parm information  ---"			>> $KERNEL
    /usr/sbin/sysdef						>> $KERNEL
  fi
  echo "$eod"							>> $KERNEL

  # compare the output with the system-file

  echo "\n*** diff. with system-file   ***"			>> $KERNEL
  diff $TMP2     /stand/system					>> $KERNEL
  
  echo "$eod"							>> $KERNEL

  echo "\n*** kernel patch information ***"			>> $KERNEL
  what /stand/vmunix						>> $KERNEL
  echo "$eod"							>> $KERNEL

  echo "OK"
}

#
get_syslog()
{ 
  echo "`date +%y%m%d_%H%M`: get_syslog"			>> $PROGRESS
  echo "\nretrieving syslog-information                     \c"
  echo "\n***   /etc/dmesg contents    ***"			>  $DMESG
  echo "\n--- uptime information       ---"                     >> $DMESG
  /usr/bin/uptime                                               >> $DMESG
  echo "\n--- dmesg  information       ---"                     >> $DMESG
  /etc/dmesg | /usr/bin/dos2ux        				>> $DMESG
  echo "$eod"							>> $DMESG

  echo "\n***   syslog.log contents    ***"			>  $SYSLOG
  if [ -f "/var/adm/syslog/OLDsyslog.log" ]
  then
    set `ls -ld /var/adm/syslog/OLDsyslog.log| sed 's/-/x/'`
    oldsyslogSize=$5
    /usr/bin/dos2ux /var/adm/syslog/OLDsyslog.log >$TMP2
  else
    oldsyslogSize=0; empty_file $TMP2
  fi
  if [ -f "/var/adm/syslog/syslog.log" ]
  then
    set `ls -ld /var/adm/syslog/syslog.log| sed 's/-/x/'`
    syslogSize=$5
    /usr/bin/dos2ux /var/adm/syslog/syslog.log >$TMP1
  else
    syslogSize=0; empty_file $TMP1
  fi

  # **** ADDED for HAO purpose ***
  if [ psopt -eq 1 ]
  then
    awk -v fileSize=$oldsyslogSize -v tmp3=$SYSLOG '{
     if (NR == 1) startdate=substr($0,1,15)
     Lastline=$0
    } END { enddate=substr(Lastline,1,15)
    printf "OLDsyslog ("fileSize" Bytes), from "startdate" until "enddate"" >>'"tmp3"'
    } ' $TMP2
    echo "\n-------------------------------------------------------" >> $SYSLOG
    $PREPSYSL $TMP2 >$TMP0
    cat duplicate.log						>>$SYSLOG
    echo "+++++\n+++++\n"					>>$SYSLOG
    # rm duplicate.log

    awk -v fileSize=$syslogSize -v tmp3=$SYSLOG '{
     if (NR == 1) startdate=substr($0,1,15)
     Lastline=$0
    } END { enddate=substr(Lastline,1,15)
    printf "syslog ("fileSize" Bytes), from "startdate" until "enddate"" >>'"tmp3"'
    } ' $TMP2
    echo "\n-------------------------------------------------------" >> $SYSLOG
    $PREPSYSL $TMP1 >$TMP2
    cat duplicate.log						>> $SYSLOG
    echo "\n\n====== OLDsyslog ====="				>> $SYSLOG
    cat $TMP0 >> $SYSLOG
    echo "\n====== syslog ====="				>> $SYSLOG
    cat $TMP2							>> $SYSLOG
    echo "\n"							>> $SYSLOG
    rm duplicate.log
    empty_file $TMP0
    empty_file $TMP1
    empty_file $TMP2
  else
  # **** END ADD ***

  awk -v fileSize=$oldsyslogSize -v tmp0=$TMP0 -v tmp3=$SYSLOG ' BEGIN {
         linecount=0; ftpcount=0; filefull=0; skiprepeat=0; writeline=0
         emptyLines=0; nport=0; startdate=""; enddate="" }
  {
   linecount++; writeline=0;
   if (linecount == 1) startdate=substr($0,1,15)
   if ( (index($0,"inetd[") != 0) || (index($0,"ftpd[") != 0) ||
        (index($0,"tcp: Connection from") != 0) ||
        (index($0,"Accepted rsa") !=0 ) )
    { ftpcount++; skiprepeat=1
      if (ftpcount > 100 ) writeline++   # do not write this line
    } else
     if (index($0,"file system full") != 0)
     { filefull++
       if (filefull > 100 ) writeline++
     } else
     if (substr($0,length($0) -8) == " vmunix: " )
     { emptyLines++; writeline++
     } else
     if (substr($0,length($0) -8) == "previously accessed device" )
     { nport++; 
       if (nport > 1000 ) writeline++
     } else
      if (( skiprepeat>0) && (index($0,"message repeat") != 0)) writeline++
      else skiprepeat=0
   if (writeline == 0)
   { xline=sprintf "%s", $0
     printf "\n"xline"" > '"tmp0"'
   }
  } END { enddate=substr(xline,1,15)
    printf "OLDsyslog ("fileSize" Bytes), from "startdate" until "enddate"" >>'"tmp3"'
    printf "\n#lines="linecount", #fstpentries="ftpcount", ">>'"tmp3"'
    printf " #filesysfull="filefull", #emptylines="emptyLines" ">>'"tmp3"'
    printf " #previous accessed devices="nport" " >>'"tmp3"'
  } ' $TMP2

  empty_file $TMP2

  awk -v fileSize=$syslogSize -v tmp2=$TMP2 -v tmp3=$SYSLOG ' BEGIN {
         linecount=0; ftpcount=0; filefull=0; skiprepeat=0; writeline=0;
         emptyLines=0; nport=0; startdate=""; enddate="" }
  {
   linecount++; writeline=0;
   if (linecount == 1) startdate=substr($0,1,15)
   if ( (index($0,"inetd[") != 0) || (index($0,"ftpd[") != 0) ||
        (index($0,"tcp: Connection from") != 0) ||
        (index($0,"Accepted rsa") !=0 ) )
    { ftpcount++; skiprepeat=1
      if (ftpcount > 100 ) writeline++  # do not write this line
    } else
     if (index($0,"file system full") != 0)
     { filefull++
       if (filefull > 100 ) writeline++
     } else
     if (substr($0,length($0) -8) == " vmunix: " )
     { emptyLines++; writeline++
     } else
     if (substr($0,length($0) -8) == "previously accessed device" )
     { nport++; 
       if (nport > 1000 ) writeline++
     } else
      if (( skiprepeat>0) && (index($0,"message repeat") != 0)) writeline++
      else skiprepeat=0
   if (writeline == 0)
   { xline=sprintf "%s", $0
     printf "\n"xline"" > '"tmp2"'
   }
  } END { enddate=substr(xline,1,15)
  printf "\n---syslog ("fileSize" Bytes), from "startdate" until "enddate"" >>'"tmp3"'
    printf "\n#lines="linecount", #ftpentries="ftpcount", ">>'"tmp3"'
    printf " #filesysfull="filefull", #emptylines="emptyLines" ">>'"tmp3"'
    printf " #previous accessed devices="nport" " >>'"tmp3"'
        } ' $TMP1
  empty_file $TMP1

  echo "\n====== OLDsyslog =====\c"				>> $SYSLOG
  cat $TMP0							>> $SYSLOG
  empty_file $TMP0
  echo "\n===== syslog ====\c"					>> $SYSLOG
  cat $TMP2							>> $SYSLOG
  echo "\n"							>> $SYSLOG
  empty_file $TMP2

  # **** ADDED for HAO purpose ***
    fi
  # **** END ADD for HAO purpose ***

  echo "$eod"							>> $SYSLOG
  echo "OK"
}
 
#
process_EMS_info()
{ 
  echo "`date +%y%m%d_%H%M`: process_EMS_info"			>> $PROGRESS
  echo "\n*** EMS status information   ***"			>  $EMS_INFO
  echo "C" | /etc/opt/resmon/lbin/monconfig 2>> $ERROR | \
  sed -e 's/=/#/g' -e 's/>#/>=/g' -e 's/dr#/dr=/' -e 's/le#/le=/' -e 's/rt#/rt=/' -e 's/st#/st=/' >> $EMS_INFO
  echo "\n$eod"							>> $EMS_INFO

  echo "\n*** EMS message information  ***"			>  $EMS
  if [ -f /var/opt/resmon/log/event.log ]
  then
    /usr/bin/dos2ux /var/opt/resmon/log/event.log		>> $EMS
  else
    echo File /var/opt/resmon/log/event.log not present		>> $EMS
  fi
  echo "$eod"							>> $EMS
}
  
#
get_lvm_info()
##############################################
# Get LVM info check for alternate links etc #
##############################################
{ 
  echo "`date +%y%m%d_%H%M`: get_lvm_info"			>> $PROGRESS
  echo "\ngathering LVM information                         \c"

  echo "\n***     lvm configuration    ***"			>  $LVM
  ll /dev/*/group						>> $LVM
  echo "$eod"							>> $LVM
  
  echo "\n***     lvm device files     ***"			>> $LVM
  strings /etc/lvmconf/vg*.conf |grep /dev/			>> $LVM
  echo "$eod"							>> $LVM

  echo "\n***         lvmtab           ***"			>> $LVM
  strings /etc/lvmtab						>> $LVM

  echo "\n---         fstab            ---"			>> $LVM
  strings /etc/fstab						>> $LVM
  echo "$eod"							>> $LVM

  echo "\n***        vg info           ***"			>> $LVM
  vgdisplay -v 2>>$ERROR | grep " " > $TMP1
  awk '
  { first_line=first_line+1
    if (( $1 == "VG" ) && ( $2 == "Name" ))
    {
      if ( first_line != 2 )
      {
        print "---------------------"
      }
    }
    print $0
  }' $TMP1 >> $LVM
  echo "$eod"							>> $LVM

  echo "\n***       vgname info        ***"			>> $LVM
  cat $TMP1 | grep -e Name -e Status -e Free			>> $LVM
  echo "$eod"							>> $LVM

  # retrieve only the names of the lvol's
  cat $TMP1 | grep 'LV Name' >  $TMP0
  
  # check for logical extents that are in stale or unavailable status!
  
  #Get stale extent information!
  echo "\n***    lvm stale extents     ***"			>> $LVM
  awk '
  { system("echo "$3" >> '"$LVM"' ")
    system("lvdisplay -v "$3" 2>>'"$ERROR"' | grep -e stale -e unavailable >> '"$LVM"' ")
  }' $TMP0
  echo "$eod"							>> $LVM
  
  cat $TMP1 |grep -e 'LV Name' -e 'PV Name' >  $TMP0
  empty_file $LVOL
  DD1="dd bs=512 count=1 skip=18<"
  DD2="dd bs=512 count=1 skip=146<"
  echo "\n***   badblock information   ***"			>  $BADBLOCK
  
  #Get lvol info, badblock reallocation and timeout value to $LVOL
  
  awk '
  { while ( $4 == "Alternate" ) if ( getline != 1 ) break
    system("echo "$3" >> '"$LVOL"' ")
    if (substr($3,1,9) == "/dev/dsk/")
    { bdev_file=$3
      dev_file="/dev/rdsk"substr(bdev_file,9)
      stat=system("pvdisplay "bdev_file" 2>>'"$ERROR"' |grep IO >> '"$LVOL"' ")
      if (stat != 0 )
      system("echo IO Timeout Seconds error >> '"$LVOL"' ")
      if ('"$no_hw"' == 0 ) {
        system("echo \""dev_file"\"           >> '"$BADBLOCK"' ")
        system(" '"$DD1"' "dev_file" 2>>'"$BADBLOCK"'| xd >> '"$BADBLOCK"' ")
        system(" '"$DD2"' "dev_file" 2>>'"$BADBLOCK"'| xd >> '"$BADBLOCK"' ")
      }
    }
    else
      system("lvdisplay "$3" 2>>'"$ERROR"'| grep -e IO -e Bad >> '"$LVOL"' ")
  }' $TMP0

  #Contents of file $LVOL, 3 lines per logical volume
  #/dev/vg00/lvol6
  #Bad block                   on
  #IO Timeout (Seconds)        default
  #add lvol, badblock reallocation parm and timeout value to $LVM
  #PV Name contents
  #Physical timeout value
  echo "\n***      vg lvol info        ***"			>> $LVM
  awk '
  { vol_type=$1
    getline
    if (substr(vol_type,1,9) == "/dev/dsk/")          #Physical volume
       x_line=sprintf "%s %s", vol_type, $4
    else                                              #logical volume
    {  bad_block=$3
       getline
       time_out=$4
       x_line=sprintf "%s %s %s", vol_type, bad_block, time_out
    }
    system("echo \""x_line"\" >> '"$LVM"' ")
  } ' $LVOL
  echo "$eod"							>> $LVM
  echo "$eod"							>> $BADBLOCK

  cat $TMP1 | grep 'PV Name' | grep -v -i 'alternate' >  $TMP0
  echo "***         pv info          ***"			 > $PVDISP
  while read part1 part2 name
  do 
  {
    first=first+1
    if [ first -ne 1 ]
    then
      echo "-------------" >>$PVDISP
    fi
    pvdisplay -v $name 2>>$ERROR > $TMP2
    awk '
    {
      if (( $1 == "PV" ) && ( $2 == "Name" ))
        print $0
  
      if (( $1 == "LV" ) && ( $2 == "Name" )) { 
        while (length($0) != 0) { 
          print $0
          getline
        }
      }
    }' $TMP2 >> $PVDISP
  } done < $TMP0

  echo "$eod"							>> $PVDISP
  echo "OK"
}

#
get_xpinfo()
{
  echo "`date +%y%m%d_%H%M`: get_xpinfo"			>> $PROGRESS
  echo "\n***  xp256/xp512/xp48 info   ***"			>  $XPINFO
  if [ `cat $IOSCAN | grep -v grep|grep 'OPEN-' | wc -l` -gt 0 ]
  then
    echo "\nretrieving XP-information                         \c"
    if [ -f "/usr/contrib/bin/xpinfo" ]
    then
      /usr/contrib/bin/xpinfo -v				>> $XPINFO
      /usr/contrib/bin/xpinfo -ld                               >> $XPINFO
      echo "OK"
    else
      echo "*** /usr/contrib/bin/xpinfo not present! ***"	>> $XPINFO
      echo "\n*** /usr/contrib/bin/xpinfo not present! ***"
    fi
  fi
  echo "$eod"							>> $XPINFO
}

#
get_tombstone()
{
  echo "`date +%y%m%d_%H%M`: get_tombstone"			>> $PROGRESS
  echo "\n***   Tombstone ts99 info    ***"			>  $TOMBSTONE
  if [ -f "/var/tombstones/ts99" ]
  then
    echo "\nretrieving latest tombstone                       \c"
    /usr/bin/dos2ux /var/tombstones/ts99			>> $TOMBSTONE
    echo "OK"
  fi
  echo "$eod"							>> $TOMBSTONE
}

#
get_vxlist()
{ 
  VXDISK=/usr/sbin/vxdisk
  
  echo "`date +%y%m%d_%H%M`: get_vxlist"			>> $PROGRESS
  echo "\n***   Veritas filesystem     ***"			>  $VXLIST
  if [ -f "/usr/sbin/vxdisk" ]
  then
    if [ -f "/etc/vx/volboot" ]     # Veritas is configured
    then
      if [ `cat $PSEF |grep -v grep|grep vxconfigd | wc -l` -eq 1 ]  # deamon!
      then
        echo "\nretrieving Veritas filesystem info                \c"
        echo "---------- vxdisk list -----------"		>> $VXLIST
        $VXDISK list >$TMP0
        cat $TMP0                                               >> $VXLIST
        awk -v vxlist=$VXLIST ' {
          if ( $4 != "-" && $4 != "GROUP" ) {
            printf "---------------------\n" >> vxlist
            system(" '"$VXDISK"' list "$1" '">>$VXLIST"' ")
          }
        }' $TMP0
        echo "------------ vxprint -------------"		>>  $VXLIST
        /usr/sbin/vxprint -rth                                  >>  $VXLIST
        echo "---------------------\n"                          >>  $VXLIST
        /usr/sbin/vxprint -l                                    >>  $VXLIST
        echo "OK"
      else
        echo "Veritas configured, deamon vxconfigd not running.">> $VXLIST
      fi
    else
      echo "Veritas not configured, volboot not present!"	>> $VXLIST
    fi
  else
    echo "Veritas file system not present on this system!"	>> $VXLIST
  fi
  echo "$eod"							>>  $VXLIST
}

#
get_raid4si()
{ 
  echo "`date +%y%m%d_%H%M`: get_raid4si"			>> $PROGRESS
  echo "\n***     raid4si card         ***"			>  $RAID4SI
  echo "\nretrieving RAID 4si related information           \c"
  if [ `cat $IOSCAN | grep I2O| wc -l` -gt 0 ]
  then
    /sbin/irdiag -v 2> /dev/null				>> $RAID4SI
    echo "OK"
  else
    echo "$np"
  fi
  echo "\n$eod"							>> $RAID4SI
}

#
get_SmartArray()
{ 
  echo "`date +%y%m%d_%H%M`: get_SmartArray"			>> $PROGRESS
  echo "\n***   SmartArray  card       ***"                     >>  $RAID4SI
  echo "\nretrieving SmartArray related information         \c"
  if [ `cat $IOSCAN | grep SmartArray| wc -l` -gt 0 ]
  then
    cat $IOSCAN | grep '/dev/ciss' > $TMP0
    awk '
    { system("/opt/raidsa/bin/sautil "$0"  >> '"$RAID4SI"'")
      system("/opt/raidsa/bin/sautil "$0" stat >> '"$RAID4SI"'")
    } ' $TMP0
    echo "OK"
  else
    echo "$np"
  fi
  echo "\n$eod"                                                 >> $RAID4SI
}

#
get_san_details()
{ 
  echo "`date +%y%m%d_%H%M`: get_san_details"			>> $PROGRESS
  echo "\nretrieving SAN related parameters.                \c"
  echo "\n***   SAN related parms      ***"			>  $SAN
  echo "Mesa version " $mesaVersion				>> $SAN
  cat $KERNEL |grep scsi_tape.c	> $TMP0
  if [ `cat $TMP0 | wc -l` -gt 0 ]
  then
    cat $TMP0							>> $SAN
  else
    echo "stape not found in kernel!"				>> $SAN
  fi
  if [ `cat $PSEF |grep -v grep|grep diaglogd | wc -l` -eq 1 ]
  then
    echo "diaglogd process is running!"				>> $SAN
  else
    echo "diaglogd process is NOT running, check it!"		>> $SAN
  fi
  if [ -f /var/stm/config/tools/monitor/dm_stape.cfg ]
  then
    cat /var/stm/config/tools/monitor/dm_stape.cfg\
        |grep POLL_INTERVAL					>> $SAN
  else
    echo "dm_stape.cfg POLINTERVAL file not present!"		>> $SAN
  fi
  cat $KERNEL|grep st_ats_enabled > $TMP0
  if [ `cat $TMP0|wc -l` -eq 0 ]
  then
    printf "%15s notPresent" st_ats_enabled			>> $SAN
  else
    set `cat $TMP0`
    printf "%15s Current    %s  Planned %s\n" $1 $2 $4		>> $SAN
  fi
  cat $KERNEL|grep st_san_safe   > $TMP0
  if [ `cat $TMP0|wc -l` -eq 0 ]
  then
    printf "%15s notPresent" st_san_safe			>> $SAN
  else
    set `cat $TMP0`
    printf "%15s Current    %s  Planned %s\n" $1 $2 $4		>> $SAN
  fi
  if [ `cat $PSEF|grep diald | wc -l` -eq 1 ]
  then
    echo "diald process running"				>> $SAN
  else
    echo "diald process not running"				>> $SAN
  fi
  echo "\n$eod"							>> $SAN
  echo "OK"
}

#
get_root_boot_info()
{ 
  echo "`date +%y%m%d_%H%M`: get_root_boot_info"		>> $PROGRESS
  # get lif ls info
  echo "\nretrieving root and boot specific info            \c"
  empty_file $TMP1
  if [ $no_hw -eq 0 ]
  then
    cat $LVLN | grep 'Boot Disk' > $TMP0
    awk '{ dev_file="/dev/rdsk/"substr($1,9)
           system("echo lifls -l "dev_file" >> '"$TMP1"' ")
           system("lifls -l "dev_file"  >> '"$TMP1"' 2>&1")
         }' $TMP0
  fi
  echo "\n***   lifls    information   ***"			>  $LIF
  cat $TMP1							>> $LIF
  echo "$eod"							>> $LIF

  echo "\n***    root and boot info    ***"			>  $RTBT
  echo "============== lvln boot =================="		>> $RTBT
  if [ $no_hw -eq 0 ]
  then
    cat $LVLN                     				>> $RTBT
  fi
  if [ -x /sbin/crashconf ]
    then
    echo "=========== Crash configuration ==========="		>> $RTBT
    /sbin/crashconf -v						>> $RTBT
  fi
  echo "\nCrash-directory : \n"                                 >> $RTBT
  echo "/etc/rc.config.d/save* reports: \n"                     >> $RTBT
  grep SAVE /etc/rc.config.d/save* | grep DIR                   >> $RTBT
  grep SAVE /etc/rc.config.d/save* | grep DIR | grep -v '#' |\
    cut -f 2 -d =                                                > $TMP2
  if [ -s $TMP2 ]
  then
    echo "\nll `cat $TMP2`"                                     >> $RTBT
    ll -R `cat $TMP2`                                           >> $RTBT
  else
    echo "\nNo dedicated directory specified, using /var/adm/crash:\n" >>$RTBT
    echo "ll /var/adm/crash"                                    >> $RTBT
    ll -R /var/adm/crash                                        >> $RTBT
  fi

  echo "\n============ lifls information  ==========="		>> $RTBT
  cat $TMP1							>> $RTBT
  echo "\n============== shutdown log ==============="		>> $RTBT
  cat /etc/shutdownlog						>> $RTBT
  if [ -f "/usr/sbin/parstatus" ] &&
     [ `cat $SYSTEM|grep '9000/800/S' |wc -l` -ne 0 ]
  then
    echo "\n=========== N Partition status ============="	 > $TMP1
    empty_file $TMP2
    cat $KERNEL|grep pat_psm.c > $TMP0
    awk -v tmp1=$TMP1 ' BEGIN { found=0 }
    { patch=""; start=index($0,"PHKL")
      patch=substr($0,start+5,5)
      if ( patch > "28099" ) 
      { system("/usr/sbin/parstatus 2>'"$TMP2"' >> '"$TMP1"' ")
        found=1; exit
      }
    } END {
     if ( found != 1 ) # Superdome Keystone and patch not installed
     { printf "Minimum patch required for parstatus is PHKL_28100!\n"    >>tmp1 
       printf "Missing this patch may need a reboot, see SN A6093A-23!\n">>tmp1 
       printf "Patch PHKL_28100 or replacement is not installed!\n"      >>tmp1
     }
    } ' $TMP0
    if [ `cat $TMP2|grep Unsupported|wc -l` -eq 0 ]
    then
      if [ `cat $TMP1|wc -l` -gt 1 ]
      then
        cat $TMP1						>> $RTBT
      fi
    fi
  fi
  if [ -f "/usr/sbin/vparstatus" ]
  then
    echo "\n=========== V Partition status ============="	>> $RTBT
    /usr/sbin/vparstatus -w		2>>$ERROR		>> $RTBT
    /usr/sbin/vparstatus -v	        2>>$ERROR		>> $RTBT
  fi
  echo "$eod"							>> $RTBT
  echo "OK"
}

get_EVA()
{ 
  echo "`date +%y%m%d_%H%M`: get_EVA"				>> $PROGRESS
  echo "\n***     EVA disk array       ***"			>  $EVA
  if [ -f "/sbin/spmgr" ]
  then
    echo "\nretrieving EVA related information                \c"
    /sbin/spmgr display						>> $EVA
    echo "OK"
  fi
  echo "$eod"							>> $EVA
}

#
get_laninfo()
{ 
  echo "`date +%y%m%d_%H%M`: get_laninfo"			>> $PROGRESS
  echo "\nretrieving LAN related information                \c"
  echo "\n***     lan information      ***"			>  $LAN

# create a script to check lanadmin, it might hang, kill it after 60 seconds
cat >$CHECK_LAN  <<'@EOF'
stay=true
while [ $stay = "true" ]
do
  # create a file with running lanadmin-processes
  ps -ef | grep lanadmin | grep -v grep | awk '{print $2 " " $7}' |
    cut -f 1 -d : > /tmp/check_lan.log

  # check the entries
  if [ -s /tmp/check_lan.log ]
  then
    while read process run_time
    do
      if [ $run_time -eq "1" ]
      then
        # The process is taking too much time, stop it.
        kill -9 $process
      fi
    done </tmp/check_lan.log
    sleep 10
  else
    stay=false
  fi
done
@EOF
chmod 544 $CHECK_LAN 

  echo "\n***     lan information      ***"			>  $LAN
  lanscan > $TMP0
  empty_file $TMP1
  unix=`uname -r`
  major=`expr substr $unix 3 2`
  # xline=sprintf("lan\nppa %s\ndisplay\nquit",$3)   # this is OK
  # xline=sprintf("lan\nppa %s\ndisplay",$3)         # this will hang lanadmin
  if [ $major = "11" ]
  then
    echo "\n--- lanscan information      ---"                   >> $LAN
    cat $TMP0                                                   >> $LAN
    echo "\n--- ifconfig information     ---"                   >> $LAN
    echo ""                                                     >> $LAN
    awk ' {
      if ( $2 != "0x000000000000" && $4 == "UP" ) {
       system("ifconfig "$5" '"2>>$ERROR"' '"1>>$LAN"' ")
      }
    }' $TMP0
    echo "\n--- netstat information      ---"                   >> $LAN
    echo ""                                                     >> $LAN
    netstat -r                                                  >> $LAN
    echo "\n--- lanadmin information     ---"                   >> $LAN
    awk -v tmp1=$TMP1 ' {
      if ( $2 != "0x000000000000" && $4 == "UP" ) {
       xline=sprintf("lan\nppa %s\ndisplay\nquit",$3)
       system("echo \""xline"\" > '"$TMP1"' ")
       system("lanadmin< '"$TMP1"' 2>/dev/null | grep -v Return '"1>>$LAN"' &")
       system(" '"$CHECK_LAN"' ")
      }
    }' $TMP0
  fi
  echo "$eod"							>> $LAN
  rm $CHECK_LAN
  echo "OK"
}

#
get_gsp_mp_log()
{ gspLog=0
  echo "`date +%y%m%d_%H%M`: get_gsp_mplog"			>> $PROGRESS
  echo "\n***        ccerrlog          ***"			>  $GSP
  echo "\nretrieving GSP or MP related information          \c"
  if [ -f "/usr/sbin/diag/contrib/cclogview" ]
  then
    CCLV=/usr/sbin/diag/contrib
    CCTR=/usr/sbin/stm/uut/bin/progs
    CCLG=/var/stm/logs/os
    # create symbolic link as workaround
    if [ ! -f "$CCTR/cc_translator" ] && [ -f "$CCLV/cc_translator" ] &&\
       [ -f "$CCLG/ccerrlog" ] && [ -f "$CCLG/ccbootlog" ]
    then
      printf "\ncclogview is missing a link to cc_translator and ccux2hex!\n"
      printf "link for cc_translator created in $CCTR.\n"
      ln -s $CCLV/cc_translator $CCTR/cc_translator
    fi
    if [ ! -f "$CCTR/ccux2hex" ] && [ -f "$CCLV/ccux2hex" ] &&\
       [ -f "$CCLG/ccerrlog" ] && [ -f "$CCLG/ccbootlog" ]
    then
      printf "link for cc_ux2hex created in $CCTR.\n"
      ln -s $CCLV/ccux2hex $CCTR/ccux2hex
    fi
    if [ -f "/var/stm/logs/os/ccerrlog" ]
    then
      gspLog=1
      empty_file $TMP0
      echo "\n - retrieving ccerrlog                            \c"
      $CCLV/cclogview /var/stm/logs/os/ccerrlog 2>$TMP0 > $TMP1
      dos2ux $TMP1 > $TMP2
      awk -v tmp=$GSP ' BEGIN { line=""; keep=0 }
      { if (( $1 == "Alert" ) && ( $3 != "0:") && ( $3 != "1:")) keep=1
        if ( length($0) < 4 )
        { if ( keep > 0 ) printf "%s",line >> tmp
          line=""; keep=0
        }
        if (length($0) > 3) line=sprintf "%s%s\n",line,$0
          else line=sprintf "%s***\n",line
      } END { if (keep > 0 ) printf "%s",line >> tmp } ' $TMP2
      if [ -s "$TMP0" ] # are there any error messages?
      then
        echo "Error in ccerrlog"                                >> $ERROR
        cat $TMP0                                               >> $ERROR
        echo "ccerrlog Failed (bug in cclogview!)"
      else
        echo "OK"
      fi
    fi
  fi
  echo "$eod"							>> $GSP
  echo "\n***       ccbootlog          ***"			>> $GSP
  if [ -f "/usr/sbin/diag/contrib/cclogview" ]
  then
    if [ -f "/var/stm/logs/os/ccbootlog" ]
    then
      empty_file $TMP0
      gspLog=2
      echo "\n - retrieving ccbootlog                           \c"
      $CCLV/cclogview /var/stm/logs/os/ccbootlog 2>$TMP0 > $TMP1
      dos2ux $TMP1 > $TMP2
      awk -v tmp=$GSP ' BEGIN { line=""; keep=0 }
      { if (( $1 == "Alert" ) && ( $3 != "0:") && ( $3 != "1:")) keep=1
        if ( length($0) < 4 )
        { if ( keep > 0 ) printf "%s",line >> tmp
          line=""; keep=0
        }
        if (length($0) > 3) line=sprintf "%s%s\n",line,$0
          else line=sprintf "%s***\n",line
      } END { if (keep > 0 ) printf "%s",line >> tmp } ' $TMP2
      if [ -s "$TMP0" ] # are there any error messages?
      then
        echo "Error in ccbootlog"                               >>$ERROR
        cat $TMP0                                               >>$ERROR
        echo "ccbootlog Failed"
      else
        echo "OK"
      fi
    fi
  fi
  echo "$eod"                                                   >> $GSP
  echo "\n***          mplog           ***"                     >> $GSP
  if [ gspLog -gt 0 ] # this system has a GSP and not a MP
  then
    echo "$eod"							>> $GSP
    return
  fi
  ll /var/stm/logs/os/fpl.log.* > $TMP0                        2>>$ERROR
  if [ `cat $TMP0|wc -l` -ge 1 ] && [ -f /usr/sbin/diag/contrib/slview ]
  then
    logCount=`cat $TMP0|wc -l`
    echo "\nThere are in total "$logCount" mplogs on this system"
    echo " - retrieving only the last mplog (be patient!)   \c"
    awk -v gsp=$GSP -v count=$logCount '
    { while ( count > 1 ) 
      { printf "File %s %s %s %s %s not examined!\n", $9,$5,$6,$7,$8	>> gsp
        if (getline==0) exit; else count --;
      }
      printf "slview 3: Warning, Critical, Fatal of log %s %s %s %s %s\n"\
              , $9,$5,$6,$7,$8 >> gsp
      printf "Search for *5 Critical or *7 for Fatal\n"			>> gsp
      system("/usr/sbin/diag/contrib/slview -d -a 3 -f "$9" >> '"$GSP"'")
    } ' $TMP0
    echo "MP OK"
  else
    if [ $gspLog -eq 0 ]
    then
      echo "No MP or GSP files"
    fi
  fi
  echo "$eod"                                                   >> $GSP
}

#
get_CPU_info()
{ 
  echo "`date +%y%m%d_%H%M`: get_CPU_info"			>> $PROGRESS
  echo "\n***     CPU information      ***"                     >> $SYSTEM
  if [ -f "/usr/contrib/bin/machinfo" ]
  then
    /usr/contrib/bin/machinfo                                   >> $SYSTEM
  fi
  echo "================= ICOD info =================="         >> $SYSTEM
  if [ -f "/usr/sbin/icod_stat" ]
  then
    /usr/sbin/icod_stat                               2>>$ERROR >> $SYSTEM
  fi
  echo "$eod"                                                   >> $SYSTEM
}

#
combine_data()
{
#########################################################################
#*** collect all date for shipment to response center                ***#
#*** Do not change anything, as sequence is important to the program ***#
#########################################################################
 
  if [ aborted -eq 1 ]
  then
    echo "\nCollecting temporary-files                        \c"
    echo "================ TMP0-3 info ================="       >> $ERROR
    echo "\n$TEMPDIR/tmp_0 : "                                  >> $ERROR
    cat $TEMPDIR/tmp_0 2>/dev/null                              >> $ERROR
    echo "\n$TMP1 : "                                           >> $ERROR
    cat $TMP1 2>/dev/null                                       >> $ERROR
    echo "\n$TMP2 : "                                           >> $ERROR
    cat $TMP2 2>/dev/null                                       >> $ERROR
    echo "\n$TMP3 : "                                           >> $ERROR
    cat $TMP3 2>/dev/null                                       >> $ERROR
    echo "OK"
  fi

  echo "`date +%y%m%d_%H%M`: combine_data"			>> $PROGRESS
  echo "$eod"							>> $PROGRESS
  echo "$eod"							>> $ERROR
  echo "\ncombining collected information                   \c"

  mv $SYSTEM $TMPNAME

  for i in $PARTS  $PARTS_ERR $FIBRE     $MESA  $LVM    $IOSCAN $PSEF  \
	   $DISK   $BADBLOCK  $LIF       $ARDSP $ARDISK $FC60   \
	   $FS     $SWLIST1   $SWLIST2   $DMESG $SYSLOG $KERNEL \
           $XPINFO $CASDSP    $TOMBSTONE $EMS   $VAINFO $RTBT   \
           $VXLIST $RAID4SI   $SAN       $EVA   $LAN    $GSP    \
           $ERROR  $PVDISP    $SG        $EMS_INFO      $PROGRESS\  
  do
    if [ aborted -eq 1 ]
    then
      # Only cat and remove existing files
      if [ -r $i ]
      then
        cat $i        >> $TMPNAME
        rm $i
      fi
    else
      cat $i          >> $TMPNAME
      rm $i
    fi
  done
  #
  # Remove the 8th line from the config-file
  line8=`cat - << EOF | ed -s $CONFIG
  8
  d
  w
  q
  EOF`
  echo "OK"
}

compress_the_data()
{
  echo "\ncompressing the collected data                    \c"
  # Check to see if we can create a file in the present directory.
  touch $NAME 2>> /dev/null
  if [ ! -r $NAME ]
  then
    echo "\nCannot create file $NAME, permission ??"
    echo "Will create file in /tmp                          \c"
    NAME=/tmp/`uname -n`$creationDate
  else
    rm $NAME
  fi
  /usr/contrib/bin/gzip -c $TMPNAME > $NAME.gz
  # cleanup the various files
  if [ -s $NAME.gz ]
  then
    rm -r $TEMPDIR
    if [ -f $NAME.err ]
    then
      if [ ! -s $NAME.err ]
      then
        rm $NAME.err
      fi
    fi
  fi
  echo "OK"
}
  
#
##################################################################
# Here starts the main-function, which calls all other functions #
##################################################################

check_sum			# Is this the original file as it should be?

check_root			# check we are root

echo "\n***    running processes     ***"	>  $PSEF
echo "Checksum "$cksum" "$CKSUM""		>> $PSEF
ps -ef 						>> $PSEF
echo "$eod"					>> $PSEF

if [ aborted -eq 0 ]
then
  # The script was aborted during the previous run,
  # collect all data and stop
  #
  check_tmp			# check /tmp exists

  set_date_minus3		# get date for fc60 and va logs
  
  if [ $no_SC -eq 0 ]
  then
    check_SC			# Check NODE_TIMEOUT SG
  else
    H="           #"
    echo "\n$H#########################################################"
    echo "$H                                                        #"
    echo "$H You have selected to execute this script bypassing the #"
    echo "$H Node-Timeout-check for Service Guard Clusters          #"
    echo "$H                                                        #"
    echo "$H When this value is incorrect and the system is heavy   #"
    echo "$H loaded might this result is a package- and/or cluster- #"
    echo "$H failover and/or HPMC/TOC's.                            #"
    echo "$H                                                        #"
    echo "$H You should try this only at quite moments              #"
    echo "$H                                                        #"
    echo "$H#########################################################"
    echo "\nDo you still wish to continue y/[n]? : \c"
    read tmp
    if [ "$tmp" != "y" -a "$tmp" != "Y" ]
    then
      exit
    fi
  fi
  
  check_mesa			# check if we have mesa / stm / diagnostics
  
  gather_system_info		# collect system-information
  
  if [ mesa -eq 1 ]
  then
    retrieve_mesa_info		# get mesa-data
  fi
  
  get_io_information		# get general i/o information
  
  get_misc_ioscan		# gather parts from the ioscan
  
  get_fibre_information		# report fibre-channel information
  
  collect_disk_information	# collect data from standard disks
  
  gather_patch_information	# collect swlist-output
  
  get_autoraid_information	# collect data from autoraids
  
  get_fc60_information		# collect data from fc60
  
  get_va7x00_information	# collect data from VA7100 or VA7400
  
  get_filesystem_info		# collect info about the file-systems
  
  get_lvm_info			# collect general lvm infomation
  
  get_kernel_information	# collect info from the kernel
  
  get_syslog			# retrieve the kernel's message-buffer
  
  get_xpinfo			# retrieve Hitachi diskarray info
  
  get_tombstone			# retrieve the latest tombstone ts99
  
  process_EMS_info		# Retrieve EMS detailed info
  
  get_root_boot_info		# Get combined root and boot related info
  
  get_vxlist			# Get Veritas filesystem information
  
  get_raid4si			# Get info on raid4si card id present
  
  get_SmartArray		# Get info smart array A7143A, A9890A and A9891A
  
  get_san_details		# san tape and xp related ems info
  
  get_EVA			# get EVA related information
  
  get_laninfo			# get network related info.
  
  get_gsp_mp_log		# get ccerrlog and ccbootlog
  
  get_CPU_info			# colelct CPU info specific Itanium
fi

combine_data			# combine all to one file
  
compress_the_data		# compress the data-file

echo ""
echo "############################################################"
echo "# Please return the file"
echo "#"
echo "# '$NAME.gz'"
echo "#"
echo "# Always use Binary transfer!"
echo "# We will analyze the information and return the results"
echo "############################################################"
echo ""
