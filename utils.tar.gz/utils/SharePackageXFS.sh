#!/usr/bin/sh

conffile="/tmp/SharePackageXFS.tmp.$$"

function Usage
{
cat - <<EOT
Usage: $0 packagename  [packageconf-file]
        this script will share all  ^nfs/hanfs_export/XFS entries that are 
        defined in the running package or in the packageconfiguration file
packagename: the ServiceGuard package name
packageconf-file: the packageconfiguration file to use
EOT
exit 1
}

function ErrorExit
{
rm -rf $existingstripped
rm -rf $currentstripped
rm -rf $conffile

echo "ERROR: $1"
exit 1
}

[[ -z "$1" ]] && Usage
packagename=$1

if [[ -z "$2" ]]
then cmgetconf -p ${packagename} ${conffile} || ErrorExit \
		"Problem reading package configuration: cmgetconf -p ${packagename} ${conffile}"
else conffile="$2"
fi

[[ ! -f "${conffile}" ]] && ErrorExit "${conffile} doesn't exist"
grep ^nfs/hanfs_export/XFS ${conffile} | while read skip opt
do
	opt=$(echo ${opt} | tr -d '"')
	echo "about to share $opt"
	share $opt
done
