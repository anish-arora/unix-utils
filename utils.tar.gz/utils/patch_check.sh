#!/usr/bin/ksh
# Author: Bolek Mynarski <bmynars@ncsus.jnj.com>
#
# $Revision: 1.2 $
# $Date: 2012/11/09 09:51:30 $
# $Header: /ncs/cvsroot/ncsbin/utils/patch_check.sh,v 1.2 2012/11/09 09:51:30 gdhaese1 Exp $
# $Id: patch_check.sh,v 1.2 2012/11/09 09:51:30 gdhaese1 Exp $
# $Locker:  $
# History: Check the bottom of the file for revision history
# ----------------------------------------------------------------------------

typeset -x PRGNAME=${0##*/}
typeset -x PRGDIR=${0%/*}

[[ $PRGDIR = . || $PRGDIR != /* ]] && PRGDIR=$(pwd)


# ------------------------------------------------------------------------------
#                                   MAIN BODY
# ------------------------------------------------------------------------------

# The purpose of this script is to provide a quick way of verifying which patches
# are missing from the local system when compared to ITIS formal RMP patch releases.
# A valid RMP patch bundle name is always required to be passed as an argument to
# this script.

function _line {
	typeset -i i=0
	while [ $i -lt ${1:-80} ]; do
		(( i+=1 ))
		echo "-\c"
	done
	echo
}

function _note {
	echo " ** $*"
}

if [ $# -ne 1 ]; then
	cat <<-eof
	Usage: $PRGNAME <RMP patch bundle name>
	
	eof
	exit
fi

typeset os=$(uname -r); os=${os#B.}			# e.g. 11.11
typeset rmp=$1
typeset depot=/var/opt/ignite/depots/GLOBAL
typeset tmpfil=/var/tmp/${PRGNAME%sh}tmp
typeset tmploc=/var/tmp/${PRGNAME%sh}loc

rmp_os=$(echo $rmp | cut -c7-11 | sed -e 's/-/./')	# e.g. 11.11
[[ "$os" != "$rmp_os" ]] && {
	_note "$prgname ($LINENO): Operating System is $os, but patch bundle Os is for $rmp_os (exit)"
	exit 1
}
_note "$prgname ($LINENO): acquiring list of patches from $rmp bundle..."
swlist $rmp @ 10.4.9.76:$depot/$rmp > $tmpfil 2>/dev/null
swlist $rmp @ itsblp02.jnj.com:$depot/$rmp >> $tmpfil 2>/dev/null

_note "$prgname ($LINENO): acquiring local list of patches..."
swlist -l product > $tmploc


echo "\n ** Checking for patches for $rmp\n"
_line 75 
printf "%20s | %11s | %25s | %s\n" "Patch" "Version" "Description" "Status"
_line 75 


for i in $tmpfil $tmploc; do
	if [ ! -s $i ] ; then
		_note "$prgname ($LINENO): $i blank or non existant"
		exit 1
	fi
done

while read product ver junk; do
	typeset -l prod=$product
	case $prod in
    	ncsgpb*|itsgpb*|jnjgpb*) : ;;
	    *) continue ;;
	esac
	
	prd=" ${product#*.} "
	typeset -L25 desc="$junk"
	printf "%20s | %11s | %25s | %s\n" "$prd" \
  "$ver" \
  "$desc" \
  "$(grep -q $prd $tmploc && echo OK || echo NotPresent)"
done < $tmpfil

# ----------------------------------------------------------------------------
# $Log: patch_check.sh,v $
# Revision 1.2  2012/11/09 09:51:30  gdhaese1
# script knows how to deal with {ncs|its|jnj}gpb and does a basic check on os and rpm_os
#
# Revision 1.1  2007/08/08 19:22:06  bmynars
# Initial commit
#
#
# $RCSfile: patch_check.sh,v $
# $Source: /ncs/cvsroot/ncsbin/utils/patch_check.sh,v $
# $State: Exp $
# ----------------------------------------------------------------------------
