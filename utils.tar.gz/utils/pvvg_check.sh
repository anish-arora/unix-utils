#!/bin/sh
# Author: Bolek Mynarski <bmynars@ncsus.jnj.com>
#
# $Revision: 1.2 $
# $Date: 2006/04/10 04:06:42 $
# $Header: /ncs/cvsroot/ncsbin/utils/pvvg_check.sh,v 1.2 2006/04/10 04:06:42 bmynars Stab $ 
# $Id: pvvg_check.sh,v 1.2 2006/04/10 04:06:42 bmynars Stab $
# $Locker:  $
# History: Check the bottom of the file for revision history
# ----------------------------------------------------------------------------

# Purpose of this script is to collect information on
# pv links in a volume group that would provide
# information on what occupies it along with the size.

typeset -x PRGNAME=${0##*/}
typeset -x PRGDIR=${0%/*}

[[ $PRGDIR = . || $PRGDIR != /* ]] && PRGDIR=$(pwd)

function _line {
	typeset -i i=0
	while [ $i -lt ${1:-80} ]; do
		(( i+=1 ))
		echo "${2:-=}\c"
	done
	echo
}

function _note {
	echo " ** $*"
}

function _freePV {
	typeset pv=$1
	typeset -i free=pe=0

	pvdisplay $pv |\
	while read f1 f2 f3; do
		case $f1 in
			PE) pe=${f3##* } ;;
			Free) free=$f3; break ;;
			*) continue ;;
		esac
	done

	echo $(( $pe * $free )) 
}

if [ $# -lt 1 ]; then
	cat <<-eof
	Usage: $PRGNAME <vg1 vg2 ...>

	eof
	exit
fi

# Sanity checks

set -A vgArry
typeset -i c=0

# We want to make sure that the volume group passed here is
# a valid one.

for i in $@; do
	vgdisplay $i > /dev/null 2>&1 

	if [ $? -eq 0 ]; then
		vgArry[(( c+=1 ))]=$i
	else
		_note "$PRGNAME ($LINENO): $i does not exits!"	
	fi
done

# ------------------------------------------------------------------------------
#                                   MAIN BODY
# ------------------------------------------------------------------------------

[ ${#vgArry[@]} -gt 0 ] || { _note "No valid VGs found!"; exit 1; }


# Processing volume groups
for i in ${vgArry[@]}; do
	_line
	_note "Volume Group: [$i]"
	_line

	# Get PE Size
	size=$(vgdisplay $i | awk '/PE Size/ { print $NF }')
	vg=${i%/*}; vg=${vg#*/}

	for pv in $(vgdisplay -v $i | awk '/PV Name/ && NF == 3 { print $NF }'); do
		
		free=$(_freePV $pv)
		echo "   \n ** $pv (${free}Mb free) ****"
		_line 51 -

		pvdisplay -v $pv |\
		awk -v VG=$vg '$1 ~ VG { print }' |\
		while read lv sze junk; do
			printf "%35s: %10d(Mb)\n" "$lv" $(($size*$sze))
		done
	done
	echo
done


# ----------------------------------------------------------------------------
# $Log: pvvg_check.sh,v $
# Revision 1.2  2006/04/10 04:06:42  bmynars
# Added display for free space left on queried PV.
#
# Revision 1.1  2006/03/29 03:48:34  bmynars
# Initial commit
#
# $RCSfile: pvvg_check.sh,v $
# $Source: /ncs/cvsroot/ncsbin/utils/pvvg_check.sh,v $
# $State: Stab $
# ----------------------------------------------------------------------------
