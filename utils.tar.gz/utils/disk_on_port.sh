#!/usr/dt/bin/dtksh
# Author: Bolek Mynarski <bmynars@ncsus.jnj.com>
#
# $Revision: 1.4 $
# $Date: 2008/05/19 14:37:21 $
# $Header: /ncs/cvsroot/ncsbin/utils/disk_on_port.sh,v 1.4 2008/05/19 14:37:21 bmynars Exp $ 
# $Id: disk_on_port.sh,v 1.4 2008/05/19 14:37:21 bmynars Exp $
# $Locker:  $
# History: Check the bottom of the file for revision history
# ----------------------------------------------------------------------------

typeset -x PRGNAME=${0##*/}
typeset -x DIRNAME=${0%/*}
typeset -x PATH=$PATH:/sbin:/usr/sbin:/usr/local/CPR/bin
typeset -r osVer=$(uname -r)

[[ $DIRNAME == /* ]] || DIRNAME=$(pwd)

# -----------------------------------------------------------------------------
#                           FUNCTIONS
# -----------------------------------------------------------------------------

function _note {
	echo "  ** $*"
}

function _size {
	typeset size=$($dskinfo $1 | grep "size: ")
	size=${size% *}; size=${size##* }
	size=$(($size / 1024))

	echo $size
}

function _pv {
	typeset is=0
	typeset vgname=""
	
	$pvdisp $1 2> /dev/null |\
	
	while read LINE; do
		case $LINE in
			*$1*) echo $LINE | grep -q 'Alternate' && is=1 ;;
			'VG Name'*) vgname=${LINE##* } ;;
			*) continue ;;
		esac
	done
	
	echo "${vgname##*/}\c"
	if [ $is -eq 1 ]; then
		echo "(a)"
	else
		echo
	fi		
}

function _wait {
	typeset prg=$1
	typeset log=$2
	typeset -i i=0
	typeset p pid
	
	case $prg in
		*xpinfo*) $prg -i > $log & ;;
		*inq*) $prg -no_dots -f_emc > $log & ;;
		*) $prg > $log & ;;
	esac

	pid=$!
	p=${pid%%${pid#?}} # Extract first character from the pid

	echo "Progress: \c"

	while ps -ef | grep -q "[${p}]${pid#?}"; do
		echo "*\c"
		sleep 3
		(( i+=1 ))
		(( i % 80 == 0 )) && echo
	done	

	echo
	echo "Total wait time: $(($i * 3)) second(s)"
	echo "--------------\n"
}

function _line {
	typeset -i i=0
	while [ $i -lt ${1:-80} ]; do
		(( i+= 1 ))
		echo "=\c"
	done
	echo
}

typeset xp=/usr/local/CPR/bin/xpinfo
typeset inq=${xp%/*}/inq.HP
typeset dskinfo=/usr/sbin/diskinfo
typeset dinfo=$DIRNAME/dskinfo.sh
typeset pvdisp=/usr/sbin/pvdisplay
typeset fc=/opt/fcms/bin/fcmsutil
typeset xptmp=/var/tmp/xpinfo.log
typeset inqtmp=/var/tmp/inq.log
typeset dinfotmp=/var/tmp/dskinfo.log
typeset -i i=0
typeset run=0 # used to determine if refresh of logs is required
set -A fcArry # Setting fiber channel array

# -----------------------------------------------------------------------------
#                           SANITY CHECKS
# -----------------------------------------------------------------------------

# This script is no longer required on B.11.3*.

case $osVer in
	B.11.3*)
		cat <<-eof

		$PRGNAME: this script is deprecated on $osVer.  Please, do not use it.

		eof

		exit
	;;
esac


for prg in $xp $dinfo $inq; do
	if [ ! -x $prg ]; then
		_note "$PRGNAME ($LINENO): [$prg] missing."
		exit 1
	fi
done

# -----------------------------------------------------------------------------
#                           MAIN BODY
# -----------------------------------------------------------------------------


while [ $# -gt 0 ]; do
	case "$1" in
		-r) run=1 ;; # refresh xpinfo and dskinfo logs
		-h)
			_note "Usage: $PRGNAME <-r|-h>"
			echo "    where '-r' option is optional and is used to"
			echo "    refresh read log files.  You should use it"
			echo "    if you are not sure whether disk configuration"
			echo "    on your system has changed."
			exit 0
		;;
		*) : ;; # unchanged
	esac
	shift
done


if [ $run -eq 1 ]; then
	_note "Collecting [xpinfo] information."
	_note "Info will be found in [$xptmp]."
	_wait $xp $xptmp
	wait

	_note "Collecting disk device file name information."
	_note "Info will be found in [$dinfotmp]."
	_wait $dinfo $dinfotmp
	wait
	
	grep -q SYMMETRIX $dinfotmp && {
		_note "Collecting [inq] information."
		_note "Info will be found in [$inqtmp]."
		_wait $inq $inqtmp
	}
else
	_note "Checking for existing log files.  Please, remember to"
	_note "refresh the logs from time to time or when disks have"
	_note "been added or removed!  Use '-r' switch to refresh it."
	
	for x in $xptmp $dinfotmp $inqtmp; do
		printf "%25s: %15-s" "[$x]"
		if [ -f "$x" ]; then
			echo "[  Ok  ]"
		else
			echo "[Not Present]"
			_note "[$x] will be re-run now..."
			case $x in
				*xpinf*)
					_note "Collecting [xpinfo] information."
					_note "Info will be found in [$xptmp]"
					_wait $xp $xptmp
					wait
				;;
				*inq*)
					_note "Collecting [inq] information."
					_note "Info will be found in [$inqtmp]"
					_wait $inq $inqtmp
					wait
				;;
				*dskin*)
					_note "Collecting disk device file name information."
					_note "Info will be found in [$dinfotmp]."
					_wait $dinfo $dinfotmp
					wait
				;;
			esac
		fi
	done	
fi

# -----------------------------------------------------------------------------

_note "Collection finished.  Continuing with disk selection (it might take a while)."

[ -s "$xptmp" ] || { _note "$PRGNAME ($LINENO): error.  [$xptmp] missing or blank"; exit 1; }

# Collecting fc information
for fiber in $(ioscan -funC fc | grep '/dev'); do
	$fc $fiber |\
	while IFS='=' read key value; do
		case "$key" in
			*'N_Port Port'*) wwn=$value ;;
			*Hardware*) hrd=${value#* } ;;
			*) continue ;;
		esac
	done
	fcArry[(( i+=1 ))]="$hrd:$wwn:$fiber"	
done

# -----------------------------------------------------------------------------
#                     Acutal work takes place here
# -----------------------------------------------------------------------------
t1="DevName"
t2="VgName"
t3="Size"
t4="HrdPath"
t5="Port"
t6="Lun"
t7="ClDev"
t8="Serial"
t9="WWN"
t10="crd"

printf "\n%9s %15s %10s %15s %4s %3s %5s %8s %20s %9s\n" \
"$(_line 9)" "$(_line 15)" "$(_line 10)" "$(_line 15)" "$(_line 4)" "===" \
"$(_line 5)" "$(_line 8)" "$(_line 20)" "$(_line 9)"

printf "%9s %15s %10s %15s %4s %3s %5s %8s %20s %9s\n" "$t1" "$t2" "$t3" "$t4" "$t5" "$t6" \
"$t7" "$t8" "$t9" "$t10"
printf "%9s %15s %10s %15s %4s %3s %5s %8s %20s %9s\n" \
"$(_line 9)" "$(_line 15)" "$(_line 10)" "$(_line 15)" "$(_line 4)" "===" \
"$(_line 5)" "$(_line 8)" "$(_line 20)" "$(_line 9)"



for p in $(awk '{ print $5 }' $xptmp | sort -u); do
	case $p in
		Lun*) continue ;;
		[A-Z]*) : ;; # continute with the rest
		*) continue ;; # blank space or other
	esac
	
	while read devfile alpa tgt lun port culdev typ serial; do
		rdsk=$devfile
		dsk=/dev/${devfile#/dev/r}
	
		[[ $port = $p ]] || continue

		size=$(_size $rdsk)
		vg=$(_pv $dsk)
		
		# Check if disk belongs to any VG
		[ -n "$vg" ]  && vg=${vg%* } || vg=NonLVM
	
		# Make sure the size of disk is greater than 0
		if [[ $size -eq 0 ]]; then
			Vg=NonLVM
		else
			Vg=${vg%* }
		fi

		# Matching disk device file name against hardware path and
		# fiber channel world wide name

		set -A resArry $(grep " ${rdsk##*/} " $dinfotmp)
				
		[[ ${rdsk##*/} = ${resArry[4]} ]] || { echo; continue; }

		for j in "${fcArry[@]}"; do
			case $j in
				${resArry[0]}:*) myval="$j"; myval=${myval%:*}; fctd=${j##*:} ;;
				*) continue ;;
			esac
		done

		[ -n "$myval" ] || myval=":"
		
		# dev file name | vg | size | hardware path | port | lun | culdev | serial | wwn | td
		printf "%9s %15s %10s %15s %4s %3s %5s %8s %20s %9s\n" \
		"${devfile##*/}" "$Vg" "${size}M" "${myval%:*}" \
		"$port" "$lun" "$culdev" "$serial" "${myval#*:}" "$fctd"
		
		unset resArry

	done < $xptmp
done

# ------------------------------------------------------------------------------
#           This is a work around for systems having EMC storage
# ------------------------------------------------------------------------------

grep -q ":EMC" $inqtmp || exit 0 # Nothing to process

# We are using Korn 12/28/93 version (do not switch 'shebang' to /usr/bin/ksh!)
# Read in lines will be split into an indexed val array.  We will expect following
# values:
#  - ${val[0]}: disk device file name
#  - ${val[1]}: vendor id
#  - ${val[2]}: vendor product
#  - ${val[3]}: revision
#  - ${val[4]}: serial number (first four serial, following two LUN number)
#  - ${val[5]} or ${val[6]}: disk capacity

while read -A val; do
	[[ ${val[0]} == *rdsk* ]] || continue # we did not find a disk here
	
	rdsk=${val[0]}
	dsk=/dev/${val[0]#/dev/r}
	
	size=$(_size $rdsk)
	vg=$(_pv $dsk)
	
	# Check if disk belongs to any VG
	[ -n "$vg" ]  && vg=${vg%* } || vg=NonLVM
	
	# Make sure the size of disk is greater than 0
	if [[ $size -eq 0 ]]; then
		Vg=NonLVM
	else
		Vg=${vg%* }
	fi
	
	# Matching disk device file name against hardware path and
	# fiber channel world wide name

	set -A resArry $(grep " ${rdsk##*/} " $dinfotmp)
				
	[[ ${rdsk##*/} = ${resArry[4]} ]] || { echo; continue; }

	for j in "${fcArry[@]}"; do
		case $j in
			${resArry[0]}:*) myval="$j"; myval=${myval%:*}; fctd=${j##*:} ;;
			*) continue ;;
		esac
	done
	
	[ -n "$myval" ] || myval=":"
	
	serial=${val[4]:1:2} # First 2 digits constitute serial number
	lun=${val[4]:3:3}    # 3 through 6 constitute LUN number
	port=EMC             # There is no Port info provided by inq
	culdev=CLDEV         # There is no CULDEV info provided by inq
		
	# dev file name | vg | size | hardware path | port | lun | culdev | serial | wwn | td
	printf "%9s %15s %10s %15s %4s %3s %5s %8s %20s %9s\n" \
	"${val[0]##*/}" "$Vg" "${size}M" "${myval%:*}" \
	"$port" "$lun" "$culdev" "$serial" "${myval#*:}" "$fctd"
		
	unset resArry
	
done < $inqtmp


# ----------------------------------------------------------------------------
# $Log: disk_on_port.sh,v $
# Revision 1.4  2008/05/19 14:37:21  bmynars
# 1) Corrected message displayed when check against OS release is made.
# 2) Removed 'read only' attribute from PRGDIR global var so it can be properly set during
#     [[ $PRGDIR == /* ]] check.
#
# Revision 1.3  2008/05/19 13:40:24  bmynars
# Added a 'case' statement to prevent the script from running on B.11.3* OS release.  In addition,
# following two improvements were added:
#         - typeset -x PATH=$PATH:/sbin:/usr/sbin:/usr/local/CPR/bin
#         - [[ $PRGDIR == /* ]] || PRGDIR=$(pwd) # Want to make sure we always have here an absolute path
#
# Revision 1.2  2006/06/21 04:31:33  bmynars
# - Increased wait time from 1 to 3 seconds (to reduce number of * displayed)
# - Line of '*'s will break at 80 character mark and continue on a new line
#
# Revision 1.1.1.1.6.1  2006/06/21 03:49:25  bmynars
# Created a branch to include EMC.  Providing everything is working the
# way it is supposed to, I will merge onto the main trunk of the code
# shortly.
#
# Revision 1.1.1.1  2005/10/05 12:32:26  bmynars
# Import
#
# Revision 1.7  2005/09/24 13:34:45  bmynars
# Added card name
#
# Revision 1.6  2005/08/29 21:28:32  bmynars
# Fixed NonLVM issue
#
# Revision 1.5  2005/08/29 13:27:27  bmynars
# Fixed check for existing file
#
# Revision 1.4  2005/08/29 13:24:18  bmynars
# Port to disk matching finished
#
# Revision 1.3  2005/08/28 20:13:37  bmynars
# Added WWN and Hardware Path
#
# Revision 1.2  2005/08/28 12:24:44  bmynars
# Final draft of script
#
# Revision 1.1  2005/08/28 11:16:40  bmynars
# Initial commit
#
# $RCSfile: disk_on_port.sh,v $
# $Source: /ncs/cvsroot/ncsbin/utils/disk_on_port.sh,v $
# $State: Exp $
# ----------------------------------------------------------------------------
