SKDSB_Q=`lpstat -p | grep -i disable | awk '/printer/ {print $2}'`
for var in $SKDSB_Q
do
SKPRNT_STATE=`lpstat -p$var | grep -i disabled|wc -l`

echo "# printer $var `date` : `lpstat -o$var |grep -i "???"`" >> /var/adm/lp/enable_printer_script.log
lpstat -o$var |grep -i "???"
if [ $? -eq 0 ]
then
echo "# printer $var `date` :`lpstat -o$var |head -10`" >> /var/adm/lp/enable_printer_script.log
DEFUNCTJOB=`lpstat -o$var |grep -i $var |head -1 |awk '{print $1}'`
cancel $DEFUNCTJOB
#else
#continue
#echo "# printer $var `date` : `lpstat -p$var | grep -i $var `" >> /var/adm/lp/enable_printer_script.log
#fi

fi
if [ $SKPRNT_STATE -ne 0 ]
then
echo "# printer $var `date` : `lpstat -p$var | grep -i $var ` " >> /var/adm/lp/enable_printer_script.log
enable $var
echo "# printer $var `date` : `lpstat -p$var | grep -i $var `" >> /var/adm/lp/enable_printer_script.log
fi

done

find /var/spool/lp/request/  -xdev -type f -mtime +30 -exec ls -ltr {} \; >/tmp/queuelistforremoval.txt
cat /tmp/queuelistforremoval.txt |grep -vE "remotesending|sendingstatus|cancel" |awk '{print $9 }' |while read i
do
rm $i
done

exit

