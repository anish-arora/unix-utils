#!/usr/bin/sh
#
## 03/11/98 - cbreisch - Initial create for HP.
#
# $Revision: 1.3 $
# $Date: 2010/09/15 15:14:04 $
# $Header: /ncs/cvsroot/ncsbin/utils/logmaint.sh,v 1.3 2010/09/15 15:14:04 pmertens Exp $
# $Id: logmaint.sh,v 1.3 2010/09/15 15:14:04 pmertens Exp $
# $Locker:  $
# History: Check the bottom of the file for revision history
# ----------------------------------------------------------------------------

typeset -x PRGNAME=${0##*/}
typeset -x PRGDIR=${0%/*}

[[ $PRGDIR = . ]] && PRGDIR=$(pwd)

typeset -rx PATH=$PATH:/usr/bin:/usr/sbin:/usr/local/bin

# To make sure we do not have to create another process to cleanup
# just cleaned up files in the future, date stamp below will only
# have month and day numeric values letting it self clean up after
# 365 days.

date=$(date +'%m%d')
typeset logpath=/var/adm/log_archive
typeset gzip=$(which gzip)

[ -x "$gzip" ] || gzip=$(whereis -b gzip | awk '{ print $NF}')

function _note {
	echo " ** $*"
}

function do_log {
	typeset logfile=$1
	typeset archfile=${1##*/}

	_note "$PRGNAME: archiving [$logfile]: \c"

	if [[ -s $logfile ]]; then
		cp -p $logfile $logpath/${archfile}_${date} && {
			echo "[  OK  ]"
			> $logfile

			if [ -z "$gzip" ]; then
				echo "  -- cannot compress the file (cannot find gzip)"
			else
				_note "Compressing [${archfile}_${date}]: \c"
				$gzip $logpath/${archfile}_${date} && echo "[  OK  ]" || echo "[FAILED]"
			fi
		} || {
			echo "[FAILED]"
			_note "$PRGNAME ($LINENO): could not archive [$logfile]"
		}
	else
		echo "[  NA  ]"
	fi
}

function do_monthly {
	typeset i

	doit[0]=/var/adm/wtmp
	doit[1]=/var/adm/btmp
	doit[2]=/var/adm/ptydaemonlog
	doit[3]=/var/adm/vtdaemonlog
	doit[4]=/etc/shutdownlog
	doit[5]=/var/sam/log/samlog
	doit[6]=/var/adm/syslog/mail.log
	doit[7]=/var/adm/rootTTYcheck.log
	doit[8]=/var/adm/rpc.statd.log
	doit[9]=/var/adm/sulog
	doit[10]=/var/adm/sw/swagent.log
	doit[11]=/var/adm/sw/swagentd.log
	doit[12]=/var/adm/sw/swconfig.log
	doit[13]=/var/adm/sw/swinstall.log
	doit[14]=/var/adm/sw/swmodify.log
	doit[15]=/var/adm/wtmps
	doit[16]=/var/adm/btmps

	for i in ${doit[@]}; do
		do_log $i
	done
}

function do_weekly {
	typeset i

	doit[0]=/var/adm/cron/log
	doit[1]=/var/adm/lp/log
	doit[2]=/var/adm/syslog/syslog.log

	for i in ${doit[@]}; do
		case $i in
			*syslog*)
				do_log $i
				logger Syslog archived to $logpath/${i##*/}_${date}
				logger Syslog restarted at $(date)
			;;
			*) do_log $i ;;
		esac
	done
}

# ------------------------------------------------------------------------------
#                    End of functions. Start of code.
# ------------------------------------------------------------------------------

# Sanity checks
if [[ ! -d $logpath ]]; then
	echo "$PRGNAME: creating missing [$logpath]: \c"
	mkdir -p $logpath && {
		echo "[  OK  ]"
	} || {
		echo "[FAILED]"
		mailx -s "$PRGNAME ($LINENO) could not create [$logpath]" root < /dev/null
		exit 1
	}
fi

case $1 in
  weekly ) do_weekly  ;;
 monthly ) do_monthly ;;
       * ) echo "Usage: $PRGNAME < weekly | monthly >"
           exit         ;;
esac

# ----------------------------------------------------------------------------
# $Log: logmaint.sh,v $
# Revision 1.3  2010/09/15 15:14:04  pmertens
# Fixed bug in locating gzip-executable [replaced -n test with -x]
#
# Revision 1.2  2009/01/16 21:24:28  bmynars
# Added compressing capabilities to archived log files and added wtmps
# and btmps files for archiving.
#
# Revision 1.1  2009/01/16 13:32:38  bmynars
# Copyied over from /usr/local/bin.  /opt/ncsbin/utils is a new
# hoem for these two scripts
#
# $RCSfile: logmaint.sh,v $
# $Source: /ncs/cvsroot/ncsbin/utils/logmaint.sh,v $
# $State: Exp $
# ----------------------------------------------------------------------------


