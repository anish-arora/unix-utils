#!/usr/bin/ksh
# Autor: Bill Gripp
#
# $Revision: 1.3 $
# $Date: 2007/01/04 01:55:22 $
# $Header: /ncs/cvsroot/ncsbin/utils/PathBal.sh,v 1.3 2007/01/04 01:55:22 bmynars Exp $
# $Id: PathBal.sh,v 1.3 2007/01/04 01:55:22 bmynars Exp $
# $Locker:  $
# History: Check the bottom of the file for revision history
# ----------------------------------------------------------------------------

typeset -x PRGNAME=${0##*/}
typeset -x PRGDIR=${0%/*}

if [ $# -ne 1 ]; then
	echo "Usage: $PRGNAME <vg>"
	exit 1
fi

function Balance
{
  vgreduce  $1  $2 $4 $5
  vgextend  $1  $2
  vgreduce  $1  $3
  vgextend  $1  $3 $4 $5
}

#
# Determine paths for PVs
#
VG="$1"
vgdisplay -v $VG|grep "PV Name" | awk '{print $3," ",$4}' | while read Disk
do
  if [ "`echo $Disk|awk '{print $2}'`" != "Alternate" ]
  then
    echo $Line >> $VG.disks
    Line="$Disk"
  else
    Disk="`echo $Disk|awk '{print $1}'`"
    Line="$Line  $Disk"
  fi
done
echo $Line >> $VG.disks

#
# Arrange PV links in ascending order
#
more $VG.disks | while read Line
do
  for Num in 1 2 3 4
  do
    Disk="`echo $Line|cut -f $Num -d\ `"
    echo $Disk >> Disk.tmp1
  done
  sort Disk.tmp1 > Disk.tmp2
  rm Disk.tmp1
  DiskLine=""
  more Disk.tmp2 | while read TmpLine
  do
   DiskLine="$DiskLine $TmpLine"
  done
  rm Disk.tmp2
  echo $DiskLine >> DiskBalance.out
done
grep dev DiskBalance.out|sort > PathBalance.out
rm $VG.disks
rm DiskBalance.out

awk '{ print NR,NF,(NR - 1) % NF + 1,$0 }' PathBalance.out | while read Line
do
  Stripe="`echo $Line|awk '{print $3}'`"
  Path1="`echo $Line|awk '{print $4}'`"
  Path2="`echo $Line|awk '{print $5}'`"
  Path3="`echo $Line|awk '{print $6}'`"
  Path4="`echo $Line|awk '{print $7}'`"

  case $Stripe in
    1) Balance $VG $Path1 $Path2 $Path3 $Path4
    ;;
    2) Balance $VG $Path2 $Path3 $Path4 $Path1
    ;;
    3) Balance $VG $Path3 $Path4 $Path1 $Path2
    ;;
    4) Balance $VG $Path4 $Path1 $Path2 $Path3
    ;;
    *) echo "--- Invalid Stripe ---"
    ;;
  esac
done

rm PathBalance.out

# ----------------------------------------------------------------------------
# $Log: PathBal.sh,v $
# Revision 1.3  2007/01/04 01:55:22  bmynars
# Reverted back to original version.  Added 'ksh' shebang and a check
# for an argument (volume group required).
#
#
# $RCSfile: PathBal.sh,v $
# $Source: /ncs/cvsroot/ncsbin/utils/PathBal.sh,v $
# $State: Exp $
# ----------------------------------------------------------------------------
