#/usr/bin/sh
# variables
OLDREQ=/var/spool/lp/request.old

function USAGE {
    echo "lprequeue.sh requires that the OLDREQ ($OLDREQ) exists"
    echo "For more information read the Knowledge Article \"How to handle lp spooler problems\""
    exit 1
}

############# MAIN ############
cd $OLDREQ || USAGE

for QUEUE in *
do
	DIR=${OLDREQ}/${QUEUE}
	cd ${DIR}
	for i in $(find . -mtime -1 -name 'c*')
	do
		[[ $i != +(./c*) ]] && continue
		name=${i#./c}
		C=c${name}
		D=d${name}
		[[ ! -f $D ]] && { echo $D does not exist 
				   continue
				   }
# dbg		grep "^O" $C
# dbg		echo $i $name $D
		OPT=""
		for option in $(grep "^O" $C)
		do 
			case $option in
     				"O") continue ;;
      				O*) OPT="${OPT} -o${option#O}" ;;
      				-*) OPT="${OPT} ${option#O}" ;;   # the last #O might be a bug
      				*)  OPT="${OPT} -o${option#O}" ;; # the last #O might be a bug
      			esac
		done
		cat - <<-EOT
		about to:
		lp -d${QUEUE} $OPT ${DIR}/${D}
		mv ${C} REQUEUED.${C}
		mv ${D} REQUEUED.${D}
		EOT
		lp -d${QUEUE} $OPT ${DIR}/${D}
		mv ${C} REQUEUED.${C}
		mv ${D} REQUEUED.${D}
#		echo "press enter to continue \n"
#		read a
		sleep 1
	done
done
