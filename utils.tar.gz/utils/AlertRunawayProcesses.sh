#!/usr/bin/ksh
# Author: Peter Mertens <pmertens@its.jnj.com>
#
# $Revision: 1.5 $
# $Date: 2010/01/29 12:31:25 $
# $Header: /ncs/cvsroot/ncsbin/utils/AlertRunawayProcesses.sh,v 1.5 2010/01/29 12:31:25 pmertens Exp $
# $Id: AlertRunawayProcesses.sh,v 1.5 2010/01/29 12:31:25 pmertens Exp $
# $Locker:  $
# History: Check the bottom of the file for revision history
# ----------------------------------------------------------------------------
#
# PURPOSE: alert runaway-processes (OVO, syslog, mail, custom-action)
# METHOD:
#  the script works together with Measureware's perfalarm.  (see: 
#  /var/opt/alarmdef, section 'Detect runaway processes'
#  perfalarm is adding a record to /var/opt/perf/runawayprocs for 
#  for each process that using no IO and high CPU. 
#  This script will then analyse regularly if the processes are running 
#  longer than the threshold defined in $1
# RUN:
#  This script should be scheduled a few times per hour (e.g. every 20 mins).
# ----------------------------------------------------------------------------
typeset -r opcmsg=/opt/OV/bin/OpC/opcmsg
typeset -r host=$(uname -n)
typeset -r tmp_suffix=$$.$(date +%Y%m%d%H%M%S).tmp
typeset -r runaway_file=/var/opt/perf/runawayprocs.track
typeset -r runaway_tmp1=/var/tmp/runawayprocs.$$.$tmp_suffix.1
typeset -r runaway_tmp2=/var/tmp/runawayprocs.$$.$tmp_suffix.2
typeset -r runaway_sort=/var/tmp/runawayprocs.$$.$tmp_suffix.sort
typeset -r exclude_list=/var/opt/perf/runaways.exc
typeset -r parameter_file=/var/opt/ITS/PerfAlertParms
typeset -r TYPE=PROCESS # this is the type used in the previous version

typeset -i count1=0
typeset -i count2=0
typeset -i Threshold=3600
typeset -i SkipOldRecords
typeset    SkipThisProcess="FALSE"
typeset    Now # current date-time in Epoch
typeset    ExcludeListCheck="TRUE"

# to improve readability define alias for below perl-script
# the perl-script converts a date-time into seconds from 1/1/1970
alias -x ConvertToEpoch="/opt/perl/bin/perl -e 'use Time::Local;
 (\$mm, \$dd, \$yyyy) = split(/\//, \$ARGV[0]);
 (\$hh, \$mi, \$ss  ) = split(/:/,  \$ARGV[1]);
 printf \"%d\n\", timegm(\$ss,\$mi,\$hh,\$dd,\$mm-1,\$yyyy)'"

#
# -- INIT ----------------------------------------------------------------------
#
# ------------------------------------------------------------------------------
#                                   Argument Handling
# ------------------------------------------------------------------------------

if [ $# -gt 0 ]
then 
	Threshold=$1 # override default threshold of 3600
fi

Now=$(ConvertToEpoch $(date '+%m/%d/%Y %H:%N:%S'))
(( Buffer = 20 * 60 )) # additional buffer of 20 minutes (cronjob shoud run every 20 min)
(( SkipOldRecords = $Now - $Threshold - $Buffer ))

if [ -r $parameter_file ]
then
	. $parameter_file
fi

#
# -- FUNCTIONS ----------------------------------------------------------------
#

function CleanUp # ------------------------------------------------------------
{
rm -f $runaway_tmp1
rm -f $runaway_tmp2
rm -f $runaway_sort
return
}

function run_action  # --------------------------------------------------------
{
if [ -x "$ALERT_ACTION" ]
then
	ps -ef | grep "$ALERT_ACTION" | grep -v grep | grep -q "$ALERT_ACTION"
	if [ $? -eq 1 ]               #Avoid duplicate run of same scripts.
	then
		$ALERT_ACTION PROCESS $*
	fi
fi
}
	      
function RaiseAlert  # --------------------------------------------------------
{
# $1 = pid
# $2 = process-name 
# $3 = user
# $4 = cpu 
# $5 = phys-io 
# $6 = disk-log-io 
# $7 = delta (=minutes of high cpu usage without change in io)

(( MINS = $7 / 60 ))

echo "Raising MAJOR alert for PID=$1 Name=$2 User=$3 CPU Util=$4 CUM IO=$5 for $MINS Minutes" 1>&2

# Send OVO alert

$opcmsg severity=major application=alarmgen msg_grp=Performance object="PROC-$1" \
       msg_text="Runaway Process Alert - High CPU usage with no IO for ~${MINS} mins.\
       - PID=$1 PROCESS=$2 USER=$3 CPU_USAGE=$4 CUMULATIVE_IO=$5+$6"

# Log syslog entry

logger -p daemon.alert -i "PerfAlert-MAJOR $TYPE Alert - PID=$1 Name=$2 User=$3 CPU Util=$4 CUM IO=$5+$6"

# If requested then also send MAIL alert

if [ -n "$PROCESS_ALERT_MAIL" ]
then
	echo "The following may be a runaway process, high cpu usage with no io for about ${MINS} minutes."\
     		"\n\tPID=$1\n\tName=$2\n\tUser=$3\n\tCPU Util=$4\n\tCUM IO=$5+$6" \
     		| mailx -s "MAJOR Runaway Process alert on $host - $2" $PROCESS_ALERT_MAIL
fi

# If requested then also execute alert ACTION

if [ -n "$PROCESS_ALERT_ACTION" ]
then
	ALERT_ACTION=$PROCESS_ALERT_ACTION
	run_action MAJOR $TYPE $*
fi

return
}

function RemoveEntry  # --------------------------------------------------------
{
# $1 = pid
# $2 = process-name 
# $3 = user
grep -v "^$1 $2 $3 " $runaway_tmp1 > $runaway_tmp2
mv $runaway_tmp2 $runaway_tmp1

return  
}

function PidStillRunning # ----------------------------------------------------
                         # check if this pid is still running 
                         # with same user and command
{
# $1 = pid
# $2 = process-name (matches first 16 bytes of comm field in ps output)
# $3 = user
typeset psUser

# set UNIX95 to invoke XPG4 behaviour of ps

psUser=$(UNIX95= ps -o comm,user -p $1|grep ^$2|awk '{print $2}' | head -1)
if [ -n "${psUser}" ] && [ "${psUser}" = $3 ]
then echo "TRUE";
else echo "FALSE";
     echo "Process $1 $2 $3 is not running anymore." 1>&2
fi

return
}

function PidOnExcludeList # ----------------------------------------------------
                          # check if this new process is on the exclude list
{
# $1 = process-name 
# $2 = user
typeset result
typeset -i rc

result="FALSE"

if [ $ExcludeListCheck = "TRUE" ]
then
	awk -v name=$1 -v user=$2 \
		'BEGIN {rc=0} \
		/^#/ { next } \
		name ~ $1  && ($2 == "" || user ~ $2) {rc=5} \
		END {exit rc}' $exclude_list
	rc=$?
	if [ $rc -eq 5 ] # process [user] matches exclude list
	then result="TRUE"
	     echo "Process $1 $2 matches exclude_list: $exclude_list" 1>&2
	elif [ $rc -eq 2 ] # some syntax error in exclude list
	then $opcmsg severity=major application=alarmgen msg_grp=Performance object="SYNTAX" \
      		 msg_text="Runaway Process Monitoring - Syntax error in $exclude_list." 
	     logger -p daemon.alert -i "PerfAlert-MAJOR $TYPE Alert - Syntax error in $exclude_list."
	     echo "Syntax error in $exclude_list. Please correct." 1>&2
	     result="FALSE"
	else # no match
	     result="FALSE"
	fi
fi
echo $result

return
}

#
# -- MAIN ----------------------------------------------------------------------
#

echo "$(date): Script $0 started: $*" 1>&2

# ------------------------------------------------------------------------------
# convert date time to Epoch time for sorting and arithmetic
# remove any entry that's older than 'Now' - Threshold
# ------------------------------------------------------------------------------

cat $runaway_file | while read pid comm user date time cpu pio lio
do
	if [ ! -n "$lio" ]
	then
		$opcmsg severity=major application=alarmgen msg_grp=Performance object="SYNTAX" \
			msg_text="Runaway Process Monitoring - Invalid format in $runaway_file." 
		logger -p daemon.alert -i "PerfAlert-MAJOR $TYPE Alert - Invalid format in $runaway_file."
		echo "Invalid format in $runaway_file. Please correct." 1>&2
		CleanUp
		exit
	fi

	(( count1=$count1+1 ))
	SECS=$(ConvertToEpoch $date $time) 
	if [ $SECS -lt $SkipOldRecords ] ; then continue; fi
	echo $pid $comm $user $SECS $date $time $cpu $pio $lio
done > $runaway_tmp1

# ------------------------------------------------------------------------------
# check for each 'pid comm user'-combination what's the longest timeframe 
# where IO didn't change
# ------------------------------------------------------------------------------

if [ -r $runaway_tmp1 ] # check if there are processes 
then
	# first_<var> shows the values for the first record read for a specific process.
	first_pid=-1
	first_comm=""
	first_user=""
	first_secs=0
	first_cpu=0
	first_pio=0
	first_lio=0

	if [ -s $exclude_list ] # check if there's a exclude list that needs to be checked 
	then ExcludeListCheck="TRUE"
	else ExcludeListCheck="FALSE"
	fi

	sort -r $runaway_tmp1 > $runaway_sort # use another temp file because $runaway_tmp1 will be updated while processing

	cat $runaway_sort | while read pid comm user secs date time cpu pio lio
	do
		(( count2=$count2+1 ))

		# check if a new process has been read
	
		if [ $first_pid -ne $pid ] || [ "$first_comm" != "$comm" ] || [ "$first_user" != "$user" ]
		then
			SkipThisProcess="FALSE"
			first_pid=$pid
			first_comm=$comm
			first_user=$user
			first_secs=$secs
			first_cpu=$cpu  
			first_pio=$pio  
			first_lio=$lio  

			# check whether this process is still running
			# or whether the process is on the exclude list
			if [ $(PidStillRunning $pid $comm $user) = "FALSE" ] ||
			   [ $(PidOnExcludeList $comm $user)     = "TRUE" ]
			then SkipThisProcess="TRUE"
		     	     RemoveEntry $pid $comm $user
			fi
		fi

		if [ $SkipThisProcess = "TRUE" ] 
		then continue # skip all remaining records for this process
		fi

		# check if io-consumption is still the same

		if [ $pio -ne $first_pio ] && [ $lio -ne $first_lio ]
		then	# change in io --> skip the process but do NOT RemoveEntry because
			# the newer records might be the start of the runaway-loop
			echo "Change in IO - process $pid-$comm will not be alerted." 1>&2
			SkipThisProcess="TRUE" 
		else 	# no change in io consumption
			# raise alert if time-difference between this record and first records exceeds threshold
			# and skip all remaining records for this process
			(( delta = $first_secs - $secs ))
			if [ $delta -ge $Threshold ]
			then RaiseAlert  $first_pid $first_comm $first_user $first_cpu $first_pio $first_lio $delta
		     	     RemoveEntry $first_pid $first_comm $first_user
			     SkipThisProcess="TRUE" 
			fi
		fi
	done

	# runaway_tmp1 now contains the recent runaway candidates that have not yet been alerted
	# remove the 4th column with the epoch-date and move back into place

	awk '{print $1, $2, $3, $5, $6, $7, $8, $9}' $runaway_tmp1 > $runaway_file
fi

CleanUp

(( count1=$count1-$count2 ))
echo "$(date): ${count1} lines purged." 1>&2
echo "$(date): ${count2} lines processed." 1>&2
echo "$(date): Script $0 ended" 1>&2

exit

# ----------------------------------------------------------------------------
# $Log: AlertRunawayProcesses.sh,v $
# Revision 1.5  2010/01/29 12:31:25  pmertens
# - bugfix: handling of Threshold variable (value was used before it got
#   overwritten by $1
# - small technical improvement in ConvertToEpoch
#
# Revision 1.4  2009/08/03 20:24:10  pmertens
# The script will now also send a message to syslog in case of syntax-error in exclude-list or in case of format error in runawayprocs.track file.  In previous version, only a OVO-alert was raised.
# The TYPE variable is now also set to PROCESS, just like in the early versions.
#
# Revision 1.3  2009/07/30 15:09:29  pmertens
# Log a count for purged records from the tracking file.
#
# Revision 1.2  2009/07/24 16:31:33  pmertens
# Bugfix:
# - checking on IO didn't work because alarmdef wasn't storing the _CUM values for IO.
# Improvements:
# - allowed pattern matching for exclude file
#
# Revision 1.1  2009/06/29 17:48:33  pmertens
# Runaway-process monitor.
# Works together with a specifc version of /var/opt/perf/alarmdef
# and should be scheduled by cron.
#
#
# $RCSfile: AlertRunawayProcesses.sh,v $
# $Source: /ncs/cvsroot/ncsbin/utils/AlertRunawayProcesses.sh,v $
# $State: Exp $
# ----------------------------------------------------------------------------
