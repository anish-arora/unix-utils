#!/usr/dt/bin/dtksh
# Bolek Mynarski <bmynars@its.jnj.com>
#
# $Revision: 1.3 $
# $Date: 2008/02/23 02:47:16 $
# $Header: /ncs/cvsroot/ncsbin/utils/ldapCNT.sh,v 1.3 2008/02/23 02:47:16 bmynars Exp $
# $Id: ldapCNT.sh,v 1.3 2008/02/23 02:47:16 bmynars Exp $
# $Locker:  $
# History: Check the bottom of the file for revision history
# ----------------------------------------------------------------------------

typeset -x PRGNAME=${0##*/}
typeset -x PRGDIR=${0%/*}
typeset -x PATH=$PATH
typeset lhost=$(uname -n)

[[ $PRGDIR != /* ]] && PRGDIR=$(pwd)

# ------------------------------------------------------------------------------
#                                FUNCTIONS
# ------------------------------------------------------------------------------

function _note {
	print -- " ** $*"
}

function _getZones {
	typeset LINE zone
	eval $lsearch $ldaparg $ldapstr -s one cn |\
	while read LINE; do
		[[ $LINE == dn* ]] || continue
		zone="${LINE%%,*}"; zone="${zone#* }"

		[[ ${zone#*=}  == Global* ]] && continue
		print -- "$zone"
	done
}

function _getComputers {
	typeset i REC
	_getZones |\
	while read i; do
		eval $lsearch $ldaparg CN=Computers,"\"$i\"",$ldapstr -s one cn |\
		while read REC; do
			[[ $REC == dn* ]] || continue
			comp="${REC%%,*}"; comp="${comp#*=}"

			[[ $comp == zone_* ]] && comp="computer.place.holder"
			print -- "${i#*=},$comp"
		done
	done
}

function _getZoneUsers {
	typeset i REC user
	_getZones |\
	while read i; do
		eval $lsearch $ldaparg CN=Users,"\"$i\"",$ldapstr -s one cn |\
		while read REC; do
			[[ $REC == dn* ]] || continue
			user="${REC%%,*}"; user=${user#*=}
			print -- "${i#*=},$user"
		done
	done
}

function _msg {
	cat <<-eof
    USAGE:
          $PRGNAME -c | -u | -z [-h LDAPHOST] [-p LDAPPORT]

    SYNOPSIS:
          $PRGNAME is a simple front end wrapper for ldapsearch command
          line utility that takes away the complexity involved in forming
          appropriately structured LDAP query syntax.

          This script is geared purely for JNJ Centrify environment but
          it can be easily adapted for other uses.

          -c   Generate a list of computers currently entered into AD.
          -u   Generate a list of users per existing zone (except Global zone).
          -z   Generate a list of zones currently entered into AD.
          -h LDAPHOST  This is optional.  It will allow you to change
                       the name of LDAP Host on the fly if needed.
          -p LDAPPORT  This is optional.  It will allow you to change
                       LDAP port number on the fly.


           For the script to be meaningful, at least -c or -z should be
           used.

    EXAMPLES:
          $PRGNAME -c
          $PRGNAME -u
          $PRGNAME -c -z
          $PRGNAME -c -z -h my.ldap.com
          $PRGNAME -z -c -h my.ldap.com -p 2389
	eof
}

# ------------------------------------------------------------------------------
#                                SANITY CHECKS
# ------------------------------------------------------------------------------

# Testing for correctshell release
if echo ${.sh.version} > /dev/null 2>&1; then
	:
else
	echo
	echo "$SHELL is incompatible with KSH93 features.  Exiting."
	exit 1
fi

typeset lsearch=$(whence ldapsearch)

if [ -z "$lsearch" ]; then
	_note "$PRGNAME: ldapsearch is missing."
	exit 1
fi

# ------------------------------------------------------------------------------
#                                     VARS
# ------------------------------------------------------------------------------

# Two vars below are our default values.  They can be overwritten
# by the user on the command line.
typeset ldapHost="jnj.com"
typeset ldapPort="389"
typeset zone comp

# ------------------------------------------------------------------------------
#                                   MAIN BODY
# ------------------------------------------------------------------------------

#typeset -ft _getZones
#typeset -ft _getComputers

typeset -i c=u=z=0

if [ $# -gt 0 ]; then
	while getopts ":h:p:czu" opt; do
		case $opt in
			h) ldapHost=$OPTARG ;;
			p) ldapPort=$OPTARG ;;
			c) c=1 ;;
			u) u=1 ;;
			z) z=1 ;;
			:) _note "$PRGNAME ($LINENO): $OPTARG requires a value.\n"; exit 2 ;;
			\?) _note "$PRGNAME ($LINENO): unknown option ($OPTARG).\n"; exit 2 ;;
		esac
	done
	shift $(( OPTIND - 1 ))
else
	_msg
fi

typeset ldaparg="-x -P 3 -h $ldapHost -p $ldapPort -b"
typeset ldapstr="CN=Zones,CN=Centrify,CN='Program Data',DC=jnj,DC=com"

(( c == 1 )) && _getComputers
(( u == 1 )) && _getZoneUsers
(( z == 1 )) && _getZones

# ----------------------------------------------------------------------------
# $Log: ldapCNT.sh,v $
# Revision 1.3  2008/02/23 02:47:16  bmynars
# Added check for ldapsearch
#
# Revision 1.2  2008/02/21 00:49:46  bmynars
# Updated variables in functions
#
# Revision 1.1  2008/02/17 04:26:10  bmynars
# Initial commit
#
#
# $RCSfile: ldapCNT.sh,v $
# $Source: /ncs/cvsroot/ncsbin/utils/ldapCNT.sh,v $
# $State: Exp $
# ----------------------------------------------------------------------------
