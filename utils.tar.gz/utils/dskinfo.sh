#!/usr/dt/bin/dtksh
# Author: Boleslaw Mynarski <bmynars@ncsus.jnj.com>
#
# $Revision: 1.4 $
# $Date: 2008/05/19 14:37:21 $
# $Header: /ncs/cvsroot/ncsbin/utils/dskinfo.sh,v 1.4 2008/05/19 14:37:21 bmynars Exp $ 
# $Id: dskinfo.sh,v 1.4 2008/05/19 14:37:21 bmynars Exp $
# $Locker:  $
# History: Check the bottom of the file for revision history
# ----------------------------------------------------------------------------

typeset -rx PRGNAME=${0##*/}
typeset -x PRGDIR=${0%/*}
typeset -x PATH=$PATH:/sbin:/usr/sbin:/usr/local/CPR/bin

[[ $PRGDIR == /* ]] || PRGDIR=$(pwd) # Want to make sure we always have here an absolute path

typeset -r osVer=$(uname -r)

# Purpose of this script is to provide a disk information by splitting
# disk hardware path into:
#     1. Host Bus Adapter
#     2. Decimal Domain ID
#     3. Decimal area which will be translated into the card and port

# ------------------------------------------------------------------------------
#                                 Local settings
# ------------------------------------------------------------------------------

# Convert to x base (16, 2, 10, etc)
function _chgbase {	
	echo "obase=$1; $2" | bc
}

# Obtain disk device file name
function _getDisk {
	$ioscan -funH $1 | awk '/\/rdsk\// { print $2 }'
}

function _diskInfo {
	# Vars below are used only to make it easier
	# to identify elements in our diskinfo array
	
	junk=0
	vendor=1
	prdid=2
	type=3
	size=4
	byteps=5
	typeset -i i=0
	
	/usr/sbin/diskinfo $1 |\
	
	while read LINE; do
		dskarry[$i]=$(echo $LINE | cut -d: -f2); dskarry[$i]="${dskarry[$i]# }"
		[ $i -eq $size ] && sz="${dskarry[$i]%% *}"
		(( i+=1 ))
	done
	
}

function _ln {
	typeset -i count=0
	while [ $count -lt ${1:-10} ]; do
		echo "-\c"
		count=$(($count+1))
	done
}

typeset -r ioscan=/usr/sbin/ioscan
typeset -i line
typeset hba ddi cardprt card port fdevice dskspace
typeset -F2 totalspace=0.00
set -A dskarry

# ------------------------------------------------------------------------------
#                                  Main Body
# ------------------------------------------------------------------------------

# This script is no longer required on B.11.3*.

case $osVer in
	B.11.3*)
		cat <<-eof

		$PRGNAME: this script is deprecated on $osVer.  Please, do not use it.

		eof

		exit
	;;
esac




if [ $(whoami) != 'root' ]; then
	printf "  ** Only <root> can run this script...\n\n"
	exit 1
fi

printf "%15s %3s %3s %3s %10s %10s %16s %15s\n" \
"$(_ln 15)" "---" "---" "---" "$(_ln 10)" "$(_ln 10)" "$(_ln 16)" "$(_ln 15)"

printf "%15s %3s %3s %3s %10s %10s %16s %15s\n" \
"HBA" "DDI" \
"Crd" "Prt" \
"DskFile" "Size (Gb)" \
"Vendor" "Product Id"

printf "%15s %3s %3s %3s %10s %10s %16s %15s\n" \
"$(_ln 15)" "---" "---" "---" "$(_ln 10)" "$(_ln 10)" "$(_ln 16)" "$(_ln 15)"

# Main loop in which we query hardware for its information

$ioscan -kfC disk |\
while read class intf hwpath drvier state hwtype description; do

	(( line+=1 )); [ $line -le 2 ] && continue
	
	hba=${hwpath%%.*}           # Obtain HBA address
	fdevice=$(_getDisk $hwpath) # Get device file name
	
	if [ ! -n "$fdevice" ]; then
		printf "%80s\n"   "** NO Device file --> $($ioscan -kH $hwpath | tail -1 | sed 's/     / /g') <-- **"
		continue		
	fi
	
	_diskInfo $fdevice          # Obtain disk device file

	hwpath=${hwpath#*.}         # Remove HBA from DDI and CardPort
	ddi=$(echo $hwpath | cut -d. -f1)
	
	# Convert port number from decimal to hex
	cardport=$(echo $hwpath | cut -d. -f2)
	
	if [ ${#cardport} -eq 1 ]; then
		# If cardport number is single digit, there is no
		# sense in trying to converted to base 16
		
		card=0
		port=$cardport
	else
		#cardport=$(_chgbase 16 $cardport)
		
		# To speed up processing we will use built in
		# printf capability of converting numbers between
		# different bases
		
		cardport=$(printf "%X" "$cardport")
		card=$(echo $cardport | cut -c1)
		port=$(echo $cardport | cut -c2)
	fi
	
	# Disk space calculations
	
	typeset -F2 Sz=$sz
	typeset -F2 dskspace=$(( $Sz / 1024 / 1024 ))
	typeset -F2 totalspace=$(( $totalspace + $dskspace ))
		
	printf "%15s %3s %3s %3s %10s %10.2f %16s %15s\n" \
	"$hba" "$ddi" "$card" "${port:-0}" "${fdevice##*/}" \
	"$dskspace" "${dskarry[1]}" "${dskarry[2]}"
	
done

printf "%38s %10s\n" "$(_ln 38)" "$(_ln 10)"
printf "%38s %10.2f\n" "Total raw space:" "${totalspace}"

# A little explanation in the form of 'legend' so the person
# looking at the output knows what s/he looks at

_ln 25
printf "\n%8s\n" "Legend:"
printf "%8s %25-s\n" "HBA " "- Host Bus Adapter"
printf "%8s %25-s\n" "DDI " "- Decimal Domain ID"
printf "%8s %25-s\n" "Crd " "- Card"
printf "%8s %25-s\n" "Prt " "- Port"

# ----------------------------------------------------------------------------
# $Log: dskinfo.sh,v $
# Revision 1.4  2008/05/19 14:37:21  bmynars
# 1) Corrected message displayed when check against OS release is made.
# 2) Removed 'read only' attribute from PRGDIR global var so it can be properly set during
#     [[ $PRGDIR == /* ]] check.
#
# Revision 1.3  2008/05/19 13:34:35  bmynars
# Added a 'case' statement to prevent the script from running on B.11.3* OS release.  In addition,
# following two improvements were added:
# 	- typeset -x PATH=$PATH:/sbin:/usr/sbin:/usr/local/CPR/bin
# 	- [[ $PRGDIR == /* ]] || PRGDIR=$(pwd) # Want to make sure we always have here an absolute path
#
# Revision 1.2  2006/03/12 13:50:38  bmynars
# Converted extranl call to shell built-in
#
# Revision 1.1.1.1  2005/10/05 12:32:26  bmynars
# Import
#
# Revision 1.1  2004/05/13 02:02:50  bmynars
# Initial commit
#
#
# $RCSfile: dskinfo.sh,v $
# $Source: /ncs/cvsroot/ncsbin/utils/dskinfo.sh,v $
# $State: Exp $
# ----------------------------------------------------------------------------
