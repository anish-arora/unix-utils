#! /usr/bin/ksh
# $Header: /ncs/cvsroot/ncsbin/utils/PerfAlert.sh,v 1.8 2010/09/16 10:45:13 pmertens Exp $ 
# $Id: PerfAlert.sh,v 1.8 2010/09/16 10:45:13 pmertens Exp $
# $Locker:  $
# History: Check the bottom of the file for revision history
# ----------------------------------------------------------------------------
#
#This script will be run by alarmgen, during alert situations, with different
#set of arguments, depending upon the type of the alert. This script will 
#handle those argument accordingly. It will source the parameter file defined
#in PARAMETER_FILE variable below. The action of this script, depends upon
#the values assigend to various parameters in the parameter file. In general,
#this script will generate email and/or run local scripts, based on the parameter
#values. See the parameter file for instruction on how to set the parameters.
#
#
PARAMETER_FILE=/var/opt/ITS/PerfAlertParms
PATH=/usr/xpg4/bin:/usr/bin/:/usr/sbin:/opt/OV/bin/OpC:/opt/perf/bin
export PATH PARAMETER_FILE 

if [ -r $PARAMETER_FILE ]
then
. $PARAMETER_FILE
fi

TYPE=$1
shift
HOST=`uname -n`

run_action()
{
 if [ -x "$ALERT_ACTION" ]
 then
  ps -ef | grep "$ALERT_ACTION" | grep -v grep | grep -q "$ALERT_ACTION"
  if [ $? -eq 1 ]		#Avoid duplicate run of same scripts.
  then
   $ALERT_ACTION $TYPE $*
  fi
 fi
}

case $TYPE in
#=============================CPU=======================================
CPU )
 logger -p daemon.alert -i "PerfAlert-$1 $TYPE Alert - Util=$2 % Queue =$3"
 if [ -n "$CPU_ALERT_MAIL" ]
 then
  echo "\tMINOR: High CPU usage for 20 mins or High CPU Usage with queue for 5 mins.\n\
  \tMAJOR: High CPU Usage with queue for 15 mins.\n\
  \t\tUtilization = $2 %\n\t\tQueue = $3" | \
  mailx -s "$1 CPU ALERT on $HOST - Util $2 Q $3 " $CPU_ALERT_MAIL
 fi ;
 if [ -n "$CPU_ALERT_ACTION" ]
 then
  ALERT_ACTION=$CPU_ALERT_ACTION
  run_action $*
 fi;;

#=============================MEMORY=======================================
MEMORY )
 logger -p daemon.alert -i "PerfAlert-$1 $TYPE Alert - Probability=$2"
 if [ -n "$MEMORY_ALERT_MAIL" ]
 then
  echo "\tMINOR: High Memory usage for 10 mins.\n\
  \tMAJOR: High Memory usage + paging/swapping activity for 10 mins.\n\
  \t\tMemory bottlenect Probability $2" | \
  mailx -s "$1 Memory Bottleneck ALERT on $HOST - Probability $2 " $MEMORY_ALERT_MAIL
 fi;
 if [ -n "$MEMORY_ALERT_ACTION" ]
 then
  ALERT_ACTION=$MEMORY_ALERT_ACTION
  run_action $*
 fi;;

#=============================SWAP=======================================
SWAP )
 logger -p daemon.alert -i "PerfAlert-$1 $TYPE Alert - Usage=$2 %"
 if [ -n "$SWAP_ALERT_MAIL" ]
 then
  echo "\tMINOR: High Swap usage for 20 mins.\n\
  \tMAJOR: Critically High Swap usage for 10 mins.\n\
  \t\tSwap Usage $2 %" | \
  mailx -s "$1 Swap Usage ALERT on $HOST - Usage $2 %" $SWAP_ALERT_MAIL
 fi;
 if [ -n "$SWAP_ALERT_ACTION" ]
 then
  ALERT_ACTION=$SWAP_ALERT_ACTION
  run_action $*
 fi;;

#=============================IO=======================================
DISK )
 logger -p daemon.alert -i "PerfAlert-$1 $TYPE Alert - Probability=$2 "
 if [ -n "$IO_ALERT_MAIL" ]
 then
  echo "\tMINOR: High IO for 10 mins.\n\
  \t\tIO bottlenect Probability $2" | \
  mailx -s "$1 IO Bottleneck ALERT on $HOST - Probability $2 " $IO_ALERT_MAIL
 fi;
 if [ -n "$IO_ALERT_ACTION" ]
 then
  ALERT_ACTION=$IO_ALERT_ACTION
  run_action $*
 fi;;

#=============================NETWORK=======================================
NETWORK )
 logger -p daemon.alert -i "PerfAlert-$1 $TYPE Alert - Collisions=$2 per min."
 if [ -n "$NETWORK_ALERT_MAIL" ]
 then
  echo "\tMINOR: High Network Collision for 10 mins.\n\
  \tMAJOR: Critically High Network Collision usage for 20 mins.\n\
  \t\tNetwork Collisions $2 per minute" | \
  mailx -s "$1 Network Collision ALERT on $HOST - $2 per minute" $NETWORK_ALERT_MAIL
 fi;
 if [ -n "$NETWORK_ALERT_ACTION" ]
 then
  ALERT_ACTION=$NETWORK_ALERT_ACTION
  run_action $*
 fi;;

#=============================PARAMETER=======================================
FILE_TABLE | FILE_LOCK | PROC_TABLE | SHMEM_TABLE | SEM_TABLE | MSG_TABLE )
 logger -p daemon.alert -i "PerfAlert-$1 $TYPE Alert - Usage=$2 %"
 if [ -n "$PARAMETER_ALERT_MAIL" ]
 then
  echo "\tMINOR: High $TYPE usage for 4 mins.\n\
  \tMAJOR: Critically High $TYPE usage for 4 mins.\n\
  \t\t$TYPE Usage $2 %" | \
  mailx -s "$1 $TYPE Usage ALERT on $HOST - Usage $2 %" $PARAMETER_ALERT_MAIL
 fi;
 if [ -n "$PARAMETER_ALERT_ACTION" ]
 then
  ALERT_ACTION=$PARAMETER_ALERT_ACTION
  run_action $*
 fi;;

#=============================INVALID=======================================
* )
 logger -p daemon.alert -i "PerfAlert- Unknown Alert for $TYPE - $* " ;;

esac

# ----------------------------------------------------------------------------
# $Log: PerfAlert.sh,v $
# Revision 1.8  2010/09/16 10:45:13  pmertens
# Removed the redundant runawayprocess monitoring code.  This has already been
# replaced by AlertRunawayProcesses.sh in NCS_UTILS B.1.3.12
#
# Revision 1.7  2009/06/24 15:35:50  pmertens
# Fixed bug in calling ALERT_ACTION.  Was introduced with previous version.
#
# Revision 1.6  2009/06/22 19:02:25  pmertens
# The check_runawayproc function has been extended with:
# - a check on process-name
# - a check on a exclude list (/var/opt/perf/runaways.exc).  If the process
#   being checked is listed in the exclude-list, it will not be alerted.
#   Optionally a 'processname username' can be specified in the exclude list.
#   In that case the process must be running under the specified user to be
#   excluded.
#
# Revision 1.5  2007/11/29 14:44:12  shameed
# The cleanup fuction is added in PerfAlert.sh and alarmdef is adjusted to
# call PerfAlert.sh, to cleanup, once every 6 hours.
#
# Revision 1.4  2007/11/21 17:02:17  shameed
# The runaway process detection logic is added in this script.
#
# Revision 1.3  2007/11/01 16:03:56  shameed
# Added comment @ the top of the script on the purpose of the script.
#
# Revision 1.2  2007/10/30 15:35:21  shameed
# The logger command is adjusted to run with "-p daemon.alert" to
# ensure that the message is logged in syslog or va/adm/messages in Sun.
#
# Revision 1.1  2007/10/30 14:59:59  shameed
# Script to be run by alarmgen to generate email alerts and execute
# local actions. This will source the file /var/opt/ITS/PerfAlertParms
# to get the various parameters. The parameter definitions can be found
# in /var/opt/ITS/PerfAlertParms.
#
#
# $RCSfile: PerfAlert.sh,v $
# $Source: /ncs/cvsroot/ncsbin/utils/PerfAlert.sh,v $
# $State: Exp $
# ----------------------------------------------------------------------------

