#!/usr/dt/bin/dtksh
# Author: Bolek Mynarski <bmynars@ncsus.jnj.com>
#
# $Revision: 1.9 $
# $Date: 2012/11/08 14:45:42 $
# $Header: /ncs/cvsroot/ncsbin/utils/oq_script.sh,v 1.9 2012/11/08 14:45:42 gdhaese1 Exp $ 
# $Id: oq_script.sh,v 1.9 2012/11/08 14:45:42 gdhaese1 Exp $
# $Locker:  $
# History: Check the bottom of the file for revision history
# ----------------------------------------------------------------------------

# Purpose of this script is to ease Operational Qualification of a newly
# built server.  Rather than executing steps manually, they can be
# executed in a single script

typeset -x PRGNAME=${0##*/}
typeset -x PRGDIR=${0%/*}
typeset -r oqdir=/var/adm/install-logs
typeset -r host=$(hostname)

[[ $PRGDIR = . || $PRGDIR != /* ]] && PRGDIR=$(pwd)

export FPATH=${PRGDIR%/utils}/acctutil/functions
export PATH=$PATH:/usr/bin:/usr/sbin:/sbin:/opt/ncsbin/utils

# Sanity Checks

if [ -d $FPATH ]; then
	: # Everything is fine
else
	echo " *** $PRGNAME ($LINENO): Fatal error occured.  [$FPATH] missing!"
	exit 1
fi

function _line {
	typeset -i i=0
	while [ $i -lt ${1:-80} ]; do
		(( i+=1 ))
		echo "${2:--}\c"
	done
	echo
}

function _step01 {
	echo "\n# Step 1"
	echo "# Verifying install state of all packages on $host.\n"
	
	typeset cmd='uname; id'
	printf "%s\n" "# Executing: $cmd" "             ${cmd//?/^}"
	uname; id

	echo
	cmd='swlist -l fileset -a state -a install_date'
	printf "%s\n" "# Executing: $cmd" "             ${cmd//?/^}"
	swlist -l fileset -a state -a install_date
}


function _step02 {
	echo "\n# Step 2"
	echo "# Verifying network accessibility. You should not see any packet loss!"
	echo "# This test will ping default gateway assigned to this host.\n"
	
	typeset cmd="ping \$(netstat -rn | awk '/default/ { print \$2 }') -n 3"
	printf "%s\n" "# Executing: $cmd" "             ${cmd//?/^}"
	
	ping $(netstat -rn | awk '/default/ { print $2 }') -n 3
}

function _step03 {
	typeset toresolve=$(awk '/nameserver/ { print $2 }' /etc/resolv.conf | tail -1)
	echo "\n# Step 3"
	echo "# Verifying network name resolution."
	echo "# Trying to resolve [$toresolve] IP address specified in /etc/resolv.conf.\n"
	
	typeset cmd='nslookup $toresolve'
	printf "%s\n" "# Executing: $cmd" "             ${cmd//?/^}"
	nslookup $toresolve
}

function _step04 {
	echo "\n# Step 4"
	echo "# Verifying proper operation of NTP protocol."
	cat <<-eof
	
	# Important information to note:
	#  1. You should see "*" and "+" signs next to NTP servers.
	#     If you do not, then wait for a few minutes for NTP server
	#	 to settle down.
	#  2. Under "reach" column, you should see '377'.  This means that
	#     each NTP server you connect to is reachable.

	eof
	
	typeset cmd='ntpq -p'
	printf "%s\n" "# Executing: $cmd" "             ${cmd//?/^}"
	ntpq -p
}

function _step05 {
	echo "\n# Step 5"
	echo "# Verifying local 'root' email address (.forward file).\n"
	
	typeset cmd="sendmail -bv root | awk '{ print \$NF }'"
	printf "%s\n" "# Executing: $cmd" "             ${cmd//?/^}"
	sendmail -bv root | awk '{ print $NF }'

	echo
	cmd='cat $HOME/.forward'
	printf "%s\n" "# Executing: $cmd" "             ${cmd//?/^}"
	cat $HOME/.forward
}

function _step06 {
	echo "\n# Step 6"
	echo "# Verify that a non existing id on this system can have SMTP address resolved"
	echo "# against JJEDS using sendmail binary.  For this test, Gery Zengion id will"
	echo "# will be used.\n"
	
	typeset cmd="sendmail -bv gzengion | awk '{ print \$NF }'"
	printf "%s\n" "# Executing: $cmd" "             ${cmd//?/^}"
	sendmail -bv gzengion | awk '{ print $NF }'
}

function _step07 {
	echo "\n# Step 7"
	echo "# Verifying configuration of the system to make sure it's SOx compliant"
	echo "# Checking first for NCS_UTILS and NCS_ACCT proudcts:\n"
	
	typeset cmd='swlist -l fileset -a state -a install_date NCS_UTILS NCS_ACCT'
	printf "%s\n" "# Executing: $cmd" "             ${cmd//?/^}"
	swlist -l fileset -a state -a install_date NCS_UTILS NCS_ACCT

	typeset secbin=/opt/ncsbin/secutils/audit_rep.sh
	
	if [ -x $secbin ]; then
		echo
		cmd="$secbin"
		printf "%s\n" "# Executing: $cmd" "             ${cmd//?/^}"
		$secbin
	else
		printf "%s\n" "# $secbin cannot be executed!" "  ${secbin//?/^}"
	fi
}

function _step08 {
	echo "\n# Step 8"
	echo "# Verifying UNIX Logical security"
	echo "# Patch Bundle Compliance"
	echo "# This is a new server build.  All the latest bundles have been applied as"
	echo "# per 'print_manifest' recorded in section 8.1 of the HP-UX SW IQ-Checklist.doc"
	echo "# However, here are current NCS patch releases anyway.\n"
	
	typeset cmd="swlist | grep -i -E '(ncsgpb|itsgpb|jnjgpb)'"
	printf "%s\n" "# Executing: $cmd" "             ${cmd//?/^}"
	swlist | grep -i -E '(ncsgpb|itsgpb|jnjgpb)'
}

function _step09 {
	echo "\n# Step 9"
	echo "# Verifying hidden home directory for root account\n"
	
	typeset cmd='ls -ld $HOME'
	printf "%s\n" "# Executing: $cmd" "             ${cmd//?/^}"
	ls -ld $HOME
}

function _step10 {
	echo "\n# Step 10"
	echo "# Verifying account management as per JAQ# 2, 4, 5, 12, 22\n"

	typeset cmd='ls -l /etc/{passwd,group}'
	printf "%s\n" "# Executing: $cmd" "             ${cmd//?/^}"
	ls -l /etc/{passwd,group}
	
	echo
	cmd="cat /etc/passwd"
	printf "%s\n" "# Executing: $cmd" "             ${cmd//?/^}"
	cat /etc/passwd
}

function _step11 {
	echo "\n# Step 11"
	echo "# Verifying security defaults configuration file as per JAQ# 9, 12, WWIAPP S-8[11]\n"
	
	typeset getdef=/usr/lbin/getprdef
	typeset cmd="ls -ld /tcb"
	
	printf "%s\n" "# Executing: $cmd" "             ${cmd//?/^}"
	ls -ld /tcb

	echo
	cmd="$getdef -bpt (in human readable format)"
	printf "%s\n" "# Executing: $cmd" "             ${cmd//?/^}"

	set -A permArry $($getdef -bpt)

	for i in ${permArry[@]}; do
		case ${i%%=*} in
			bootpw) des="Boot authorization flag" ;;
			usrpick) des="User selected passwd" ;;
			syspnpw) des="System generates pronounceable passwords" ;;
			rstrpw) des="Use restricted password rules" ;;
			nullpw) des="Allow for use of NULL passwords" ;;
			syschpw) des="System generates passwords with characters only" ;;
			sysltpw) des="System generates letters only" ;;
			mintm) des="Minimum days allowed between password changes" ;;
			exptm) des="Password expiratoin time" ;;
			lftm) des="Password life time" ;;
			llog) des="Account inactivity before locking" ;;
			expwarn) des="Password expiration warning in days" ;;
			umaxlntr) des="Maximum unsuccessful login tries" ;;
			tmaxlntr) des="Max num of consec bad logins per terminal allowed" ;;
			dlylntr) des="Delay in seconds between bad login attempts" ;;
			lntmout) des="Login timeout in seconds" ;;
			*) des="No description available" ;;
		esac

		key=${i%%=*}; value=${i#*=}; value=${value%,*}
		printf "%50s (%10s): %5-s\n" "$des" "$key" "$value"
	done

	echo
	cmd="$getdef -rm maxpwln (Maximum password length)"
	printf "%s\n" "# Executing: $cmd" "             ${cmd//?/^}"
	$getdef -rm maxpwln

	echo
	cmd="/usr/lbin/getprpw -m exptm,spwchg on each user"
	printf "%s\n" "# Executing: $cmd" "             ${cmd//?/^}"

	echo
	printf "%10s %s\n" "UserID:" "Expiration Time, Password Change Date"
	printf "%10s %s\n" "=======" "====================================="
	
	typeset u
	for u in $(pwget | cut -d: -f1); do
		printf "%10s %s\n" "$u:" "$(/usr/lbin/getprpw -m exptm,spwchg $u)"
	done
	
	echo	
	typeset secfile=/etc/default/security
	
	if [ -s $secfile ]; then
		cmd="cat $secfile"
		printf "%s\n" "# Executing: $cmd" "             ${cmd//?/^}"
		cat $secfile
	else
		_note "$PRGNAME ($LINENO): $secfile does not exist!"
	fi
}

function _step12 {
	echo "\n# Step 12"
	echo "# Verifying security messages as per JAQ #26, WWIAPP# S-26[16]\n"
	
	typeset issue=/etc/issue
	typeset motd=/etc/motd
	
	typeset cmd="cat $issue"
	printf "%s\n" "# Executing: $cmd" "             ${cmd//?/^}"

	if [ -s $issue ]; then
		cat $issue
	else
		_note "$PRGNAME ($LINENO): $issue does not exit or is blank!"
	fi
	
	echo
	cmd="cat $motd"
	printf "%s\n" "# Executing: $cmd" "             ${cmd//?/^}"
	
	if [ -s $motd ]; then
		cat $motd
	else
		_note "$PRGNAME ($LINENO): $motd does not exist or is blank!"
	fi
}

function _step13 {
	echo "\n# Step 13"
	echo "# Verifying that direct logon of the privileged account is disabled"
	echo "# as per JAQ #5\n"
	
	typeset profile=/etc/profile
	typeset iddb=/var/adm/.iddb
	
	typeset cmd="cat $profile"
	printf "%s\n" "# Executing: $cmd" "             ${cmd//?/^}"

	if [ -s $profile ]; then
		cat $profile
	else
		_note "$PRGNAME ($LINENO): there is an issue with $profile!"
	fi		
	
	echo
	cmd="cat $iddb"
	printf "%s\n" "# Executing: $cmd" "             ${cmd//?/^}"
	
	if [ -f $iddb ]; then
		cat $iddb
		
		echo
		cmd="ls -l $iddb"
		printf "%s\n" "# Executing: $cmd" "             ${cmd//?/^}"
		
		ls -l $iddb
	else
		_note "$PRGNAME ($LINENO): /var/adm/.iddb does not exist!"
	fi
}


function _step14 {
	echo "\n# Step 14"
	echo "# Verifying minimum system requirements as per JAQ #11, WWIAPP Refernece: S-26 11,12,13\n"
	
	typeset basconf="/etc/opt/sec_mgmt/bastille/config"
	typeset cmd="cat $basconf"
	printf "%s\n" "# Executing: $cmd" "             ${cmd//?/^}"

	if [ -f $basconf ]; then
		cat $basconf
	else
		_note "$PRGNAME ($LNIENO): $basconf does not exist!"
	fi

	echo "\n# Display currently active services in /etc/inetd.conf\n"
	cmd="grep -v '^#' /etc/inetd.conf | sed '/^$/d'"
	printf "%s\n" "# Executing: $cmd" "             ${cmd//?/^}"
	grep -v '^#' /etc/inetd.conf | sed '/^$/d'
}

function _step15 {
	echo "\n# Step 15"
	echo "# Verifying FTP JAQ #10, WWIAPP Refernece: S-8 & S-26\n"
	
	typeset cmd="cat /etc/ftpd/ftpusers"
	printf "%s\n" "# Executing: $cmd" "             ${cmd//?/^}"

	if [ -f /etc/ftpd/ftpusers ]; then
		cat /etc/ftpd/ftpusers
	else
		_note "$PRGNAME ($LINENO): /etc/ftpd/ftpusers does not exist!"
	fi
}

function _step16 {
	typeset flck=${PRGDIR%/*}/secutil/sidgid.sh

	echo  "\n# Step 16"
	echo "# Listing SetUID, SetGID, and world writeable files and directories\n"

	if [ -f $flck ]; then
		printf "%s\n" "# Executing: $flck" "             ${flck//?/^}"
		$flck
	else
		typeset cmd="find / ! -fstype nfs -user 0 \( -perm -4000 -o -perm -2000 \) -exec ls -ld {} \;"
		printf "%s\n" "# Executing: $cmd" "             ${cmd//?/^}"
		find / ! -fstype nfs -user 0 \( -perm -4000 -o -perm -2000 \) -exec ls -ld {} \;
	fi
}

function _step17 {
	echo "\n# Step 17"
	echo "# Verifying general security recommendations\n"
	
	typeset sectt=/etc/securetty
	typeset cmd="cat $sectt"
	printf "%s\n" "# Executing: $cmd" "             ${cmd//?/^}"
	
	if [ -f $sectt ]; then
		cat $sectt
	else
		_note "$PRGNAME ($LINENO): $sectt does not exist!"
	fi

	echo
	cmd="grep console /tcb/files/devassign"
	printf "%s\n" "# Executing: $cmd" "             ${cmd//?/^}"
	grep console /tcb/files/devassign

	echo
	cmd="ls -l /sbin/rc{1,2,3}.d"
	printf "%s\n" "# Executing: $cmd" "             ${cmd//?/^}"
	
	for dir in 1 2 3; do
		echo "  Directory: /sbin/rc${dir}.d"
		echo "  ---------------------------"
		ls -l /sbin/rc${dir}.d
	done

	echo
	cmd="cat /etc/rc.config.d/nddconf"
	printf "%s\n" "# Executing: $cmd" "             ${cmd//?/^}"
	cat /etc/rc.config.d/nddconf
}

function _step18 {
	echo "\n# Step 18"
	echo "# Veifying audit scripts and periodic verification as per JAQ #16\n"
	
	typeset cmd="crontab -l | grep ncsbin"
	printf "%s\n" "# Executing: $cmd" "             ${cmd//?/^}"
	crontab -l | grep ncsbin
}


# ------------------------------------------------------------------------------
#                                   MAIN BODY
# ------------------------------------------------------------------------------

{
	_line 80
	_note "OPERATIONAL QUALIFICATION FOR [$host]"
	_note "$(date)"
	_line 80

	typeset -i c=0
	while [ $c -lt 18 ]; do
		(( c+=1 ))
		[ ${#c} -eq 1 ] && num=0${c} || num=$c
	
		eval _step${num}
		_line 80 '='
	done

} | tee -a $oqdir/OQ-${host}_verification_script.scriptlog


# ----------------------------------------------------------------------------
# $Log: oq_script.sh,v $
# Revision 1.9  2012/11/08 14:45:42  gdhaese1
# changed step 8 for the missing itsgpb and jnjgpb patch bundle checks
#
# Revision 1.8  2006/11/25 05:31:00  bmynars
# Changed message displayed in step 16 of oq script to read following:
# "# Listing SetUID, SetGID, and world writeable files and directories."
#
# Revision 1.7  2006/11/25 05:19:38  bmynars
# Replaced 'find' command in step 16 with 'ncsbin/secutil/sidgid.sh' script
# checking for suid, gid, and world writeable files and directories.
#
# Revision 1.6  2006/04/09 22:05:12  bmynars
# Minor cosmetic changes.
#
# Revision 1.5  2006/04/09 14:59:25  bmynars
# Converted script to use functions as each step
#
# Revision 1.4  2006/04/09 05:13:53  bmynars
# Fixed check for NCS patch bundle
#
# Revision 1.3  2006/04/09 05:00:58  bmynars
# Fixed step 11 by making output human readable
#
# Revision 1.2  2005/12/02 18:17:46  bmynars
# Fixed spelling error
#
# Revision 1.1  2005/11/21 21:22:50  bmynars
# Operation Qualification script for new server build.
#
# $RCSfile: oq_script.sh,v $
# $Source: /ncs/cvsroot/ncsbin/utils/oq_script.sh,v $
# $State: Exp $
# ----------------------------------------------------------------------------
