#!/usr/bin/ksh
# Author: Sahul Hameed <shameed@ncsus.jnj.com>
#
# $Revision: 1.8 $
# $Date: 2008/05/29 15:15:20 $
# $Header: /ncs/cvsroot/ncsbin/utils/sa_tasks/START_MEMORY_COUNT.sh,v 1.8 2008/05/29 15:15:20 shameed Exp $ 
# $Id: START_MEMORY_COUNT.sh,v 1.8 2008/05/29 15:15:20 shameed Exp $
# $Locker:  $
# History: Check the bottom of the file for revision history
# ----------------------------------------------------------------------------

# set -x

typeset -x PRGNAME=${0##*/}
typeset -x PRGDIR=${0%/*}
typeset -x PATH=$PATH:/usr/bin:/usr/contrib/bin:/usr/sbin:/sbin

[[ $PRGDIR = . || $PRGDIR != /* ]] && PRGDIR=$(pwd)

####Starting  verification of  memory counts while system comes up ####

typeset -x HOST=$(hostname)
typeset memfil=$PRGDIR/REF_MEM_COUNT
typeset -l arch=$(uname -m)
typeset -l osrev=$(uname -r)

function _mailErr {
	mailx -s "There are issues with acquiring memory count using $PRGNAME. Please, investiage" root < /dev/null
	exit 1
}

function _filCheck {
	if [ -s "$memfil" ]; then
		MCOUNT=$(cat $memfil)
	else
		echo 0 > $memfil
	fi
}

function _adb {
	echo phys_mem_pages/D | adb -k /stand/vmunix /dev/kmem | \
	awk 'length >15' | awk '{print $2/262144 }'
}

function _report {
	typeset MCOUNT=$1
	typeset MC=$2
	typeset unit=$3
	
	if [ $MCOUNT -le $MC ]; then
		printf "%25s: %-s\n" "Total Memory" "${MCOUNT}${unit}"
		printf "%25s: %-s\n" "Actual Memory" "${MC}${unit}"
	else
		date | mailx -s "${HOST}: Less memory found after reboot, $MCOUNT vs ${MC}." root
		echo 'logger -t SA_ALERT -p user.alert "CPU: The system has less memory after reboot. Could be due to H/W failure."' | \
		at now + 40 minutes
	fi
}

function _risc {
	_filCheck # Check for content of memory count file
	
	MC="$(_adb)" # Checking run time memory
	
	[ -n "$MC" ] || _mailErr

	_report $MCOUNT $MC Gb
}

function _ia64 {
	_filCheck # Check for content of memory count file
	MC=`machinfo | grep ^Memory|sed 's/^[A-Za-z :=][A-Za-z :=]*\([0-9][0-9][0-9]*\) ..*/\1/'`
	
	[ $MC -eq 0 ] && _mailErr
	
	_report $MCOUNT $MC Mb
}

# ------------------------------------------------------------------------------
#                                     MAIN BODY
# ------------------------------------------------------------------------------

# To debug, enable function tracing below and set -x on the top
# typeset -ft _ai64
# typeset -ft _risc
# typeset -ft _mailErr
# typeset -ft _report
# typeset -ft _adb
# typeset -ft _filCheck

case $arch in
	ia64) _ia64 ;;
	9000*) _risc ;;
	*) _mailErr ;;
esac
	

# ----------------------------------------------------------------------------
# $Log: START_MEMORY_COUNT.sh,v $
# Revision 1.8  2008/05/29 15:15:20  shameed
# Updated for change in output of machinfo command in IA boxes. _ia64
# function is modified.
#
# Revision 1.7  2008/03/20 20:53:08  shameed
# Adjusted scripts for B11.31 version of machinfo Memory report.
#
# Revision 1.6  2007/01/11 15:53:47  bmynars
# Added unit of measure to the output of memory count.  It's in Mb on
# IA64 and in Gb on PA-RISC.
#
# Revision 1.5  2007/01/11 15:32:17  bmynars
# Updated script to properly handle memory count on IA64 platform.
#
# Revision 1.4  2005/11/17 17:57:39  bmynars
# Formatted script for ease of reading
#
# $RCSfile: START_MEMORY_COUNT.sh,v $
# $Source: /ncs/cvsroot/ncsbin/utils/sa_tasks/START_MEMORY_COUNT.sh,v $
# $State: Exp $
# ----------------------------------------------------------------------------
