#!/bin/sh
# Author: Bolek Mynarski <bmynars@ncsus.jnj.com>
#
# $Revision: 1.6 $
# $Date: 2014/06/16 08:41:50 $
# $Header: /ncs/cvsroot/ncsbin/utils/sa_tasks/START_CPU_COUNT.sh,v 1.6 2014/06/16 08:41:50 gdhaese1 Exp $ 
# $Id: START_CPU_COUNT.sh,v 1.6 2014/06/16 08:41:50 gdhaese1 Exp $
# $Locker:  $
# History: Check the bottom of the file for revision history
# ----------------------------------------------------------------------------

typeset -x PRGNAME=${0##*/}
typeset -x PRGDIR=${0%/*}

#### Checking the Number of CPU , while system is Restarted ######

/usr/sbin/ioscan -fknC processor >/tmp/processor

if [ -f /tmp/processor ]; then 
	CPU_COUNT_AFTER_REBOOT=`/usr/bin/grep processor /tmp/processor |/usr/bin/grep CLAIMED |/usr/bin/wc -l`
fi

[[ ! -f "$PRGDIR/REF_CPU_COUNT" ]] && exit 0  # makes no sense to continue

REFCOUNT=$(cat $PRGDIR/REF_CPU_COUNT)

if [ $REFCOUNT -eq $CPU_COUNT_AFTER_REBOOT ]; then 
	echo "The Number of Processors EQUALS with the default value  #:  $REFCOUNT" >/dev/null
	echo "The current processor value is #: $CPU_COUNT_AFTER_REBOOT" >>/dev/null
elif [ $REFCOUNT -gt $CPU_COUNT_AFTER_REBOOT ]; then
	HOST=`hostname`
	date | mailx -s "${HOST}-FEWER CPUS FOUND AFTER REBOOT, $REFCOUNT Vs ${CPU_COUNT_AFTER_REBOOT}." root
	echo 'logger -t SA_ALERT -p user.alert "CPU: The system has fewer CPU after reboot. Could be due to H/W failure."' | \
	at now + 40 minutes
fi

rm -f /tmp/processor


# ----------------------------------------------------------------------------
# $Log: START_CPU_COUNT.sh,v $
# Revision 1.6  2014/06/16 08:41:50  gdhaese1
# if file REF_CPU_COUNT does not exist; just exit the script
#
# Revision 1.5  2008/03/20 17:42:51  shameed
# Added -k option to ioscan.
#
# Revision 1.4  2005/11/17 17:57:39  bmynars
# Formatted script for ease of reading
#
# $RCSfile: START_CPU_COUNT.sh,v $
# $Source: /ncs/cvsroot/ncsbin/utils/sa_tasks/START_CPU_COUNT.sh,v $
# $State: Exp $
# ----------------------------------------------------------------------------
