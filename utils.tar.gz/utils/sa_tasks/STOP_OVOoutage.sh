#!/bin/sh
# Author: Sahul Hameed, NCS
#
# $Revision: 1.8 $
# $Date: 2009/06/30 20:40:55 $
# $Header: /ncs/cvsroot/ncsbin/utils/sa_tasks/STOP_OVOoutage.sh,v 1.8 2009/06/30 20:40:55 shameed Exp $ 
# $Id: STOP_OVOoutage.sh,v 1.8 2009/06/30 20:40:55 shameed Exp $
# $Locker:  $
# History: Check the bottom of the file for revision history
# ----------------------------------------------------------------------------

typeset -x PRGNAME=${0##*/}
typeset -x PRGDIR=${0%/*}

#
##################### VARIABLES ##########################
#
# Configurable variables are in file defined in CONFIG_FILE varaible below.
# Change the variables in the configuration file, not in here. Do not
# modify any of these variables.

PATH=:/usr/bin:/usr/sbin:$PATH
export PATH
CONFIG_FILE=/var/opt/ITS/OVO_Outage_Input
ME=`basename $0`

MAXHOUR=23
MAXMIN=59

D0=:Sun:0:
D1=:Mon:1:
D2=:Tue:2:
D3=:Wed:3:
D4=:Thu:4:
D5=:Fri:5:
D6=:Sat:6:
D7=:Sun:7:

# ==============================================================================
# FUNCTIONS

toTIME() {

	toMIN=`expr $fromMIN + $DUR`

	if [ "$toMIN" -ge 60 ]; then
		toHOUR=$(( $fromHOUR + $toMIN / 60 ))
		toMIN=$(( $toMIN % 60 ))
	else
		toHOUR=$fromHOUR
	fi


	if [ "$toHOUR" -ge 24 ]; then
		toDAY=$(( $fromDAY +  $toHOUR / 24 ))
		toHOUR=$(( $toHOUR % 24 ))
	else
		toDAY=$fromDAY
	fi
}

digit() {
	WC=`echo $fromHOUR|wc -m`
	if [ $WC -le 2 ]; then
		fromHOUR=0${fromHOUR}
	fi

	WC=`echo $fromMIN|wc -m`
	
	if [ $WC -le 2 ]; then
		fromMIN=0${fromMIN}
	fi

	WC=`echo $toHOUR|wc -m`

	if [ $WC -le 2 ]; then
		toHOUR=0${toHOUR}
	fi

	WC=`echo $toMIN|wc -m`
	if [ $WC -le 2 ]; then
		toMIN=0${toMIN}
	fi
}

save_OI() {

ps -ef| grep $ME  > /tmp/pslist
cat /tmp/pslist | grep -v $$ | wc -l |read COUNT
if [ $COUNT -ne 0 ]; then
	echo "Another $0 script is running. Exiting..."
	cat /tmp/pslist
	echo "The PID of this process is $$."
	exit 1
fi

if [ -f ${OUTAGE_INPUT}.AUTOSAVE ]; then
	echo A copy of ${OUTAGE_INPUT}.AUTOSAVE found, possibly due to an \
	incomplete execution of $0 . Restore proper ${OUTAGE_INPUT} and \
	cleanup ${OUTAGE_INPUT}.AUTOSAVE. Exiting.. | \
	mailx -s "${OUTAGE_INPUT} ERROR" $MAILTO
	exit 1
else
	if [ -f $OUTAGE_INPUT ]; then
		mv $OUTAGE_INPUT ${OUTAGE_INPUT}.AUTOSAVE
	else
		sed -n '/^#START of Default outage_input file.$/,/^#END of Default outage_input file.$/p' $0 |grep -v -E '^#START|^#END' > ${OUTAGE_INPUT}.AUTOSAVE
	fi
fi

}


restore_OI() {
if [ -f $OUTAGE_INPUT ]; then
	cp -pi $OUTAGE_INPUT /tmp/outage_input.`date +%m%d%y%H%M`
fi

if [ -f $FOOTPRINT ]; then
	ll $FOOTPRINT
	rm $FOOTPRINT
else
	echo OVO Outage footprint file $FOOTPRINT not found.
fi

if [ -f ${OUTAGE_INPUT}.AUTOSAVE ]; then
	mv ${OUTAGE_INPUT}.AUTOSAVE $OUTAGE_INPUT
fi

}

#------------------------------------------------------------------------



# MAIN SCRIPT


if [ -r $CONFIG_FILE ]
then
	. $CONFIG_FILE
else
	echo Config file $CONFIG_FILE not found.
	exit 1
fi


trap "echo mv ${OUTAGE_INPUT}.AUTOSAVE $OUTAGE_INPUT; exit" 1 2 3 15

if [ -n "$1" ]; then
	DUR=$1
	if [ $DUR -gt 8640 ]; then
		echo "Long outage duration--this script will handle duration upto"
		echo "8640 minutes (#of minutes in 6 days) only. Anything more, has to"
		echo "be handled manually by operations. Outage records for the first"
		echo "8640 minutes will be created."
		DUR=8640
	fi
else
	DUR=$DEFAULT_DUR
fi

if [ -n "$2" ]; then
	APP=$2
else
	APP=$DEFAULT_APP
fi

if [ -d ${OV_CONF_DIR} ]; then
	echo nothing > /dev/null
else
	mkdir -p -m 700 ${OV_CONF_DIR}
	chmod 700 ${OV_CONF_DIR}
fi

save_OI

date "+%u %H %M" | read fromDAY fromHOUR fromMIN

while [ "$DUR" -gt 0 ] ; do
	minsleft=`echo "( $MAXMIN - $fromMIN ) + ( ( $MAXHOUR - $fromHOUR ) * 60 )" |bc`
	
	if [ $minsleft -ge $DUR ]; then
		toTIME
		DAY=`echo "$D0\n$D1\n$D2\n$D3\n$D4\n$D5\n$D6\n$D7\n"|grep "$fromDAY" | \
		cut -d ':' -f 2`
		digit
		echo "|$APP|${DAY}|${fromHOUR}:${fromMIN}|${toHOUR}:${toMIN}|$DUR|" >> $OUTAGE_INPUT
		DUR=`expr $DUR - $minsleft`
	else
		X=$DUR
		DUR=$minsleft
		toTIME
		DAY=`echo "$D0\n$D1\n$D2\n$D3\n$D4\n$D5\n$D6\n$D7\n"|grep "$fromDAY" | \
		cut -d ':' -f 2`
		digit
		echo "|$APP|${DAY}|${fromHOUR}:${fromMIN}|${toHOUR}:${toMIN}|$DUR|" >> $OUTAGE_INPUT
		DUR=`expr $X - $minsleft`
		fromHOUR=00
		fromMIN=00
		fromDAY=`echo "( $fromDAY + 1) % 7" |bc`
	fi
done
sleep ${OV_READ_SLEEP_INTRVL}

restore_OI

#START of Default outage_input file.
### Format of this file:
###
### |application_group|weekday|start_time|end_time|duration|
###
### Where:
###   application_group is the application group name in procmon_local.cfg
###   or the keyword "wholeserver" for outage for the whole server
###   weekday is either the day of the week or a fixed date or DAILY for everyday
### For example:
### |ora_AMPHD1|Sat|22:00|23:59|119|
#END of Default outage_input file.


# ----------------------------------------------------------------------------
# $Log: STOP_OVOoutage.sh,v $
# Revision 1.8  2009/06/30 20:40:55  shameed
# Fix for OVO 7 & changed logic for detecting duplicate processes.
#
# Revision 1.7  2009/06/24 22:44:11  shameed
# Adjusted for OVO 08
#
# Revision 1.6  2008/03/25 18:11:50  shameed
# This version of script populates OVO outage input file for whole server
# outage interval automaticaly during ordely reboot, waits for OVO to read
# the outage information and restores the original outage input file. This
# eliminates the need of the START script ot restore the file upon reboot.
# This also sources a parameter file, /var/opt/ITS/OVO_Outage_Input.
#
# Revision 1.5  2005/12/02 18:15:33  bmynars
# Fixed line 78 - toHOUR calculation logic
#
# Revision 1.4  2005/11/17 17:57:39  bmynars
# Formatted script for ease of reading
#
# $RCSfile: STOP_OVOoutage.sh,v $
# $Source: /ncs/cvsroot/ncsbin/utils/sa_tasks/STOP_OVOoutage.sh,v $
# $State: Exp $
# ----------------------------------------------------------------------------
