#!/usr/bin/ksh
# Author: Anil Bhandarkar, NCS
#
# $Revision: 1.5 $
# $Date: 2008/09/26 18:10:45 $
# $Header: /ncs/cvsroot/ncsbin/utils/sa_tasks/START_sandisk_timeout.sh,v 1.5 2008/09/26 18:10:45 bmynars Exp $
# $Id: START_sandisk_timeout.sh,v 1.5 2008/09/26 18:10:45 bmynars Exp $
# $Locker:  $
# History: Check the bottom of the file for revision history
# ----------------------------------------------------------------------------

typeset -x PRGNAME=${0##*/}
typeset -x PRGDIR=${0%/*}

###The script set the pv timeout value to 120 secs for only the SAN
###disks

PATH=:/usr/bin:/usr/bin:$PATH

typeset pvtmout=60                         # time out value for physical devices
typeset os=$(uname -r)                     # os model
typeset sansort=/var/tmp/sandisk_sort_list
typeset sanscan=/var/tmp/ioscan.sandisk
typeset sandisks=/var/tmp/sandisks
typeset pvnames=/var/tmp/pvnames

########## Do an ioscan to get a list of all the disks###########
typeset arg="-funC disk"
[[ $os = B.11.3* ]] && arg="-m lun -F"

ioscan $arg > $sanscan

#############Get a list of ONLY SAN disks form the ioscan#########
case $os in
	B.11.3*)
		awk -F: '/EMC([ ])+SYMMETRIX|HP([ ])+OPEN-|HP([ ])+DISK-SUBSYSTEM/ \
			{ if ( $5 == "CLAIMED" ){ getline; print | "sort -u" }}' $sanscan |\
			while read dsk1 dsk2 junk; do
				[[ $dsk1 = */pt/pt* ]] && continue
				echo "$dsk1"
			done > $sansort
	;;
	*)
		awk '/EMC([ ])+SYMMETRIX|HP([ ])+OPEN-|HP([ ])+DISK-SUBSYSTEM/ \
			{ if ( $5 == "CLAIMED" ){getline; print $1 | "sort -u"}}' $sanscan \
			> $sansort
	;;
esac

# -----------------------------------------------------------------------------
#                               SANITY CHECKS
# -----------------------------------------------------------------------------

if [ ! -s $sansort ]; then
	echo "$PRGNAME ($LINENO): [$sansort] is blank or does not exist!"
	exit 1
fi

# -----------------------------------------------------------------------------
#                                 MAIN BODY
# -----------------------------------------------------------------------------

# All values will be set to $pvtmout
for vg in $(vgdisplay | awk '/VG Name/ && $NF !~ /vg00/ { print $NF }'); do
	# Acquire list of disks
	vgdisplay -v $vg |\
	awk '/PV Name/ && ! /Alternate Link/ { print $NF | "sort -u" }' > $pvnames
	comm -12 $pvnames $sansort > $sandisks
	VGCFG_SAVE=no

	# Check for PVTimeout values
	for dasd in $(< $sandisks); do
		TimeOut=$(pvdisplay $dasd |awk '/IO Timeout/ {print $4}')
		[[ $TimeOut = $pvtmout ]] && continue # Alread set.  Skip this PV.

		pvchange -A n -t $pvtmout $dasd >/dev/null 2>&1
		VGCFG_SAVE=yes
	done

	# Backup volume group after adjusting PVTimeout
	[[ $VGCFG_SAVE = yes ]] && vgcfgbackup $vg
done


# ----------------------------------------------------------------------------
# $Log: START_sandisk_timeout.sh,v $
# Revision 1.5  2008/09/26 18:10:45  bmynars
# Updated 'if' expression checking for a timeout.  Made it more readable.
#
# Revision 1.4  2008/09/26 17:22:34  bmynars
# Modified script to PVTimeout is set to 60 seconds on SAN disks as well
# as adjusted it so it can be used on B.11.31 systems.
#
# Revision 1.3  2006/06/13 20:36:24  shameed
# Disabled hard ioscan and added -A to differ vgcfg save ill all changesall PVs of a VG are done.
#
# Revision 1.2  2005/11/17 17:57:39  bmynars
# Formatted script for ease of reading
#
# $RCSfile: START_sandisk_timeout.sh,v $
# $Source: /ncs/cvsroot/ncsbin/utils/sa_tasks/START_sandisk_timeout.sh,v $
# $State: Exp $
# ----------------------------------------------------------------------------
