#!/usr/bin/ksh
#
# $Revision: 1.8 $
# $Date: 2008/05/29 15:15:20 $
# $Header: /ncs/cvsroot/ncsbin/utils/sa_tasks/STOP_MEMORY_COUNT.sh,v 1.8 2008/05/29 15:15:20 shameed Exp $ 
# $Id: STOP_MEMORY_COUNT.sh,v 1.8 2008/05/29 15:15:20 shameed Exp $
# $Locker:  $
# History: Check the bottom of the file for revision history
# ----------------------------------------------------------------------------

typeset -x PRGNAME=${0##*/}
typeset -x PRGDIR=${0%/*}
typeset -x PATH=$PATH:/usr/bin:/usr/contrib/bin:/usr/sbin:/sbin

[[ $PRGDIR = . || $PRGDIR != /* ]] && PRGDIR=$(pwd)

#
###### Checking the Memory Count  while the system shutsdown/rebooted #######

typeset -x HOST=$(hostname)
typeset memfil=$PRGDIR/REF_MEM_COUNT
typeset -l arch=$(uname -m)
typeset -l osrev=$(uname -r)

function _mailErr {
	mailx -s "There are issues with acquiring memory count using $PRGNAME. Please, investiage" root < /dev/null
	exit 1
}

function _risc {
	echo phys_mem_pages/D | adb -k /stand/vmunix /dev/kmem |\
	awk 'length >15' |\
	awk '{print $2/262144 }' > $memfil
}

function _ia64 {
	machinfo | grep ^Memory|sed 's/^[A-Za-z :=][A-Za-z :=]*\([0-9][0-9][0-9]*\) ..*/\1/' > $memfil
}

case $arch in
	ia64) _ia64 ;;
	9000*) _risc ;;
	*)
		mailx -s "$PRGNAME ($LINENO): I know nothing about [$arch]!" root < /dev/null
	;;
esac

# ----------------------------------------------------------------------------
# $Log: STOP_MEMORY_COUNT.sh,v $
# Revision 1.8  2008/05/29 15:15:20  shameed
# Updated for change in output of machinfo command in IA boxes. _ia64
# function is modified.
#
# Revision 1.7  2008/03/20 20:53:08  shameed
# Adjusted scripts for B11.31 version of machinfo Memory report.
#
# Revision 1.6  2007/01/11 15:48:05  bmynars
# Updated script to properly handle ia64 platform.
#
# Revision 1.5  2005/11/17 18:12:43  bmynars
# Fixed directory location
#
# Revision 1.4  2005/11/17 17:57:39  bmynars
# Formatted script for ease of reading
#
# $RCSfile: STOP_MEMORY_COUNT.sh,v $
# $Source: /ncs/cvsroot/ncsbin/utils/sa_tasks/STOP_MEMORY_COUNT.sh,v $
# $State: Exp $
# ----------------------------------------------------------------------------
