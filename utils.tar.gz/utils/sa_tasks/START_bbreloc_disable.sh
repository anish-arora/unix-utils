#!/bin/sh
# Author: Anil Bhandarkar
#
# $Revision: 1.5 $
# $Date: 2006/06/13 19:56:26 $
# $Header: /ncs/cvsroot/ncsbin/utils/sa_tasks/START_bbreloc_disable.sh,v 1.5 2006/06/13 19:56:26 shameed Stab $ 
# $Id: START_bbreloc_disable.sh,v 1.5 2006/06/13 19:56:26 shameed Stab $
# $Locker:  $
# History: Check the bottom of the file for revision history
# ----------------------------------------------------------------------------

typeset -x PRGNAME=${0##*/}
typeset -x PRGDIR=${0%/*}

# This script disables the bad block relocation on only those logical volumes
# which have ONLY SAN disks.

ioscan -funC disk >/tmp/ioscan.alldisks

#Get a list of ONLY SAN disks form the ioscan
awk '/EMC     SYMMETRIX|HP      OPEN-|HP      DISK-SUBSYSTEM/ { if ( $5 == "CLAIMED" ){getline; print $1}}' /tmp/ioscan.alldisks >/tmp/onlysandisk_list

for VG in `vgdisplay 2>/dev/null|awk '/^VG Name/ {print $3}'`
do
 VGCFG_SAVE=no
 for LV in `vgdisplay -v $VG 2>/dev/null|awk '/LV Name/ {print $3}'`
 do
  B_RELOC=no            #Assume the lv only has SAN disks.
  for PV in `lvdisplay -kv $LV | awk '/\/dev\/dsk\// {print $1}'`
  do
   grep -q $PV /tmp/onlysandisk_list
   RC=$?
   if [ $RC -ne 0 ]; then
   
    B_RELOC=yes #Since it has local disks, flag to do reloc.
   fi
  done
        #Tune off bad block reclocation on SAN only LVs.

  if [ "$B_RELOC" = "no" ]; then
   BBLK=`lvdisplay -kv $LV|grep -i bad|awk '{print $3}'`
   if [ "$BBLK" = "on" ]; then
    echo "Turning off bad block relocation on $LV"
    lvchange -A n -r N $LV
    VGCFG_SAVE=yes
   fi
  fi
 done
 if [ "$VGCFG_SAVE" = "yes" ]
 then
  vgcfgbackup $VG
 fi
done



# ----------------------------------------------------------------------------
# $Log: START_bbreloc_disable.sh,v $
# Revision 1.5  2006/06/13 19:56:26  shameed
# Disabled hard ioscan and added -A to differ vgcfg config till all LVs of a VG are done.
#
# Revision 1.4  2005/11/17 17:57:39  bmynars
# Formatted script for ease of reading
#
# $RCSfile: START_bbreloc_disable.sh,v $
# $Source: /ncs/cvsroot/ncsbin/utils/sa_tasks/START_bbreloc_disable.sh,v $
# $State: Stab $
# ----------------------------------------------------------------------------
