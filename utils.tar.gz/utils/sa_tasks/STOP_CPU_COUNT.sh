#!/bin/sh
#
# $Revision: 1.5 $
# $Date: 2008/03/20 17:42:51 $
# $Header: /ncs/cvsroot/ncsbin/utils/sa_tasks/STOP_CPU_COUNT.sh,v 1.5 2008/03/20 17:42:51 shameed Exp $ 
# $Id: STOP_CPU_COUNT.sh,v 1.5 2008/03/20 17:42:51 shameed Exp $
# $Locker:  $
# History: Check the bottom of the file for revision history
# ----------------------------------------------------------------------------

typeset -x PRGNAME=${0##*/}
typeset -x PRGDIR=${0%/*}

### Checking the processor count while the system is shutdown/rebooted  ####
#
#

/usr/sbin/ioscan -fknC processor >/tmp/processor

if [ -f /tmp/processor ]; then 
	SHUT_REBOOT_CPU_COUNT=`/usr/bin/grep processor /tmp/processor |/usr/bin/grep CLAIMED |/usr/bin/wc -l`
	echo $SHUT_REBOOT_CPU_COUNT > $PRGDIR/REF_CPU_COUNT 
fi

rm -f /tmp/processor


# ----------------------------------------------------------------------------
# $Log: STOP_CPU_COUNT.sh,v $
# Revision 1.5  2008/03/20 17:42:51  shameed
# Added -k option to ioscan.
#
# Revision 1.4  2005/11/17 17:57:39  bmynars
# Formatted script for ease of reading
#
# $RCSfile: STOP_CPU_COUNT.sh,v $
# $Source: /ncs/cvsroot/ncsbin/utils/sa_tasks/STOP_CPU_COUNT.sh,v $
# $State: Exp $
# ----------------------------------------------------------------------------
