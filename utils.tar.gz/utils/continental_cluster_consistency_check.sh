#!/bin/ksh
# Script: c4 (Continental Cluster Configuration Checker or c4)
# License: GPLv3
# Author: Gratien D'haese - gdhaese1 at its.jnj.com

# $Id $

#
# Parameters
#
PS4='$LINENO:=> ' # This prompt will be used when script tracing is turned on
typeset -x PRGNAME=${0##*/}                             # This script short name
typeset -x PRGDIR=$(dirname $0)                         # This script directory name
[[ $PRGDIR = /* ]] || {                                 # Acquire absolute path to the script
        case $PRGDIR in
                . ) PRGDIR=$(pwd) ;;
                * ) PRGDIR=$(pwd)/$PRGDIR ;;
        esac
        }
typeset -x ARGS="$@"                                    # the script arguments
[[ -z "$ARGS" ]] && ARGS="(empty)"                      # is used in the header
typeset -x PATH=/usr/local/CPR/bin:/sbin:/usr/sbin:/usr/bin:/usr/xpg4/bin:$PATH:/usr/ucb:.
typeset -r platform=$(uname -s)                         # Platform
typeset -r model=$(uname -m)                            # Model
typeset -r HOSTNAME=$(uname -n)                         # hostname
typeset os=$(uname -r); os=${os#B.}                     # e.g. 11.31

typeset -x	ERRcode=0				# exit code (default 0)
typeset -r	CMVIEWCONCL=/usr/sbin/cmviewconcl
typeset -r	CMVIEWCL=/usr/sbin/cmviewcl
typeset -r	CMGETPKGENV=/usr/sbin/cmgetpkgenv
typeset -r	SWLIST=/usr/sbin/swlist
typeset -r	CONCLUSR=conclusr			# the cc user

typeset -r	LOGFILE=/var/tmp/$PRGNAME-$(date '+%Y%m%d-%H%M').log
typeset		TMPDIR=$( mktemp -d /tmp -p ${PRGNAME}.$$ )
typeset         TMPFILE1=$TMPDIR/${PRGNAME}_1.$$
typeset         TMPFILE2=$TMPDIR/${PRGNAME}_2.$$
typeset		CCCONFIG_FILE=$TMPDIR/CCCONFIG_FILE.$$
typeset		CCCONPKG_FILE=$TMPDIR/CCCONPKG_FILE.$$
typeset		PRIMARY_CONF_FILE=$TMPDIR/PRIMARY_CONF_FILE.$$
typeset		RECOVERY_CONF_FILE=$TMPDIR/RECOVERY_CONF_FILE.$$
typeset -r	SENDMAIL=/usr/lib/sendmail   # used by function GenerateHTMLMail
typeset		mailto="DL-NCSBE-ITSGTSCMonitor3@ITS.JNJ.com"

#
# Functions
#
function _check_continental_cluster_software
{
    # T2346BA  A.08.00.00     HP Continentalclusters
    $SWLIST T2346BA,r\>=A.08.00.00 >/dev/null 2>&1
    return $?
}

function _echo
{
	case $platform in
		Linux|Darwin) arg="-e " ;;
	esac
	echo $arg "$*"
} # echo is not the same between UNIX and Linux

function _note
{
	_echo " ** $*"
} 

function _error
{
	printf " *** ERROR: $* \n"
	_cleanup_tmp_files
	exit 1
}

function _warning
{
	printf " *** WARN: $* \n"
}

function _ok
{
	echo "[  OK  ]"
}

function _nok
{
	ERRcode=$((ERRcode + 1))
	echo "[FAILED]"
}

function _skip
{
	echo "[ SKIP ]"
}

function _warn
{
	echo "[ WARN ]"
}

function _mail
{
	[ -s "$LOGFILE" ] || LOGFILE=/dev/null
	expand "$LOGFILE" | mailx -s "$*" $mailto
}

function _askYN
{
	# input arg1: string Y or N; arg2: string to display
	# output returns 0 if NO or 1 if YES so you can use a unary test for comparison
	typeset answer

	case "$1" in
		Y|y)	order="Y/n" ;;
		*)	order="y/N" ;;
	esac

	_echo "$2 $order ? \c"
	read answer

	case "$1" in
		Y|y)
			if [[ "${answer}" = "n" ]] || [[ "${answer}" = "N" ]]; then
				return 0
			else
				return 1
			fi
			;;
		*)
			if [[ "${answer}" = "y" ]] || [[ "${answer}" = "Y" ]]; then
				return 1
			else
				return 0
			fi
			;;
	esac

}

function _line
{
	typeset -i i
	while (( i < 95 )); do
		(( i+=1 ))
		echo "${1}\c"
	done
	echo
}

function _banner
{
	# arg1 "string to print next to Purpose"
	cat - <<-EOD
	$(_line "#")
	$(_print 22 "Script:" "$PRGNAME")
	$(_print 22 "Arguments:" "$ARGS")
	$(_print 22 "Purpose:" "$1")
	$(_print 22 "OS Release:" "$os")
	$(_print 22 "Model:" "$model")
	$(_print 22 "Host:" "$HOSTNAME")
	$(_print 22 "User:" "$(whoami)")
	$(_print 22 "Date:" "$(date +'%Y-%m-%d @ %H:%M:%S')")
	$(_print 22 "Log:" "$LOGFILE")
	$(_line "#")
	EOD
}

function _print
{
	# arg1: counter (integer), arg2: "left string", arg3: "right string"
	typeset -i i
	i=$(_isnum $1)
	[[ $i -eq 0 ]] && i=22	# if i was 0, then make it 22 (our default value)
	printf "%${i}s %-80s " "$2" "$3"
}

function _whoami
{
	if [ "$(whoami)" != "root" ]; then
		_error "$(whoami) - You must be root to run this script $PRGNAME"
	fi
}

function _osrevision
{
	case $platform in
		HP-UX) : ;;
		*) _error "Script $PRGNAME does not support platform $platform" ;;
	esac
	_print 3 "**" "Running on $platform $os" ; _ok
}

function _is_var_empty
{
	[[ -z "$1" ]] && return 1
	return 0
}

function _date
{
	echo $(date '+%Y-%b-%d')	# format: 2012-Aug-06
}

function _my_grep
{
	# input arg1: "string to find" arg2: "string to be searched"
	echo "$2" | grep -q "$1"  && echo 1 || echo 0
}

function _isnum
{
	echo $(($1+0))		# returns 0 for non-numeric input, otherwise input=output
}


# MASKS array is used to find the CIDR number
set -A MASKS \
        0 \
        2147483648 3221225472 3758096384 4026531840 \
        4160749568 4227858432 4261412864 4278190080 \
        4286578688 4290772992 4292870144 4293918720 \
        4294443008 4294705152 4294836224 4294901760 \
        4294934528 4294950912 4294959104 4294963200 \
        4294965248 4294966272 4294966784 4294967040 \
        4294967168 4294967232 4294967264 4294967280 \
        4294967288 4294967292 4294967294 4294967295 \
        -1


function _my_ipcalc
{
    typeset -i BITS ADDRESS="$(_ip2num "$1")"

    if [[ ! -z "$2" ]]; then
        typeset -i i=0 DEC MASK="$(_ip2num "$2")"
        while [[ $i -le 32 ]]; do
             DEC=${MASKS[$i]}
             (( MASK == DEC )) && break
             i=$(( i + 1))
        done
        (( DEC < 0 )) && _error "Main: netmask [$2] seems to be invalid."
        NETADDR=$(_num2ip "$(( ADDRESS & MASK ))")
        BITS=$i
    else
        NETADDR=$(_num2ip "$ADDRESS")
        BITS=32
    fi
    echo "$NETADDR/$BITS"
}

function _quad2num
{
    if [ $# -eq 4 ]; then
        let n="${1} << 24 | ${2} << 16 | ${3} << 8 | ${4}"
        echo "${n}"
        return 0
    else
        echo "0"
        return 1
    fi
}

function _ip2num
{
	IFS="."
	_quad2num ${1}
}

function _num2ip
{
     num="$1"
     d=$(($num % 256))
     c=$(( ($num >> 8 ) % 256 ))
     b=$(( ($num >> 16) % 256 ))
     a=$(( ($num >> 24) % 256 ))
     echo "$a.$b.$c.$d"
}

function _get_network_address
{
    # get network address for the given IP address and (netmask or prefix)
    # CIDR notation
    ip="$1"
    nm="$2"

    if [ -n "$ip" -a -n "$nm" ]; then
        if [[ "$nm" = *.* ]]; then
            :
        else
            nm=$( _prefix2netmask ${nm} )
        fi
        _my_ipcalc ${ip} ${nm} | cut -d '/' -f 2
    fi
}

function _prefix2netmask
{
	pf="$1"
	echo $(_num2ip "${MASKS[$pf]}")
}

function _get_prefix
{
    # get prefix for the given IP address and mask
    ip="$1"
    nm="$2"

    if [ -n "$ip" -a -n "$nm" ]; then
        _my_ipcalc ${ip} ${nm} | cut -d '/' -f 2
    fi
}

function _validOS
{
	[[ "$os" = "11.31" ]] || _error "$PRGNAME only run on HP-UX 11.31 (and not on $os)"
	_osrevision
}

function _validSG
{
	release=$(/usr/sbin/swlist T1905CA.ServiceGuard | tail -1 | awk '{print $2}')
	rc=$(_my_grep "A.11.20" $release)
	if [[ $rc -eq 1 ]]; then
		_print 3 "**" "Serviceguard $release is valid" ; _ok
	else
		_error "Serviceguard $release is not valid (expecting A.11.20.*)"
	fi
}

function _validSGeSAP
{
	release=$(/usr/sbin/swlist T2803BA | tail -1 | awk '{print $2}')
	rc=$(_my_grep "B.05.10" $release)
	if [[ $rc -eq 1 ]]; then
		_print 3 "**" "Serviceguard Extension for SAP $release is valid" ; _ok
	else
		_print 3 "==" "Serviceguard Extension for SAP $release is not valid (expecting B.05.10)"; _warn
	fi
}

function _validCluster
{
	out=$(cmviewcl -l cluster 2>&1 | tail -1)
	echo $out | grep -q up
	rc=$?
	if [[ $rc -eq 0 ]]; then
		_print 3 "**" "A valid cluster $(echo $out | awk '{print $1}') found, which is running (up)" ; _ok
		#_print 3 " "  "$out"
		#printf "\n"	# to have a proper linefeed
	else
		_error "Cluster is not up or not configured (yet)"
	fi
}

function _check_nslookup_address
{
	# input arg: name
	# output: 0=true (name resolvable); 1=false (name not found)
	nslookup "$1" > /tmp/_check_nslookup_address.txt 2>&1
	grep -q "^Address:" /tmp/_check_nslookup_address.txt && return 0
	return 1
}

function _debug
{
	test "$DEBUG" && _note "$@"
}

function _find_and_print_x_lines
{
	# find a keyword (string) and print x nr of lines after that keyword (line of keyword included)
	# input args: $1 (string to find); $2=integer (amount of lines); $3=filename to search in
	# output: lines of text 
	awk '/'"$1"'/ {p = '"$2"'} p > 0  {print $0; p--}' $3
}

function _cmp_banner
{
	printf "primary cluster: $PRIM_CL                                      recovery cluster: $REC_CL\n"
	_line "~"
}

function _compare_general_parameters
{
	# compare the general cluster parameters between primary and recovery cluster
	# input args: none
	# output:
	ExclStr="name=|^node|^package|node:|^id=|^cluster_formation_time|^coordinator|^logout|^configuration_data_version|incarnation"
	grep -v -E '('${ExclStr}')' $PRIMARY_CONF_FILE > $TMPFILE1
	grep -v -E '('${ExclStr}')' $RECOVERY_CONF_FILE > $TMPFILE2
	cmp -s $TMPFILE1 $TMPFILE2
	if [[ $? -eq 1 ]]; then
		_print 3 "==" "The general cluster parameters do not match between $PRIM_CL and $REC_CL" ; _nok
		_cmp_banner
		sdiff -w 120 -s $TMPFILE1 $TMPFILE2
	else
		_print 3 "**" "The general cluster parameters match between $PRIM_CL and $REC_CL" ; _ok
	fi
	echo
}

function _compare_node_parameters
{
	# it is the purpose to compare node1 from primary cluster with node1 from recovery cluster
	# keep in mind that IP addresses will be different
	# input args: none
	# output:
	count_prim_cl=${#PRIMARY_NODES[@]}  # amount of nodes in array
	count_rec_cl=${#RECOVERY_NODES[@]}  # amount of nodes in array
	if [[ $count_prim_cl -ne $count_rec_cl ]]; then
		# TODO: should this become an _error?
		_print 3 "==" "The amount of nodes between primary cluster ($count_prim_cl) and recovery cluster ($count_rec_cl) is not equal" ; _nok
	fi

	# NODE contains the FQDN (the PRIMARY_CONF_FILE only contains the short hostname) -> ${NODE%%.*}
	j=0  # counter for our PRIM_IP, PRIM_NM and PRIM_SN arrays (to compare primary/recovery sides)
	for NODE in $( echo ${PRIMARY_NODES[@]} )
	do
		# grep only lines starting with "node" and $(hostname) and remove "node:$(hostname)|" too
		grep "^node" $PRIMARY_CONF_FILE | grep ${NODE%%.*} | cut -d'|' -f2- | \
		grep -v -E '(node_pr_key|boot_timestamp|mac_address|id=)' > $TMPDIR/${NODE%%.*}
		# to be able to compare we have to remove (or change) the subnets of the node, e.g. subnet 10.0.208 vs. 10.0.210
		grep ip_address $TMPDIR/${NODE%%.*} | while read LINE
		do
			echo $LINE | grep -q "name=" && {
				PRIM_IP[$j]=$( echo $LINE | grep "name=" | cut -d= -f2 )
				printf "${NODE%%.*}: ${PRIM_IP[j]}/" >> $TMPDIR/${NODE%%.*}.IPs
				}
			echo $LINE | grep -q "netmask=" && {
				PRIM_NM[$j]=$( echo $LINE | grep "netmask=" | cut -d= -f2 )
				printf "$( _get_network_address ${PRIM_IP[j]} ${PRIM_NM[j]} ) " >> $TMPDIR/${NODE%%.*}.IPs
				}
			echo $LINE | grep -q "subnet=" && {
				PRIM_SN[$j]=$( echo $LINE | grep "subnet=" | cut -d= -f2 )
				PRIM_HP[$j]=$(( $(_ip2num ${PRIM_IP[j]}) - $(_ip2num ${PRIM_SN[j]}) ))
				printf " host-part=${PRIM_HP[j]}\n" >> $TMPDIR/${NODE%%.*}.IPs
				# after subnet line we may increase of index j
				j=$(( j + 1 ))
				}
		done
	done
	# the polling_target is the default gateway (and per cluster it must be the same for all nodes)
	PRIM_GW=$( grep subnet $TMPDIR/${NODE%%.*} | grep polling_target | cut -d= -f2 )

	j=0  # reset our array counter fro REC_IP, REC_NM and REC_SN
	for NODE in $( echo ${RECOVERY_NODES[@]} )
	do
		# grep only lines starting with "node" and $(hostname) and remove "node:$(hostname)|" too
		grep "^node" $RECOVERY_CONF_FILE | grep ${NODE%%.*} | cut -d'|' -f2- | \
		grep -v -E '(node_pr_key|boot_timestamp|mac_address|id=)' > $TMPDIR/${NODE%%.*}
		grep ip_address $TMPDIR/${NODE%%.*} | while read LINE
		do
			echo $LINE | grep -q "name=" && {
				REC_IP[$j]=$( echo $LINE | grep "name=" | cut -d= -f2 )
				printf "${NODE%%.*}: ${REC_IP[j]}/" >> $TMPDIR/${NODE%%.*}.IPs
				}
			echo $LINE | grep -q "netmask=" && {
				REC_NM[$j]=$( echo $LINE | grep "netmask=" | cut -d= -f2 )
				printf "$(  _get_network_address ${REC_IP[j]} ${REC_NM[j]} ) " >> $TMPDIR/${NODE%%.*}.IPs
				}
			echo $LINE | grep -q "subnet=" && {
				REC_SN[$j]=$( echo $LINE | grep "subnet=" | cut -d= -f2 )
				REC_HP[$j]=$(( $(_ip2num ${REC_IP[j]}) - $(_ip2num ${REC_SN[j]}) ))
				printf " host-part=${REC_HP[j]}\n" >> $TMPDIR/${NODE%%.*}.IPs
				# after subnet line we may increase of index j
				j=$(( j + 1 ))
				}
		done
		# take a backup copy of recovery node file (as we will change the IP addresses etc)
		cp $TMPDIR/${NODE%%.*} $TMPDIR/${NODE%%.*}.orig
	done
	REC_GW=$( grep subnet $TMPDIR/${NODE%%.*} | grep polling_target | cut -d= -f2 )

	# to be able to compare we will replace the node IP addresses with the unique host-part
	i=0
	while [[ $i -le ${#PRIM_IP[@]} ]]
	do
		for NODE in $( echo ${PRIMARY_NODES[@]} )
		do
			echo "${PRIM_IP[i]}" | grep -q "192.168"
			if [[ $? -eq 0 ]]; then
			    # heartbeat IP address - set host part to 0
			    IP_HP=0
			else
			    IP_HP=$(( $(_ip2num ${PRIM_IP[i]}) - $(_ip2num ${PRIM_SN[i]}) ))
			fi
			SN_HP=$(( $(_ip2num ${PRIM_SN[i]}) - $(_ip2num ${PRIM_SN[i]}) ))    # should always be 0
			NM_HP=$(( $(_ip2num ${PRIM_NM[i]}) - $(_ip2num ${PRIM_NM[i]}) ))    # should always be 0
			GW_HP=$(( $(_ip2num ${PRIM_GW}) - $(_ip2num ${PRIM_SN[i]}) ))

			sed -e "s/${PRIM_IP[i]}/${IP_HP}/g" -e "s/${PRIM_NM[i]}/${NM_HP}/g" \
			-e "s/${PRIM_SN[i]}/${SN_HP}/g" -e "s/${PRIM_GW}/${GW_HP}/g" \
			< $TMPDIR/${NODE%%.*} >$TMPDIR/${NODE%%.*}-tmp
			mv $TMPDIR/${NODE%%.*}-tmp $TMPDIR/${NODE%%.*}
		done
		i=$(( i + 1 ))
	done
	i=0
	while [[ $i -le ${#REC_IP[@]} ]]
	do
		for NODE in $( echo ${RECOVERY_NODES[@]} )
		do
			# we need to add some wizard trick here for heartbeat networks (each interface has its own
			# unique address (192.168.x.y vs. 192.168.x.z) which makes them always different
			# Therefore, when we detect an subnet containing 192.168.x we copy PRIM_IP into REC_IP
			echo "${REC_IP[i]}" | grep -q "192.168"
			if [[ $? -eq 0 ]]; then
			    # heartbeat IP address - set host part to 0
			    IP_HP=0
			else
			    IP_HP=$(( $(_ip2num ${REC_IP[i]}) - $(_ip2num ${REC_SN[i]}) ))
			fi
			SN_HP=$(( $(_ip2num ${REC_SN[i]}) - $(_ip2num ${REC_SN[i]}) ))    # should always be 0
			NM_HP=$(( $(_ip2num ${REC_NM[i]}) - $(_ip2num ${REC_NM[i]}) ))    # should always be 0
			GW_HP=$(( $(_ip2num ${REC_GW}) - $(_ip2num ${REC_SN[i]}) ))

			sed -e "s/${REC_IP[i]}/${IP_HP}/g" -e "s/${REC_NM[i]}/${NM_HP}/g" \
			-e "s/${REC_SN[i]}/${SN_HP}/g" -e "s/${REC_GW}/${GW_HP}/g" \
			< $TMPDIR/${NODE%%.*} >$TMPDIR/${NODE%%.*}-tmp
			mv $TMPDIR/${NODE%%.*}-tmp $TMPDIR/${NODE%%.*}
		done
		i=$(( i + 1 ))
	done

	# remove the "name=" line from each input node file (to make comparing easier)
	for NODE in $( echo ${PRIMARY_NODES[@]} ${RECOVERY_NODES[@]} )
	do
		sed -e "/^name=/d" < $TMPDIR/${NODE%%.*} >$TMPDIR/${NODE%%.*}-tmp
		##mv $TMPDIR/${NODE%%.*}-tmp $TMPDIR/${NODE%%.*}
		cat $TMPDIR/${NODE%%.*}-tmp | grep -v "_net=" | rmnl | ssp | sort > $TMPDIR/${NODE%%.*}
	done
	# now we have to compare node per equivalent node between primary and recovery cluster
	i=0     # the first node name in array
	while [[ $i -lt $count_prim_cl ]]
	do
		cmp -s $TMPDIR/${PRIMARY_NODES[$i]%%.*} $TMPDIR/${RECOVERY_NODES[$i]%%.*}
		if [[ $? -eq 1 ]]; then
			_print 3 "==" "Node ${PRIMARY_NODES[$i]%%.*} differs from ${RECOVERY_NODES[$i]%%.*}" ; _warn
			_cmp_banner
			sdiff -w 120 -s $TMPDIR/${PRIMARY_NODES[$i]%%.*} $TMPDIR/${RECOVERY_NODES[$i]%%.*}
		else
			_print 3 "**" "Node ${PRIMARY_NODES[$i]%%.*} is equal to ${RECOVERY_NODES[$i]%%.*}" ; _ok
		fi
		i=$((i+1))
		echo
	done
	
}

function _compare_package_of_group
{
	# purpose is to compare package configuration of group $1 between primary and recover cluster
	# packages should be equal
	# input argument $1:group
	# output: done inside function
	GROUP="$1"
	# give the file a prefix "group_" as group name can be anything
	_find_and_print_x_lines "$GROUP" 5 $CCCONFIG_FILE > "$TMPDIR/group_$GROUP"
	echo "\n"
	_line "*"
	_note "Start analyzing package recovery group \"$GROUP\""
	_line "*"
	cat "$TMPDIR/group_$GROUP"
	echo
	# PACKAGE RECOVERY GROUP  Group001
	#
	#    PACKAGE                           ROLE           STATUS
	#    treasury_lab/GTSLORA1             primary        up
	#    treasury_lab_dr/GTSLORA1          recovery       down
	PACKAGENAME=$( tail -1 $TMPDIR/group_$GROUP | awk '{print $1}' | cut -d"/" -f2 )
	grep "^package:${PACKAGENAME}" $PRIMARY_CONF_FILE  > "$TMPDIR/pkg_${PACKAGENAME}_PRIM"
	grep "^package:${PACKAGENAME}" $RECOVERY_CONF_FILE > "$TMPDIR/pkg_${PACKAGENAME}_REC"


	# first check some essentials
	grep -q "autorun=enabled" "$TMPDIR/pkg_${PACKAGENAME}_PRIM"
	if [[ $? -eq 0 ]]; then
		_print 3 "**" "Package ${PACKAGENAME} setting of autorun=enabled [$PRIM_CL]" ; _ok
	else
		_print 3 "==" "Package ${PACKAGENAME} setting of autorun=enabled [$PRIM_CL]" ; _nok
	fi

	grep -q "autorun=disabled" "$TMPDIR/pkg_${PACKAGENAME}_REC"
	if [[ $? -eq 0 ]]; then
		_print 3 "**" "Package ${PACKAGENAME} setting of autorun=disabled [$REC_CL]" ; _ok
	else
		_print 3 "==" "Package ${PACKAGENAME} setting of autorun=disabled [$REC_CL]" ; _nok
	fi

	grep -q "initial_autorun=disabled" "$TMPDIR/pkg_${PACKAGENAME}_PRIM"
	if [[ $? -eq 0 ]]; then
		_print 3 "**" "Package ${PACKAGENAME} setting of initial_autorun=disabled [$PRIM_CL]" ; _ok
	else
		_print 3 "==" "Package ${PACKAGENAME} setting of initial_autorun=disabled [$PRIM_CL]" ; _nok
	fi

	grep -q "initial_autorun=disabled" "$TMPDIR/pkg_${PACKAGENAME}_REC"
	if [[ $? -eq 0 ]]; then
		_print 3 "**" "Package ${PACKAGENAME} setting of initial_autorun=disabled [$REC_CL]" ; _ok
	else
		_print 3 "==" "Package ${PACKAGENAME} setting of initial_autorun=disabled [$REC_CL]" ; _nok
	fi

	# package:GTSLORA1|node:gltdbdr1|switching=disabled
	grep "switching=" "$TMPDIR/pkg_${PACKAGENAME}_PRIM" | while read LINE
	do
		node=$( echo $LINE | cut -d"|" -f2 | cut -d: -f2 )	# nodename

		echo $LINE | grep -q "switching=enabled"
		if [[ $? -eq 0 ]]; then
			_print 3 "**" "Package ${PACKAGENAME} setting of switching=enabled on node $node [$PRIM_CL]" ; _ok
		else
			_print 3 "==" "Package ${PACKAGENAME} setting of switching=enabled on node $node [$PRIM_CL]" ; _nok
		fi
	done

	grep "switching=" "$TMPDIR/pkg_${PACKAGENAME}_REC" | while read LINE
	do
		node=$( echo $LINE | cut -d"|" -f2 | cut -d: -f2 )      # nodename

		echo $LINE | grep -q "switching=enabled"
		if [[ $? -eq 0 ]]; then
			_print 3 "**" "Package ${PACKAGENAME} setting of switching=enabled on node $node [$REC_CL]" ; _ok
		else
			_print 3 "==" "Package ${PACKAGENAME} setting of switching=enabled on node $node [$REC_CL]" ; _nok
		fi
	done

	_filter_package_output_of "$TMPDIR/pkg_${PACKAGENAME}_PRIM" 0
	_filter_package_output_of "$TMPDIR/pkg_${PACKAGENAME}_REC"  1

	# do a general compare between primary/recovery cluster package group
	cmp -s "$TMPDIR/pkg_${PACKAGENAME}_PRIM" "$TMPDIR/pkg_${PACKAGENAME}_REC"
	if [[ $? -eq 1 ]]; then
		_print 3 "==" "Package ${PACKAGENAME} differs between primary and recovery cluster" ; _warn
		_cmp_banner
		sdiff -w 120 -s "$TMPDIR/pkg_${PACKAGENAME}_PRIM" "$TMPDIR/pkg_${PACKAGENAME}_REC"
	else
		_print 3 "**" "Package ${PACKAGENAME} is exactly the same between primary and recovery cluster" ; _ok
	fi



}

function _filter_package_output_of
{
	# purpose of function is to remove lines from the pkg_${PACKAGENAME}_<PRIM|REC> file
	# so it becomes easier to compare them
	# input: pkg_${PACKAGENAME}_<PRIM|REC> file, arg2: trigger (1) to replace nodenames, IPs
	# output: pkg_${PACKAGENAME}_<PRIM|REC> file rewritten

	# first we remove "package:<PACKAGENAME>|" from input stream and some keywords
	cat ${1} | cut -d'|' -f2- | grep -v -E '(^name=|^owner=|^id=|^ip_address:|summary=|switching=|autorun)' | \
	grep -v -E '(last_run_time=|last_halt_time=|last_halt_failed=|status=|state=|available=|pid=|restart_limit=)' | \
	rmnl | ssp > ${1}.new
	mv -f ${1}.new ${1}

	# we will replace all IP addresses with their unique host-part - makes it easy to compare
	IP_SUBNET=$(  grep ^ip_subnet ${1} | grep ip_subnet= | cut -d= -f2 )

	# grab the PKG_IP from package file; as prim cluster may not be the active one use subnet line
	i=0
	grep ^ip_subnet ${1} | grep ip_address | while read LINE
	do
		PKG_IP[$i]=$( echo $LINE | cut -d= -f2 )
		PKG_HP[$i]=$(( $(_ip2num ${PKG_IP[i]}) - $(_ip2num ${IP_SUBNET}) ))
		i=$(( i + 1 ))
	done

	if [[ $2 -eq 0 ]]; then
		# collect the HORCMINST nr of primary cluster package group (should be the same for all primary pkgs)
		PRIM_HORCMINST=$( grep HORCMINST ${1} | cut -d= -f2 )
	else
		# recovery packagroup file
		REC_HORCMINST=$( grep HORCMINST ${1} | cut -d= -f2 )

		i=0
		while [[ $i -le ${#RECOVERY_NODES[@]} ]]
		do
			NODE_PRIM=${PRIMARY_NODES[i]%%.*}  # use the short primary hostname
			NODE_REC=${RECOVERY_NODES[i]%%.*}  # use the short primary hostname
			sed -e "s/$NODE_REC/$NODE_PRIM/g" \
			-e "s/HORCMINST=${REC_HORCMINST}/HORCMINST=${PRIM_HORCMINST}/g" \
			-e "s/horcmperm${REC_HORCMINST}/horcmperm${PRIM_HORCMINST}/g"  < ${1} > ${1}.new
			mv -f ${1}.new ${1}
			i=$(( i + 1 ))
		done
	fi

	# to be able to compare we will replace the recovery node IP addresses (REC_IPs) with the PRIM_IPs
	i=0
	if [[ $2 -eq 0 ]]; then
		while [[ $i -le ${#PRIM_IP[@]} ]]
		do
			IP_HP=$(( $(_ip2num ${PRIM_IP[i]}) - $(_ip2num ${IP_SUBNET}) ))
			SN_HP=$(( $(_ip2num ${PRIM_SN[i]}) - $(_ip2num ${IP_SUBNET}) ))    # should always be 0
			NM_HP=$(( $(_ip2num ${PRIM_NM[i]}) - $(_ip2num ${IP_SUBNET}) ))
			GW_HP=$(( $(_ip2num ${PRIM_GW}) - $(_ip2num ${IP_SUBNET}) ))
			sed -e "s/${PRIM_IP[i]}/${IP_HP}/g" -e "s/${PRIM_NM[i]}/${NM_HP}/g" \
			-e "s/${PRIM_SN[i]}/${SN_HP}/g" -e "s/${PRIM_GW}/${GW_HP}/g" \
			< ${1} > ${1}.new
			mv -f ${1}.new ${1}
			i=$(( i + 1 ))
		done
	else
		while [[ $i -le ${#REC_IP[@]} ]]
		do
			IP_HP=$(( $(_ip2num ${REC_IP[i]}) - $(_ip2num ${IP_SUBNET}) ))
			SN_HP=$(( $(_ip2num ${REC_SN[i]}) - $(_ip2num ${IP_SUBNET}) ))    # should always be 0
			NM_HP=$(( $(_ip2num ${REC_NM[i]}) - $(_ip2num ${IP_SUBNET}) ))
			GW_HP=$(( $(_ip2num ${REC_GW}) - $(_ip2num ${IP_SUBNET}) ))
			sed -e "s/${REC_IP[i]}/${IP_HP}/g" -e "s/${REC_NM[i]}/${NM_HP}/g" \
			-e "s/${REC_SN[i]}/${SN_HP}/g" -e "s/${REC_GW}/${GW_HP}/g" \
			< ${1} > ${1}.new
			mv -f ${1}.new ${1}
			i=$(( i + 1 ))
		done
	fi

	# for SAP webdispatchers multiple IP addresses may be defined
	i=0
	while [[ $i -le ${#PKG_IP[@]} ]]
	do
		sed -e "s/${PKG_IP[i]}/${PKG_HP[i]}/g" < ${1} > ${1}.new
		mv -f ${1}.new ${1}
		i=$(( i + 1 ))
	done
}

function _show_nodes_IP_addresses
{
	# purpose is to show an overview of the nodes IP addresses
	# input args: none
	# output : inside this function
	_note "Overview of the IP addresses/CIDR per node"
	_line "*"
	_note "Primary Cluster $PRIM_CL nodes are:"
	i=0
	while [[ $i -le ${#PRIMARY_NODES[@]} ]]
	do
		if [[ -f $TMPDIR/${PRIMARY_NODES[i]%%.*}.IPs ]]; then
			cat $TMPDIR/${PRIMARY_NODES[i]%%.*}.IPs
		fi
		i=$(( i + 1 ))
	done
	echo
	_note "Recovery Cluster $REC_CL nodes are:"
	i=0
	while [[ $i -le ${#RECOVERY_NODES[@]} ]]
	do
		if [[ -f $TMPDIR/${RECOVERY_NODES[i]%%.*}.IPs ]]; then
			cat $TMPDIR/${RECOVERY_NODES[i]%%.*}.IPs
		fi
		i=$(( i + 1 ))
	done
	echo
}

function _cleanup_tmp_files
{
	rm -f $TMPFILE1 $CCCONPKG_FILE $TMPFILE2 $CCCONFIG_FILE
	rm -f /tmp/_check_nslookup_address.txt
	rm -rf $TMPDIR
}

function _ssh_test_conclusr
{
    typeset node="$1"
    typeset conf_file="$2"
    typeset name_cl="$3"
    su - $CONCLUSR -c "ssh  -n -o NumberOfPasswordPrompts=0 -o StrictHostKeyChecking=false -l $CONCLUSR $node  hostname" > $TMPFILE2 2>$TMPFILE2
    if [[ $? -eq 0 ]]; then
        _print 3 "**" "User $CONCLUSR can execute commands on node $node" ; _ok
        # ssh works so now we can collect the output from cmviewcl -v via $CONCLUSR
        su - $CONCLUSR -c "ssh -q -n -o NumberOfPasswordPrompts=0 -o StrictHostKeyChecking=false \
        -l $CONCLUSR $node /usr/sbin/cmviewcl -f line -v" > "$conf_file" 2>/dev/null
        if [[ $? -eq 0 ]]; then
            # we print the short hostname with ${node%%.*}
            _print 3 "**" "Save the configuration of cluster $name_cl (via node ${node%%.*})" ; _ok
        else
            _print 3 "==" "Save the configuration of cluster $name_cl (via node ${node%%.*})" ; _nok
        fi
    else
        _print 3 "==" "User $CONCLUSR can execute commands on node ${node%%.*}" ; _nok
        grep -q "Account" $TMPFILE2 && _note "$(grep Account $TMPFILE2)"
    fi
}

function _compare_files_between
{
    # purpose to to compare the output files of swlist, patches and state between the nodes and list differences
    # input arg1: prefix (of input files to use); arg2: list of nodes
    PREFIX="$1"
    set -A NODES $2
    typeset -i i=0 j=0 n=${#NODES[@]}
    case $PREFIX in
	swlist) msg="Compare the swlist output"  ;;
	patches)msg="Compare the patches installed" ;;
	state)  msg="Show incorrect states of installed products" ;;
    esac
    while [[ $i -lt $((n - 1)) ]]; do
	# we will compare in following order:
	# n0 n1; n0 n2; n0 n3; n0 n4; n1 n2; n1 n3; n1 n4; n2 n3; n2 n4; n3 n4
        #_print 3 "**" "$msg between ${NODES[i]%%.*} and ${NODES[$((j+1))]%%.*}"
	cmp -s $TMPDIR/${NODES[i]%%.*}.$PREFIX $TMPDIR/${NODES[$((j+1))]%%.*}.$PREFIX
        if [[ $? -eq 1 ]]; then
            _print 3 "==" "$msg between ${NODES[i]%%.*} and ${NODES[$((j+1))]%%.*}" ; _nok
	    sdiff -w 120 -s $TMPDIR/${NODES[i]%%.*}.$PREFIX $TMPDIR/${NODES[$((j+1))]%%.*}.$PREFIX
	else
            _print 3 "**" "$msg between ${NODES[i]%%.*} and ${NODES[$((j+1))]%%.*}" ; _ok
	fi
	j=$(( j + 1))
	if [[ $j -eq $((n - 1)) ]]; then
	    i=$(( i + 1 ))  # increment left node counter
            j=$i            # reset right node counter (to avoid already compared nodes)
	fi
    done
}


function MailHeaders
{
    # input parameter (string of text) is used for subject line
    echo "From: ${FromUser:-root}"
    echo "To: ${ToUser:-root}"
    echo "Subject: $*"
    echo "Content-type: text/html"
    echo "$*" | grep -q "FAILED"
    if [[ $? -eq 0 ]]; then
        echo "Importance: high"
        echo "X-Priority: 1"
    else
        echo "Importance: normal"
        echo "X-Priority: 3"
    fi
    echo ""
}

function StartOfHtmlDocument
{
    # define HTML style (this function should be called 1st)
    echo '<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 3.2//EN">'
    echo '<HTML> <HEAD>'
    echo "<META NAME=\"CHANGED\" CONTENT=\" $(date) \">"
    echo "<META NAME=\"DESCRIPTION\" CONTENT=\"$PRGNAME\">"
    echo "<META NAME=\"subject\" CONTENT=\"Results of $PRGNAME\">"
    echo '<style type="text/css">'
    echo "Pre     {Font-Family: Courier-New, Courier;Font-Size: 10pt}"
    echo "BODY        {FONT-FAMILY: Arial, Verdana, Helvetica, Sans-serif; FONT-SIZE: 12pt;}"
    echo "A       {FONT-FAMILY: Arial, Verdana, Helvetica, Sans-serif}"
    echo "A:link      {text-decoration: none}"
    echo "A:visited   {text-decoration: none}"
    echo "A:hover     {text-decoration: underline}"
    echo "A:active    {color: red; text-decoration: none}"
    echo "H1      {FONT-FAMILY: Arial, Verdana, Helvetica, Sans-serif;FONT-SIZE: 20pt}"
    echo "H2      {FONT-FAMILY: Arial, Verdana, Helvetica, Sans-serif;FONT-SIZE: 14pt}"
    echo "H3      {FONT-FAMILY: Arial, Verdana, Helvetica, Sans-serif;FONT-SIZE: 12pt}"
    echo "DIV, P, OL, UL, SPAN, TD"
    echo "{FONT-FAMILY: Arial, Verdana, Helvetica, Sans-serif;FONT-SIZE: 11pt}"
    echo "</style>"
}

function SetTitleOfDocument
{
    # define title of HTML document and start of body (should be called 2th)
    echo "<TITLE>${PRGNAME} - $(hostname)</TITLE>"
    echo "</HEAD>"
    echo "<BODY>"
    echo "<CENTER>"
    echo "<H1> <FONT COLOR=blue>"
    echo "<P><hr><B>${PRGNAME} - $(hostname) - $*</B></P>"
    echo "</FONT> </H1>"
    echo "<hr> <FONT COLOR=blue> <small>Created on \"$(date)\" by $PRGNAME</small> </FONT>"
    echo "</CENTER>"
}

function EndOfHtmlDocument
{
    echo "</BODY> </HTML>"
}

function CreateTable
{
    # start of a new HTML table
    echo "<table width=100% border=0 cellspacing=0 cellpadding=0 style=\"border: 0 solid #000080\">"
}

function EndTable
{
    # end of existing HTML table
    echo "</table>"
}

function TableRow
{
    # function should be called when we are inside a table
    typeset row="$1"
    columns=""
    typeset color=${2:-white}  # default background color is white
    typeset -i c=0             # counter of columns (0, 1 and 2)

    case "$( echo "$row" | cut -c1-2 )" in
        "**" ) columns[0]='**'    # lines   with '**' means success
		#row=$( echo "$row" | cut -c4- )
		row=$( echo "$row" | cut -c3- )
                ;;
	"==" ) columns[0]="=="    # lines   with '==' indicates a failure
                #row=$( echo "$row" | cut -c4- )
                row=$( echo "$row" | cut -c3- )
                ;;
	*     ) columns[0]=""  ;;  # other types of lines
    esac
    columns[1]=$( echo "$row" |  sed -e 's/\(.*\)\[.*/\1/' )   # the text without ** and [ ... ]
    echo "$row" | grep -q '\['
    if [[ $? -eq 0 ]]; then
        columns[2]=$( echo "$row" | sed -e 's/.*\(\[.*\]\)/\1/' )  # contains [  OK  ]
    else
        columns[2]=""
    fi
    # set the colors correct
    case "$( echo "${columns[2]}" | sed -e 's/\[//;s/\]//' -e 's/ //g' -e 's/\&nbsp;//g' )" in
	"OK")		color="#00CA00" ;;	# greenish
	"FAILED")	color="#FF0000" ;;	# redish
	"WARN")
		if [[ "${columns[0]}" = "**" ]]; then
			color="#E8E800"		# yellow alike
		else
			color="#FB6104"		# orange alike
		fi
		;;
	"SKIP")		color="#000000" ;;	# black
    esac
    
    echo "<tr bgcolor=\"$color\">"

    while (( $c < ${#columns[@]} )); do
	if [[ "$color" = "#FF0000" ]] || [[ "$color" = "#FB6104" ]] || [[ "$color" = "#000000" ]]; then
		# foreground color white if background color is redish or orangish or black
		echo "  <td align=left><font size=-1 color="white">\c"
	else
        	echo "  <td align=left><font size=-1>\c"
	fi
	#str=$( echo "${columns[c]}" | sed -e 's/^[:blank:]*//;s/[:blank:]*$//' )  # remove leading/trailing spaces
	str="${columns[c]}"
        if [[ $c -eq 1 ]]; then
		[[ "$color" = "white" ]] && printf "<pre style=\"font-family: Courier-New;\">"  #was Verdana
		printf "<b>$str</b>"
		[[ "$color" = "white" ]] && printf "</pre>"
	else
		printf "$str"
	fi
        echo "</td>"
        c=$((c + 1))
    done
    echo "</tr>"
}

function str_replace
{
    # input: $1:LINE; $2:character; $:new-character
    echo "$1" | sed -e 's/'"$2"'/'"$3"'/g'
}

function GenerateHTMLMail
{
    # input parameter (string of text) is used for subject line
    MailHeaders "$*"
    StartOfHtmlDocument
    SetTitleOfDocument "$*"
    CreateTable
    cat $LOGFILE | while read LINE
    do
        #TableRow "$LINE"
        TableRow "$( str_replace "$LINE" " " "\&nbsp;" )"
    done
    EndTable
    EndOfHtmlDocument
}

###############################################################################
###
### MAIN
###
###############################################################################

{  # as wrapper to log everything into $LOGFILE
_whoami
_banner "Continental Cluster Consistency Checks"
_validOS

# create the TMPDIR
[[ -d $TMPDIR ]] && rm -rf $TMPDIR    # remove old TMPDIR
mkdir -p $TMPDIR || _error "Could not create the temporary directory $TMPDIR"
chmod 777 $TMPDIR   # conclusr must be able to write into it

###############################################################################
_check_continental_cluster_software
if [[ $? -eq 0 ]]; then
    _print 3 "**" "Continental Cluster Software T2346BA,r=>A.08.00.00 present" ; _ok
else
    _error "Continental Cluster Software T2346BA not present or release <A.08.00.00"
fi

# check if SG 11.20 is installed
_validSG

###############################################################################
# do we have the cmviewconcl command present? The $CCCONFIG_FILE will be used later
type $CMVIEWCONCL >/dev/null 2>&1
if [[ $? -eq 0 ]]; then
    _print 3 "**" "Collecting output of command $CMVIEWCONCL"
    $CMVIEWCONCL </dev/null >$CCCONFIG_FILE 2>&1   # added </dev/null to avoid hangs when run in bg
    if [[ $? -eq 0 ]]; then
        _ok
    else
        _nok
    fi
else
   _error "Required Command $CMVIEWCONCL not found"
fi

###############################################################################
# Do we have the conclusr locally defined in the passwd file?
grep ^${CONCLUSR} /etc/passwd >/dev/null 2>&1
if [[ $? -eq 0 ]]; then
    _print 3 "**" "Continental Cluster user ${CONCLUSR} is present on this node $HOSTNAME" ; _ok
else
    _error "Continental Cluster user ${CONCLUSR} seems to be unknown"
fi

###############################################################################
# show continental cluster name
CC_NAME=$( grep "^CONTINENTAL CLUSTER" $CCCONFIG_FILE | awk '{print $3,$4}' )
if [[ ! -z "$CC_NAME" ]]; then
    _print 3 "**" "Continental Cluster name is $CC_NAME" ; _ok
else
    _print 3 "==" "Continental Cluster name is unknown" ; _nok
fi

###############################################################################
# get names of primary and recovery cluster
PRIM_CL=$( _find_and_print_x_lines "PRIMARY CLUSTER" 2 $CCCONFIG_FILE | tail -1 | awk '{print $1}' )
REC_CL=$( grep "RECOVERY CLUSTER" $CCCONFIG_FILE | awk '{print $3}' )
if [[ ! -z "$PRIM_CL" ]]; then
    _print 3 "**" "Primary cluster name is $PRIM_CL" ; _ok
else
   _print 3 "==" "Primary cluster name is unknown" ; _nok
fi
if [[ ! -z "$REC_CL" ]]; then
    _print 3 "**" "Recovery cluster name is $REC_CL" ; _ok
else
    _print 3 "==" "Recovery cluster name is unknown" ; _nok
fi

###############################################################################
# Show which cluster is active and define ACTIVE_CL variable
PRIM_CL_STATUS=$( _find_and_print_x_lines "PRIMARY CLUSTER" 2 $CCCONFIG_FILE | tail -1 | awk '{print $2}' )
if [[ ! -z "$PRIM_CL_STATUS" ]]; then
    if [[ "$PRIM_CL_STATUS" = "up" ]]; then
        _print 3 "**" "Primary cluster ($PRIM_CL) status is \"$PRIM_CL_STATUS\"" ; _ok
        ACTIVE_CL=$PRIM_CL
    else
        _print 3 "**" "Primary cluster ($PRIM_CL) status is \"$PRIM_CL_STATUS\"" ; _warn
        # check now if recovery cluster is up!
        grep recovery $CCCONFIG_FILE | grep -q up
        if [[ $? -eq 0 ]]; then
            _print 3 "**" "Recovery cluster ($REC_CL) status is \"up\"" ; _ok
            ACTIVE_CL=$REC_CL
        else
            _print 3 "==" "Recovery cluster status is down" ; _nok
            ACTIVE_CL=""
        fi
    fi
else
    _print 3 "==" "Primary and recovery cluster status are not known" ; _nok
    ACTIVE_CL=""
fi

###############################################################################
# verify if ccconfpkg package is available (we need this to find all the nodes on both sides)
$CMVIEWCL -f line -v -p ccconfpkg > $CCCONPKG_FILE 2>&1
if [[ $? -eq 0 ]]; then
    _print 3 "**" "Continental Cluster Configuration package ccconfpkg is available" ; _ok
else
    _error "Continental Cluster Configuration package ccconfpkg not found"
fi

###############################################################################
# collect the nodes of the PRIMARY CLUSTER (use file $CCCONPKG_FILE to retrieve the nodes)
set -A PRIMARY_NODES $( grep "dts/ccconf/CLUSTER_NAME:${PRIM_CL}|dts/ccconf/CC_NODE_NAME=" $CCCONPKG_FILE | cut -d= -f2 )
if [[ ${#PRIMARY_NODES[@]} -gt 0 ]]; then
    _print 3 "**" "Primary Cluster nodes are $(echo ${PRIMARY_NODES[@]})" ; _ok
else
    _print 3 "==" "Primary Cluster [$PRIM_CL] has no nodes defined" ; _nok
fi

###############################################################################
# collect the nodes of the RECOVERY CLUSTER (use file $CCCONPKG_FILE to retrieve the nodes)
set -A RECOVERY_NODES $( grep "dts/ccconf/CLUSTER_NAME:${REC_CL}|dts/ccconf/CC_NODE_NAME=" $CCCONPKG_FILE | cut -d= -f2 )
if [[ ${#RECOVERY_NODES[@]} -gt 0 ]]; then
    _print 3 "**" "Recovery Cluster nodes are $(echo ${RECOVERY_NODES[@]})" ; _ok
else
    _print 3 "==" "Recovery Cluster [$REC_CL] has no nodes defined" ; _nok
fi


###############################################################################
# run ssh connectivity tests towards all remotes nodes for the CONCLUSR user
# Primary nodes & when successfull grab the output of the cluster running

for NODE in $( echo ${PRIMARY_NODES[@]} )
do
    _ssh_test_conclusr $NODE $PRIMARY_CONF_FILE $PRIM_CL
done

# Recovery nodes & when successfull grab the output of the cluster running
for NODE in $( echo ${RECOVERY_NODES[@]} )
do
    _ssh_test_conclusr $NODE $RECOVERY_CONF_FILE $REC_CL
done

###############################################################################
# compare the swlist output of all our nodes (should al be the same)
for NODE in $( echo ${PRIMARY_NODES[@]} ${RECOVERY_NODES[@]} )
do
    _print 3 "**" "Collecting swlist output from node $NODE"
    su - $CONCLUSR -c "ssh  -n -o NumberOfPasswordPrompts=0 -o StrictHostKeyChecking=false -l $CONCLUSR $NODE \
	/usr/sbin/swlist 2>/dev/null" 2>/dev/null | grep -v -E '(\#)' | rmnl | ssp > $TMPDIR/${NODE%%.*}.swlist && _ok || _nok
    _print 3 "**" "Collecting patches from node $NODE"
    su - $CONCLUSR -c "ssh  -n -o NumberOfPasswordPrompts=0 -o StrictHostKeyChecking=false -l $CONCLUSR $NODE \
	/usr/contrib/bin/show_patches 2>/dev/null" 2>/dev/null | grep -v -E '(\#)' | rmnl | ssp > $TMPDIR/${NODE%%.*}.patches && _ok || _nok
    _print 3 "**" "Collecting swlist state output from node $NODE"
    su - $CONCLUSR -c "ssh  -n -o NumberOfPasswordPrompts=0 -o StrictHostKeyChecking=false -l $CONCLUSR $NODE \
	/usr/sbin/swlist -l fileset -a state 2>/dev/null" 2>/dev/null | grep -v -E '(configured|\#)' | rmnl | ssp > $TMPDIR/${NODE%%.*}.state && _ok || _nok
done

_compare_files_between swlist "$( echo ${PRIMARY_NODES[@]} ${RECOVERY_NODES[@]} )"
_compare_files_between patches "$( echo ${PRIMARY_NODES[@]} ${RECOVERY_NODES[@]} )"
_compare_files_between state "$( echo ${PRIMARY_NODES[@]} ${RECOVERY_NODES[@]} )"

###############################################################################
# Check if we have a valid cluster configuration overview of the primary site
### TODO: make a function for this
if [[ -f $PRIMARY_CONF_FILE ]]; then
    # we will first remove the login banner from the cmviewcl output
    #cat $PRIMARY_CONF_FILE | \
    #awk "/name=$PRIM_CL/,/logout/ {if (\$0 !~ "name=$PRIM_CL" && \$0 !~ "logout") print}" \
    #> $TMPFILE2
    #cp $TMPFILE2 $PRIMARY_CONF_FILE
    # verify if the output makes sense by grepping "network_failure_detection" string (as
    # we are sure this must be in there)
    grep -q "network_failure_detection" $PRIMARY_CONF_FILE
    if [[ $? -eq 0 ]]; then
        _print 3 "**" "The configuration of cluster $PRIM_CL seems valid" ; _ok
    else
        # if the input file is invalid no need to continue
        _error "The configuration of cluster $PRIM_CL seems invalid - see file $PRIMARY_CONF_FILE"
    fi
else
    _error "The configuration of cluster $PRIM_CL was not created??"
fi

###############################################################################
# Check if we have a valid cluster configuration overview of the recovery site
if [[ -f $RECOVERY_CONF_FILE ]]; then
    # we will first remove the login banner from the cmviewcl output
    #cat $RECOVERY_CONF_FILE | \
    #awk "/name=$REC_CL/,/logout/ {if (\$0 !~ "name=$REC_CL" && \$0 !~ "logout") print}" \
    #> $TMPFILE2
    #cp $TMPFILE2 $RECOVERY_CONF_FILE
    # verify if the output makes sense by grepping "network_failure_detection" string (as
    # we are sure this must be in there)
    grep -q "network_failure_detection" $RECOVERY_CONF_FILE
    if [[ $? -eq 0 ]]; then
        _print 3 "**" "The configuration of cluster $REC_CL seems valid" ; _ok
    else
        # if the input file is invalid no need to continue
        _error "The configuration of cluster $REC_CL seems invalid - see file $RECOVERY_CONF_FILE"
    fi
else
    _error "The configuration of cluster $REC_CL was not created??"
fi

###############################################################################
# Start comparing the primary and recovery cluster configuration
# part: general parameters
_compare_general_parameters

###############################################################################
# Start comparing the node parameters
# part: node paramaters
_compare_node_parameters


###############################################################################
# display the nodes IPs
_show_nodes_IP_addresses

###############################################################################
# part: go over the package groups
for GROUP in $( grep "PACKAGE RECOVERY GROUP" $CCCONFIG_FILE | awk '{print $4}' )
do
	_compare_package_of_group $GROUP
done

# write ERRcode to file (as we would loose it after next }!)
echo $ERRcode > /tmp/ERRcode.c4

} 2>&1 | tee $LOGFILE # tee is used in case of interactive run

#
# Picking up ERRcode and do mail handling
#
#  check error count
if [[  -f /tmp/ERRcode.c4 ]] ; then
	# now we can do proper error handling
	ERRcode=$(cat /tmp/ERRcode.c4)
	if [[ $ERRcode -eq 0 ]]; then
		echo | tee -a $LOGFILE
		_print 3 "**" "GREAT JOB - no errors found in our Continental Cluster setup" | tee -a $LOGFILE
		_ok | tee -a $LOGFILE
	else
		echo | tee -a $LOGFILE
		_print 3 "==" "Errors found in our Continental Cluster setup" | tee -a $LOGFILE
		_nok | tee -a $LOGFILE
	fi
fi

_line "+" | tee -a $LOGFILE
_note "$(date '+%d-%m-%Y %H:%M:%S') - Log file is saved as $LOGFILE" | tee -a $LOGFILE
_line "+" | tee -a $LOGFILE

CC_NAME=$( grep "^CONTINENTAL CLUSTER" $CCCONFIG_FILE | awk '{print $3,$4}' )
if [[ $ERRcode -eq 0 ]]; then
	GenerateHTMLMail "[SUCCESS] Results of Continental Cluster [$CC_NAME] Configuration Checks" | $SENDMAIL -t "$mailto"
else
	GenerateHTMLMail "[FAILURE] Results of Continental Cluster [$CC_NAME] Configuration Checks" | $SENDMAIL -t "$mailto"
fi

# 
# The End and cleanup
#
_cleanup_tmp_files
exit $ERRcode
