#!/usr/dt/bin/dtksh
# Author: Bolek Mynarski <bmynars@ncsus.jnj.com>
#
# $Revision: 1.5 $
# $Date: 2006/08/10 12:20:23 $
# $Header: /ncs/cvsroot/ncsbin/utils/random.sh,v 1.5 2006/08/10 12:20:23 bmynars Stab $ 
# $Id: random.sh,v 1.5 2006/08/10 12:20:23 bmynars Stab $
# $Locker:  $
# History: Check the bottom of the file for revision history
# ----------------------------------------------------------------------------

# Purpose of this program is to random generate a list of servers, in our case.
# The premise of the script is very simple:
#      - use KORN built in RANDOM variable number generator and use it as means
#        of extracting our random element from the list provided.

typeset -x PRGNAME=${0##*/}
typeset -x PRGDIR=${0%/*}

[[ $PRGDIR = . || $PRGDIR != /* ]] && PRGDIR=$(pwd)


function _note {
	echo " ** $*"
}


if [ $# -ne 2 ]; then
	cat <<-eof
	Usage: $PRGNAME <flat file> <number>
	
	eof
	exit 1
fi

typeset list=$1
typeset num=$2
typeset -i i=0


[ -f $list ] || { _note "$PRGNAME ($LINENO): <$list> does not exist!"; exit 1; }

if [ $(wc -l < $list) -gt 4095 ]; then
	cat <<-eof
	$PRGNAME ($LINENO):
	    Number of elements is too large for $SHELL to handle.
        Use following to remedy the issue:
            split $list


        This will generate files that will be no larger than 1000 lines.
	eof
	exit
fi

case $num in
	0) _note "$PRGNAME ($LINENO):\n\t[$num] is no allowed."; exit 1 ;;
	+([0-9])) : ;; # We have a number
	*) _note "$PRGNAME ($LINENO):\n\t[$num] is not a valid number"; exit 1 ;;
esac

while read LINE; do
	elements[(( i+=1 ))]="$LINE"
done < $list


[ ${#elements[@]} -lt 1 -o ${#elements[@]} -lt $num ] && \
	{ _note "$PRGNAME ($LINENO):
	 Not enough elements provided or number is larger than total of element list"; exit 1; }

# ------------------------------------------------------------------------------
#                                   MAIN BODY
# ------------------------------------------------------------------------------

while [ $num -gt 0 ]; do
	(( num-=1 ))
	element=$(( $RANDOM % ${#elements[@]} ))
	
	[ $element -eq 0 ] && element=1

	echo ${elements[$element]}
	
	# Popping element from the servers array
	elements[$element]=''
	
	# To make sure we can handle names with blank spaces, following
	# routine replaced: set -A elements $(echo ${elements[@]}).  Also,
	# a temp array had to be created.  Otherwise, duplicates were still
	# appearing in the selection.  This way we are ensuring that one and
	# only one element will be displayed at any draw.
	
	typeset -i c=0
	for k in "${elements[@]}"; do
		[[ -n $k ]] && tmp[(( c+=1 ))]="$k"
	done

	unset elements
	
	typeset -i c=0
	for k in "${tmp[@]}"; do
		elements[(( c+=1 ))]="$k"
	done
	unset tmp
done

# ----------------------------------------------------------------------------
# $Log: random.sh,v $
# Revision 1.5  2006/08/10 12:20:23  bmynars
# Fixed the problem of "re-appearing" duplicate element when
# a larger randomized selection was made.  Fix involved introduction of
# creation of a temporary array after skipping a blanked element in the
# main array.  After tmp array is created, main array is blanked and re-
# populated with the content of the tmp array.
#
# Revision 1.4  2006/04/08 21:46:32  bmynars
# Improved script by following:
# 	- increased number of elements from 1023 to 4095
# 	- enabled correct handling of names with spaces
# 	- made script messages generic so anything could
# 	  be used for randomizing.
#
# Revision 1.3  2006/04/05 00:41:03  bmynars
# Fixed formatting and added a check for '0'
#
# Revision 1.2  2006/04/05 00:37:19  bmynars
# Fixed randomness issue.  Each time we will have uniqe servers
#
# Revision 1.1  2006/04/04 19:37:42  bmynars
# First take on random host genrator
#
# $RCSfile: random.sh,v $
# $Source: /ncs/cvsroot/ncsbin/utils/random.sh,v $
# $State: Stab $
# ----------------------------------------------------------------------------
