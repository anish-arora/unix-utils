#!/usr/dt/bin/dtksh
# Bolek Mynarski <bmynars@its.jnj.com>
#
# $Revision: 1.5 $
# $Date: 2011/04/01 19:47:49 $
# $Header: /ncs/cvsroot/ncsbin/utils/zoneInfo.sh,v 1.5 2011/04/01 19:47:49 bmynars Exp $
# $Id: zoneInfo.sh,v 1.5 2011/04/01 19:47:49 bmynars Exp $
# $Locker:  $
# History: Check the bottom of the file for revision history
# ----------------------------------------------------------------------------
# This script is used to query Centrify managed UNIX/Linux servers.  It has
# been adopted from a HP-UX version.

typeset -x PRGNAME=${0##*/}
typeset -x PRGDIR=${0%/*}
typeset -x PATH=$PATH
typeset lhost=$(uname -n)
typeset os=$(uname -s)
typeset centdir=/usr/share/centrifydc
typeset PATH=$centdir/bin:$PATH
typeset principal=""

[[ $PRGDIR == /* ]] || PRGDIR=$(pwd)

# ------------------------------------------------------------------------------
#                                FUNCTIONS
# ------------------------------------------------------------------------------

function _note {
	print -- " ** $*"
}

function _adZone {
	typeset zone
	adinfo -z 2> /dev/null | read zone
	if [ -n "$zone" ]; then
		echo "${zone##*/}"
	else
		echo "NoZone"
	fi
}

function _osCheck {
	# Currently we only check Linux systems as they
	# might be running an incorrect version of KoRN
	# shell.  We want real KSH93 instead of PDKSh or
	# some other concoction created by open source.

	typeset version

	case $os in
		Linux)
			version=$(rpm -qi ksh | awk '/^Version / { print $3 }')
			if [[ $version == 93* ]]; then
				: # Everything is OK
			else
				_note "Either KoRN is not present or incorrect version is installed (${version:-NotInstalled})."
				exit
			fi
		;;
		SunOS)
			_note "[$os] is not supported at this time.\n"
			exit
		;;
	esac
}

function _line {
	typeset -i i=0
	for (( i = 0; i <= ${1:-80}; i++ )); do
		echo "-\c"
	done
	echo
}

function _revision {
    typeset rev
    rev=$(awk '/Revision:/ { print $3 }' $PRGDIR/$PRGNAME | head -1)
    [ -n "$rev" ] || rev="UNKNOWN"
    echo $rev
}

function _msg {
	cat <<-eof
  SYNOPSIS
    $PRGNAME can be used to query various aspects of user, group, zone, and
    computer identity information against Active Directory using Centrify.
    One can query following: zones, computer, groups, and users.

  USAGE
    $PRGNAME -[c|g|u|z] (name|all) or [-z name -g name|-z name -u name|-z name -c name]
    $PRGNAME -e [prod|dev|qual]
    $PRGNAME -v
         c - searches computers.
         g - searches groups (UNIX group names).
         u - searches users.
         z - searches zones.
         e - optional but cannot be used stand alone.  If left out, a default production
             environment will be used for all searches. -e takes the following arguments:
               - prod (production enviornment)
               - dev  (development environment.  Currently valid user required.)
               - qual (quality/staging environment)
         v - does not take any arguments.  It provide the current revision
             number of the script.

      name - name of the object we want to search for (can be partial).
       all - if we want to search ALL object, use 'all' as a special keyword.
             Using '*' has the same effect as providing the keyward 'all'.

  EXAMPLE
    $PRGNAME -z ncsiux02-hpux-na
    $PRGNAME -z 'ncsiux*'
    $PRGNAME -z '*ncsiux*'
    $PRGNAME -z 'ncs*' -e qual
    $PRGNAME -v

    NOTE:
      If a combination of a search criteria is used, make sure to run
      this script as root for the best experience.  If you do not,
      you will be inundated with password prompts for your own id!

          $PRGNAME -z 'itsusras*' -g 'se*'
          $PRGNAME -z 'ncsusra*' -u 'jsmit*'
          $PRGNAME -z 'olympus*' -c all

    The same searching pattern goes for c, g, and u.

    Note: when using wildcards (*), you MUST use quotes to prevent shell
    from trying to expand anything that it can match in your home
    directory.
eof
}

function _parseDate {
	typeset year month day hour min sec
	year=${1:0:4}; month=${1:4:2}; day=${1:6:2}
	#hour=${1:8:2}; min=${1:10:2}; sec=${1:12:2}
	echo "${year}-${month}-${day}"
}

function _getZoneGroupGroups {
	# Setting up initial ldap string to process requested group and zone
	#typeset ldapHost="-H ldap://jnj.com:389"
	typeset searchScope="-s one -z 0 -a always -r"
	typeset -l zone="$1" key
	typeset unixGroup="$2"
	typeset attribute="name gidNumber managedBy keywords"
	typeset baseDN="CN=Groups,CN=${zone},CN=Zones,CN=Centrify,CN=Program Data,DC=${dom},DC=com"
	typeset value
	typeset rightZone=0 # is the zone managed by AD via appropriate object?
	typeset isPresent=0 # Bit for existance of unix group name in a zone
	typeset -i j=0 # Counter used to delimit our record.

	# Setup group string
	if [[ $unixGroup == all ]]; then
		unixGroup="cn=*"
	else
		unixGroup="cn=${unixGroup}"
	fi

	typeset grp="(&(${unixGroup})(displayName=\$CimsGroupVersion*))"

	# This loop acquires list of groups as seen in AD.  It does not look
	# at the groups as seen from the system itself.
	$cmd $ldapHost -b "$baseDN" $searchScope "$grp" $sortKey $attribute |\
	while IFS=: read key value; do
		typeset -A values
		typeset -l katrrib=$key

		value="${value#* }"

		case $katrrib in
			name) values[$katrrib]="$value"; isPresent=1 ;;
			keywords)
				# We skip this section in the "Global" zone
				[[ $zone == 'global '@(unix|user)* ]] && continue

				# This section has been added in those cases where a zone
				# was not created the same way (e.g., it was created earlier
				# with different settings.)
				if [[ $value == gid:+([[:digit:]]) ]]; then
					# If we acquired AD name for the UNIX group via gidNumber
					# attribute, then, we do not have to reassign it here.
					if [[ -z ${valuse[gidnumber]} ]]; then
						values[gidnumber]="${value#*:}"
						rightZone=1
					fi
				fi
			;;
			managedby) value=${value%%,*}; value=${value#???}; values[$katrrib]="${value%,}" ;;
			gidnumber) values[$katrrib]="$value" ;;

			'') j=1 ;;
		esac

		# If we are here, it is safe to process users per group listed.
		if (( j == 1 )); then
			j=0 # reset the record counter
			if [[ -n ${values[managedby]} ]]; then
				_getZoneGroupUsers "${values[gidnumber]}" "${values[managedby]}" "$zone" "$rightZone" "${values[name]}"
			else
				# We can no longer process this entry as the 'ManagedBy' attribute has been
				# dereferenced in AD.  As such, we can no longer correlate it to its full
				# AD name.
				echo "$zone:${values[gidnumber]:-x}:${grp}:x:Reference to AD group lost:Reference to AD group lost"
				return
			fi
		fi # End of record break
	done

	if (( isPresent == 0 )); then
		#printf "%25s   %9s | %-s\n" "" "" "Group ${unixGroup#cn=} does not exist in $zone zone."
		echo "$zone:x:${unixGroup}:x:Not present in a zone:Not present in a zone"
	fi
}

function _getZoneGroupUsers {
	# Local scope variables.  We want to make sure that they do not 'leak' to
	# other functions.
	typeset gidnumber="$1"
	typeset adGroupName="$2"
	typeset zone="$3"
	typeset isZoneRight="$4"
	typeset unixGroupName="$5"
	typeset ldapGroup="(&(cn=${adGroupName})(objectclass=Group))"
	typeset idmgrpbase="OU=Security,OU=IDM,OU=Groups,DC=${dom},DC=com"
	typeset searchScope="-s one -z 0 -a always -r"
	typeset attribute="name member managedObjects"
	typeset -i n=0 # record delimiter
	typeset -l key
	typeset -i idmCtrl=0 # Is it under IDM control as in created via IDM tool?
	typeset i zmatch value


	# adquery will not work because if a group is not present in the zone
	# we are running this script from, it will generate and error.  Is there
	# another way?
	if [[ $zone == $localZone ]]; then
		# If we are on the server for which we want to check the zone group
		# settings, then, it is safe to run adinfo.
		for i in $(adquery group $adGroupName -m); do
			#printf "%25s   %9s | %8s | %-s\n" "" "$(( k+=1 ))" "$i" "$(adquery user $i -p)"
			echo "$zone:$gidnumber:$unixGroupName:$adGroupName:$i:$(adquery user $i -p)"
		done
	else
		# If we are querying a different system, we must use ldapsearch.  Please, remember
		# that when we do it, we no longer are checking "real" settings of the group as
		# represented by the adinfo but rather we are reporting what AD sees instead.

		typeset -i mem=man=n=0
		set -A Mem; set -A Man

		if (( isZoneRight == 0 )); then
			$cmd $ldapHost -b "$idmgrpbase" $searchScope "$ldapGroup" $attribute |\
			while IFS=: read key value; do
				value="${value#* }"
				case $key in
					name) idmCtrl=1 ;; # If this entry is found, we know it is in correct AD location
					member)
						#echo "Processing righZone member"
						value="${value%%,OU=*}"; value="${value#CN=}"; value="${value//\/}"
						Mem[(( mem+=1 ))]="$value"
					;;
					managedobjects*)
						#echo "Processing rightZone managedObjects"
						value="${value#*CN=Groups,}"; value="${value%%,*}"
						Man[(( man+=1 ))]="${value#CN=}" # this is our zone
					;;
					'') n=1 ;;
				esac

				# We reached our end of record.  Processing it now.
				if (( n == 1 )); then
					typeset -l zmatch
					n=0 # Reset record counter right away so we do not have dups.
					if [[ $zone == 'global '@(unix|user)* ]]; then
						for i in "${Mem[@]}"; do
							echo "$zone:$gidnumber:$unixGroupName:${adGroupName:-x}:x:$i"
						done
					else
						for zmatch in "${Man[@]}"; do
							if [[ $zmatch == $zone ]]; then
								if (( ${#Mem[@]} > 0 )); then
									for l in "${Mem[@]}"; do
										echo "$zone:$gidnumber:$unixGroupName:${adGroupName:-x}:x:$l"
									done
								else
									echo "$zone:$gidnumber:$unixGroupName:${adGroupName:-x}:x:x"
								fi
								continue 2
							fi
						done
					fi
				fi
			done

			if (( idmCtrl == 0 )); then
				echo "$zone:${gidNumber:-x}:${unixGroupName:-x}:${adGroupName:-x}:Not IDMS controlled:Not IDMS controlled"
			fi
			idmCtrl=0 # Resetting DIMS control variable
			unset Mem Man
		else
			#printf "%25s   %9s | %-s\n" "" "" "This is an old zone.  Cannot verify it."
			echo "$zone:${gidnumber:-x}:${unixGroupName:-x}:${adGroupName:-x}:Old Zone:Cannot Verify"
		fi
	fi
}

function _getZoneGroup {
	typeset -l zone="$1"
	typeset -l unixGroup="$2"
	typeset baseDN="CN=Zones,CN=Centrify,CN=Program Data,DC=${dom},DC=com"
	typeset attribute
	set -A zones
	typeset -i c=j=n=k=count=0
	typeset rightZone=0

	# Setup zone string
	if [[ $zone == all ]]; then
		zone="cn=*"
	else
		zone="cn=${zone}"
	fi

	zone="(&($zone)(displayName=\$CimsZoneVersion*))"
	attribute=name

	# First collect zones
	$cmd $ldapHost -b "$baseDN" $searchScope "$zone" $sortKey $attribute |\
	while IFS=: read key value; do
		[[ $key == name ]] || continue
		zones[(( k += 1 ))]="${value#* }"
	done

	# Zones are collected
	if (( ${#zones[@]} == 0 )); then
		_note "Your zone criteria could not be matched ($zone).  Try again."
		exit
	fi

	# This is the 'meat' of this function.  We take all the zones that we are
	# supposed to interrogate and walk through them one by one dumping
	# group and user information.
	_note "Number of zones to be processed: ${#zones[@]}"
	_line 45; echo

	echo "Zone:Gid:UNIX Group:AD Group:UNIX User:AD User"

	typeset -l z
	for z in "${zones[@]}"; do
		_getZoneGroupGroups "$z" "$unixGroup"
	done
	exit
}

function _getZoneUserUsers {
	# We need to modified some of the LDAP search criteria from the global ones we were using earlier.
	typeset -l user="$1"
	typeset -l zone="$2"
	typeset attribute="uid uidNumber gidNumber managedBy unixHomeDirectory loginShell whenCreated whenChanged keywords"
	typeset sortKey="-S dn"
	typeset searchScope="-s one -z 0 -a always -r"
	typeset baseDN="CN=Zones,CN=Centrify,CN=Program Data,DC=${dom},DC=com"
	typeset -A values
	typeset -i c=j=0
	typeset key value

	# Setting up correct ldap search strings
	if [[ $user == all ]]; then
		user="(&(cn=*)(objectClass=posixAccount))"
	else
		user="(&(cn=${user})(objectClass=posixAccount))"
	fi

	baseDN="CN=Users,CN=$zone,$baseDN"
	$cmd $ldapHost -b "$baseDN" $searchScope "$user" $sortKey $attribute |\
	while IFS=: read key value; do
		typeset -l key="$key" # Normalize naming convention
		value=${value#* } # Remove preceeding blanks

		case $key in
			dn)
				echo "$value" | IFS=, read cn1 cn2 cn3 junk
				value=${cn3#???}
				[[ $value == 'Global Unix User'* ]] && value="${value% Container*}..." || value="$value"

				values[zone]="${value}"
			;; # Extract zone information
			whencreated) values[created]="$(_parseDate $value)" ;;
			whenchanged) values[changed]="$(_parseDate $value)" ;;
			keywords)
				if [[ $value == unix* ]]; then
					values[uxenable]="${value#*:}"
				else
					continue
				fi
			;; # Is account UNIX enabled?
			managedby)
				value="${value%%,OU*}"; value=${value//\/}
				values[name]="${value#???}"
			;; # Acquire full name as reported by AD
			uid) values[user]="$value" ;; # UNIX user name
			loginshell) values[shell]="$value" ;; # Logon shell
			uidnumber) values[uid]="$value" ;; # UNIX uid
			gidnumber) values[gid]="$value" ;; # UNIX gid
			unixhomedirectory) values[homedir]="$value"	;; # UNIX Home directory
			'') c=1 ;;
		esac

		if (( c == 1 )); then
			echo "${values[user]}:${values[uid]}:${values[gid]}:${values[name]}:\
${values[homedir]}:${values[shell]}:\
${values[created]}:${values[changed]}:\
${values[uxenable]}:${values[zone]}"

			c=0
		fi
	done
}

function _getZoneUser {
	typeset -l zone="$1"
	typeset -l unixUser="$2"
	typeset attribute
	set -A zones
	typeset -i c=j=n=k=count=0
	typeset rightZone=0

	# Setup zone string
	if [[ $zone == all ]]; then
		zone="cn=*"
	else
		zone="cn=${zone}"
	fi

	zone="(&($zone)(displayName=\$CimsZoneVersion*))"
	attribute=name

	# First collect zones
	$cmd $ldapHost -b "$baseDN" $searchScope "$zone" $sortKey $attribute |\
	while IFS=: read key value; do
		[[ $key == name ]] || continue
		zones[(( k += 1 ))]="${value#* }"
	done

		# Zones are collected
	if (( ${#zones[@]} == 0 )); then
		_note "Your zone criteria could not be matched ($zone).  Try again."
		exit
	fi

	# This is the 'meat' of this function.  We take all the zones that we are
	# supposed to interrogate and walk through them one by one dumping
	# group and user information.
	_note "Number of zones to be processed: ${#zones[@]}"
	_line 45; echo


	echo "User:UID:GID:Full Name:Home Dir:Shell:Created:Modified:Enabled:Zone"

	typeset -l z
	for z in "${zones[@]}"; do
		_getZoneUserUsers "$unixUser" "$z"
	done
	exit
}

function _getZoneComputer {
    typeset -l zone="$1"
    typeset -l computer="$2"
    typeset -A values
    typeset -A zones
    typeset -i eor=0 # End of record
    typeset -i counter=0
    typeset key value
    typeset attribute
	typeset sortKey="-S dn"
	typeset searchScope="-s one -z 0 -a always -r"
	typeset baseDN="CN=Zones,CN=Centrify,CN=Program Data,DC=${dom},DC=com"
    typeset filter i j

    [[ $zone == all ]] && zone="cn=*" || zone="cn=$1"
    [[ $computer == all ]] && computer="cn=*" || computer="$2"

    # In order to be able to display attributes from either zones or computer names, we
    # cannot simply write a filter for both, computer and a zone (possible) but rather
    # we need to first search for the zone specified, collect its attribute information, and
    # only then, continue with searching for a computer name.

    # Before we continue any further, does the zone a user is asking for
    # even exist?
    filter="(&($zone)(displayName=\$CimsZoneVersion*))"
    attribute="name whenCreated whenChanged"
    $cmd $ldapHost -b "$baseDN" $searchScope "$filter" $sortKey $attribute |\
    while IFS=: read key value; do
        value=${value#* }
        case $key in
            whenCreated) values[created]="$(_parseDate $value)" ;;
            whenChanged) values[changed]="$(_parseDate $value)" ;;
            name)
                typeset -l rec=$value
                [[ $rec == 'global '@(unix|users)* ]] && continue # Skip Global zones
                values[name]="$value"
            ;;
            '') eor=1 ;;
        esac

        # Create a hash array named by a zone name for further processing
        if (( eor == 1 )); then
            zones[${values[name]}]="${values[name]}:${values[created]}:${values[changed]}"
            eor=0
        fi
    done # End of LDAP zone search processing

   # Header information
   echo "Number of zones: ${#zones[@]}"
   echo "Zone:zCreateDate:zModifyDate:Computer:cCreateDate:cModifyDate:Enabled:Agent:CPU#"

    # If we are here, we can now determine if we need to search for computers
    # based on our zone find:
    if (( ${#zones[@]} == 0 )); then
        _note "Requested zone ($zone) does not exist."
        exit
    fi

    filter="(&($computer)(displayName=\$CimsComputerVersion*))"
    attribute="$attribute keywords"
    eor=0 # reset record counter

    # OK.  If we are here, let's process computers.
    for i in ${!zones[@]}; do
        echo $i | IFS=: read zn junk
        [[ -n $zn ]] || continue
        baseDN="CN=Computers,CN=$zn,CN=Zones,CN=Centrify,CN=Program Data,DC=${dom},DC=com"
        computer=0; unset computers; set -A computers
        $cmd $ldapHost -b "$baseDN" $searchScope "$filter" $sortKey $attribute |\
        while IFS=: read key value; do
            value=${value#* }
            case $key in
                dn) # Extract zone name from 'dn' attribute
                    value=${value#*Computers,CN=}; value=${value%%,*}
                    values[zone]="$value" ;;
                whenCreated) values[created]="$(_parseDate $value)" ;;
                whenChanged) values[changed]="$(_parseDate $value)" ;;
                name) values[name]="$value" ;;
                keywords)
                    case $value in
                        agent*) values[cntagent]="${value#*:}" ;;
                        cpus*) values[cpunum]="${value#*:}" ;;
                        unix*) values[enabled]="${value#*:}" ;;
                    esac
                ;;
                '') eor=1 ;;
            esac

            # Processing end of record now
            if (( eor == 1 )); then
                if [[ -n ${values[zone]} ]]; then
                    # Let's make sure we only assign non blanks to computer array
                    computers[(( counter += 1 ))]="${zones[${values[zone]}]#:}:${values[name]}:${values[created]}:${values[changed]}:${values[enabled]}:${values[cntagent]}:${values[cpunum]}"
                fi
                eor=0
            fi
        done

        # Putting it all together
        if (( ${#computers[@]} > 0 )); then
            for j in "${computers[@]}"; do
                echo "$j"
            done
        else
             echo "${zones[$i]}:x:x:x:x:x:x"
        fi
        unset computers zn junk
    done
    exit
}

function _getZone {
	typeset -l zone="$1"
	typeset attribute="name whenCreated whenChanged description"
	typeset -A values
	typeset -i c=j=0
	typeset key value

	if [[ $zone == all ]]; then
		zone="cn=*"
	else
		zone="cn=${zone}"
	fi

	zone="(&($zone)(displayName=\$CimsZoneVersion*))"

	echo "Report Generated: $(date +'%Y-%m-%d %H:%M:%S')"
	echo "Zone Name:Created:Updated:Default GID:Default Home:Default Shell:Schema"

	$cmd $ldapHost -b "$baseDN" $searchScope "$zone" $sortKey $attribute |\
	while IFS=: read key value; do

		value=${value#* }

		[[ $key == @(dn|objectClass)* ]] && continue
		[[ "$value" == [gG]'lobal '[uU]* ]] && continue
		[[ $key == whenC* ]] && values[$key]="$(_parseDate $value)"

		# Description attribute consists of multiple entries.
		if [[ $key == description ]]; then
			case "$value" in
				defaultgid*) values[gid]="${value#*:}" ;;
				defaulthom*) values[home]="${value#*:}" ;;
				defaultshe*) values[shell]="${value#*:}" ;;
				schema*) values[schema]="${value#*:}" ;;
			esac
		fi

		# When there is nothing more to process and the return value is blank,
		# then it is our end of record.  We can now construct the output.
		[[ $key == name ]] && c=1

		if (( c == 1 )); then
			echo "${value}:${values[whenCreated]}:${values[whenChanged]}:${values[gid]:-NotSet}:\
${values[home]:-NotSet}:${values[shell]:-NotSet}:${values[schema]:-NotSet}"
			c=0; (( j += 1 ))
		else
			continue
		fi
	done


	_line 45
	echo "Total Zone Count: $j\n"
}

function _getComputer {
	# We need to modified some of the LDAP search criteria from the global ones we were using earlier.
	typeset -l computer="$1"
	typeset attribute="cn whenCreated whenChanged keywords managedBy"
	typeset sortKey="-S cn"
	typeset searchScope="-s sub -z 0 -a always -r"
	typeset -A values
	typeset -i c=j=0
	typeset key value host adcontainer

	if [[ $computer == all ]]; then
		computer="cn=*"
	else
		computer="cn=${computer}"
	fi

	computer="(&($computer)(displayName=\$CimsComputerVersion*))"

	echo "Report Generated: $(date +'%Y-%m-%d %H:%M:%S')"
	echo "Host:Zone:Created:Modified:Agent:CPUs:Enabled:Company:Platform"

	$cmd $ldapHost -b "$baseDN" $searchScope "$computer" $sortKey $attribute |\
	while IFS=: read key value; do
		typeset -l key="$key" # Normalize naming convention
		value=${value#* } # Remove preceeding blanks

		case $key in
			dn)
				echo "$value" | IFS=, read cn1 cn2 cn3 junk
				value=${cn3#???}
				[[ $value == 'Global Unix User'* ]] && value="${value% Container*}..." || value="$value"
				values[zone]="$value"
			;;
			whenc*) values[$key]="$(_parseDate $value)" ;;
			keywords)
				case "$value" in
					agent*) values[centrify]="${value#* }" ;;
					cpus*) values[cpunum]="${value#*:}" ;;
					unix*) values[enabled]="${value#*:}" ;;
				esac
			;;
			managedby)
				echo "$value" | IFS=, read v1 v2 v3 junk
				values[host]="${v1#CN=}"
				values[opc]="${v2#OU=}"
				values[platform]="${v3#OU=}"
			;;
			'') c=1 ;;
		esac

		# When there is nothing more to process and the return value is blank,
		# then it is our end of record.  We can now construct the output.
		if (( c == 1 )); then
			# Some of the values we expect to acquire out of managedBy AD attribute
			# might not be set on a particular record.  As such, we will try to ensure
			# that the relevant information is present.

			[[ -z ${values[host]} ]] && values[host]="${values[zone]%%-*}"
			[[ -z ${values[opc]} ]] && values[opc]="NotSet"
			[[ -z ${values[platform]} ]] && values[platform]="NotSet"

			echo "${values[host]}:${values[zone]}:${values[whencreated]}:${values[whenchanged]}:\
${values[centrify]}:${values[cpunum]}:${values[enabled]}:${values[opc]}:${values[platform]}"

			c=0; (( j += 1 ))
		else
			continue
		fi
	done

	_line 45
	print "Total Computer Count: $j\n"
}

function _getUser {
	# We need to modified some of the LDAP search criteria from the global ones we were using earlier.
	typeset -l user="$1"
	typeset attribute="uid uidNumber gidNumber managedBy unixHomeDirectory loginShell whenCreated whenChanged keywords"
	typeset sortKey="-S dn"
	typeset searchScope="-s sub -z 0 -a always -r"
	typeset -i c=j=0
	typeset key value

	# Setting up correct ldap search strings
	if [[ $user == all ]]; then
		baseDN="CN=Global Unix User Container-Master List for Addition,CN=Zones,CN=Centrify,CN=Program Data,DC=${dom},DC=com"
		user="(&(cn=*)(objectClass=posixAccount))"
		sortKey="-S name"
		searchScope="-s sub -z 0 -a always -r"
	else
		user="(&(cn=${user})(objectClass=posixAccount))"
	fi

	echo "Report Generated: $(date +'%Y-%m-%d %H:%M:%S')"
	echo "User:UID:GID:Full Name:Home Dir:Shell:Created:Modified:Enabled:Zone"

	$cmd $ldapHost -b "$baseDN" $searchScope "$user" $sortKey $attribute |\
	while IFS=: read key value; do
        typeset -A values
		typeset -l key="$key" # Normalize naming convention
		value=${value#* } # Remove preceeding blanks

		case $key in
			dn)
				echo "$value" | IFS=, read cn1 cn2 cn3 junk
				value=${cn3#???}
				[[ $value == 'Global Unix User'* ]] && value="${value% Container*}..." || value="$value"

				values[zone]="${value}"
			;; # Extract zone information
			whencreated) values[created]="$(_parseDate $value)" ;;
			whenchanged) values[changed]="$(_parseDate $value)" ;;
			keywords)
				if [[ $value == unix* ]]; then
					values[uxenable]="${value#*:}"
				else
					continue
				fi
			;; # Is account UNIX enabled?
			managedby)
				value="${value%%,OU*}"; value=${value//\/}
				values[name]="${value#???}"
			;; # Acquire full name as reported by AD
			uid) values[user]="$value" ;; # UNIX user name
			loginshell) values[shell]="$value" ;; # Logon shell
			uidnumber) values[uid]="$value" ;; # UNIX uid
			gidnumber) values[gid]="$value" ;; # UNIX gid
			unixhomedirectory) values[homedir]="$value"	;; # UNIX Home directory
		esac

		# When there is nothing more to process and the return value is blank,
		# then it is our end of record.  We can now construct the output.
		[[ $key == '' ]] && c=1

		if (( c == 1 )); then
			echo "${values[user]}:${values[uid]}:${values[gid]}:${values[name]:-Unassigned}:\
${values[homedir]}:${values[shell]}:\
${values[created]}:${values[changed]}:\
${values[uxenable]}:${values[zone]}"

			c=0; (( j += 1 ))
		else
			continue
		fi
        unset values # blank values set in the hash
	done

	_line 45
	echo "Total User Count: $j\n"
}

function _getGroup {
	# We need to modified some of the LDAP search criteria from the global ones we were using earlier.
	typeset -l user="$1"
	typeset attribute="dn cn name managedBy gidNumber whenCreated whenChanged"
	typeset sortKey="-S dn"
	typeset searchScope="-s sub -z 0 -a always -r"
	typeset -A values
	typeset -i c=j=0
	typeset key value

	if [[ $user == all ]]; then
		baseDN="CN=Global Unix User Container-Master List for Addition,CN=Zones,CN=Centrify,CN=Program Data,DC=${dom},DC=com"
		user="(&(cn=*)(objectClass=posixGroup))"
		sortKey="-S name"
		searchScope="-s sub -z 0 -a always -r"
	else
		user="(&(cn=${user})(objectClass=posixGroup))"
	fi

	echo "Report Generated: $(date +'%Y-%m-%d %H:%M:%S')"
	echo "Group:GID:AD Name:Created:Modified:Zone"

	$cmd $ldapHost -b "$baseDN" $searchScope "$user" $sortKey $attribute |\
	while IFS=: read key value; do
		typeset -l key="$key" # Normalize naming convention
		value=${value#* } # Remove preceeding blanks

		case $key in
			dn)
				echo "$value" | IFS=, read cn1 cn2 cn3 junk
				value=${cn3#???}
				[[ $value == 'Global Unix User'* ]] && value="${value% Container*}..." || value="$value"

				values[zone]="${value}"
			;; # Extract zone information
			cn) values[name]="$value" ;; # UNIX group name
			whencreated) values[created]="$(_parseDate $value)" ;;
			whenchanged) values[changed]="$(_parseDate $value)" ;;
			managedby)
				value="${value%%,OU*}"; value=${value//\/}
				values[adname]="${value#???}"
			;; # Acquire full name as reported by AD
			gidnumber)
				values[gid]="$value"
				c=1

				if (( c == 1 )); then
					echo "${values[name]}:${values[gid]}:${values[adname]}:\
${values[created]}:${values[changed]}:${values[zone]}"

					c=0; (( j += 1 ))
				else
					continue
				fi
			;; # UNIX Home directory
		esac
	done

	_line 45
	echo "Total User Count: $j\n"
}

function _principal {
	# If a person executing our script is not a root user,
	# we can no longer use machine password for authentication.
	# As such, we will have to ask the user for his/her password
	# to authenticate to LDAP.  klist will tell us what domain
	# s/he belongs to.
	klist 2> /dev/null | awk '/^Default principal/ { print $NF }'
}

function _whoAmI {
	typeset -l answer # input collected from a user
	typeset curUser=$(whoami)
	typeset domain="jnj.com"
	typeset pick

	if [[ $curUser == root ]]; then
		cmd="$cmd -Q -m"
	else
		duser=$(_principal)
		if [ ! -n "$duser" ]; then
			# OK.  Kerberos ticket could not be obtained (number of reasons).  As such
			# we will prompt a user for his/her domain s/he belongs to.
			PS3='Your choice: '
			echo
			print -u2 "You need to pick your default Active Directory domain."
			print -u2 "Select a numeric value listed below:"
			select pick in na la eu ap quit; do
				case $pick in
					na) duser="${curUser}@${pick}.${domain}"; break ;;
					la) duser="${curUser}@${pick}.${domain}"; break ;;
					eu) duser="${curUser}@${pick}.${domain}"; break ;;
					ap) duser="${curUser}@${pick}.${domain}"; break ;;
					quit) exit ;;
				esac
			done
		fi

		# Our LDAP authentication string
		cmd="$cmd -D $duser -W -x"
	fi
}

# ------------------------------------------------------------------------------
#                                SANITY CHECKS
# ------------------------------------------------------------------------------


# Testing for correct KoRN release
_osCheck

if [ ! -d "$centdir" ]; then
	_note "[$cendir] is missing.  Cannot continue."
	exit
fi

typeset lsearch=$(whence ldapsearch)

if [ -z "$lsearch" ]; then
	_note "$PRGNAME: ldapsearch is missing."
	exit 1
fi

# If you wish to trace execution of either of the functions below, simply
# uncomment them.  To close debugging, however, you have to comment them
# out again.

#typeset -ft _getZone
#typeset -ft _getComputer
#typeset -ft _parseDate
#typeset -ft _getUser
#typeset -ft _getGroup
#typeset -ft _whoAmI
#typeset -ft _osCheck
#typeset -ft _principal
#typeset -ft _getZoneGroup
#typeset -ft _getZoneGroupGroups
#typeset -ft _getZoneGroupUsers
#typeset -ft _getZoneUser
#typeset -ft _getZoneUserUsers
#typeset -ft _getZoneComputer
#typeset -ft _revision

# ------------------------------------------------------------------------------
#                                   MAIN BODY
# ------------------------------------------------------------------------------

typeset -l localZone=$(_adZone)
typeset -i c=g=u=z=0
typeset -i count=0

# The following two lines below set the stage for the selection of the
# environment we will be operating doing our searches.
typeset -x dom=jnj
typeset -x ldapSrv="jnj.com"

if [ $# -gt 0 ]; then
	while getopts ":c:z:u:g:e:v" opt; do
		case $opt in
			c) c=1; ldHost="$OPTARG" ;;
			z) z=1; ldZone="$OPTARG" ;;
			u) u=1; ldUser="$OPTARG" ;;
			g) g=1; ldGroup="$OPTARG" ;;
			e)
				typeset -l arg=$OPTARG
				case $arg in
					prod) ldapSrv="jnj.com"; dom=jnj ;;
					dev)
						# Be advised that using 'root' might not work
						# in dev enviornment and you must do it with your
						# valid dfdev account!!!
						ldapSrv="dfdevdns1.jnj.com"; dom="dfdev,DC=jnj" ;;
					qual) ldapSrv="sjnj.com"; dom=sjnj ;;
					*)
						echo "  Following environments are available:"
						echo "     - prod (Production)"
						echo "     - dev (Development)"
						echo "     - qual (Quality/Staging)\n"
						echo "  Environment provided ($OPTARG) is invalid."
						exit
					;;
				esac
			;;
			v) echo "Script revision: $(_revision)\n"; exit ;;
			:) _note "$PRGNAME ($LINENO): -${OPTARG} paramter requires a value.\n"; exit 2 ;;
			*) _note "$PRGNAME ($LINENO): unknown option (-${OPTARG}).\n"; exit 2 ;;
		esac
	done
	shift $(( OPTIND - 1 ))

	if	(( c + u > 1 )) ||
		(( c + g > 1 )); then
		cat <<eof

   You can only use one option at a time.  For example:
       $PRGNAME -z 'itsusra*'
       $PRGNAME -c '*blp0*'
       $PRGNAME -u 'jsmith*'
       $PRGNAME -g se

    or following two combinations (note: become root for best experience):
       $PRGNAME -z 'itsusras*' -u 'jsmith*'
       $PRGNAME -z 'jjc*' -g setemp
       $PRGNAME -z itsusrasidv3 -c all

eof
        exit
	fi
else
	_msg
	exit
fi


# -----------------------------------------------------------------------------
#                      Setting up ldapsearch command
# -----------------------------------------------------------------------------
typeset cmd="ldapsearch -LLL"
_whoAmI # This will set proper LDAP command string

typeset ldapHost="-H ldap://${ldapSrv}:389"
typeset baseDN="CN=Zones,CN=Centrify,CN=Program Data,DC=${dom},DC=com"
typeset searchScope="-s one -z 0 -r"
typeset sortKey="-S name"

(( z + g == 2 )) && _getZoneGroup "$ldZone" "$ldGroup"
(( z + u == 2 )) && _getZoneUser "$ldZone" "$ldUser"
(( z + c == 2 )) && _getZoneComputer "$ldZone" "$ldHost"
(( z == 1 )) && _getZone "$ldZone"
(( c == 1 )) && _getComputer "$ldHost"
(( u == 1 )) && _getUser "$ldUser"
(( g == 1 )) && _getGroup "$ldGroup"

# ----------------------------------------------------------------------------
# $Log: zoneInfo.sh,v $
# Revision 1.5  2011/04/01 19:47:49  bmynars
# Synced with IDMS version release.
#
# Revision 1.14  2011/04/01 19:00:38  bmynars
# Version 4 release.  New functionality has been added:
#   - one can choose now what enviornment to conduct searches in.
#     It can be done in prod, qual, or dev.
#
# Revision 1.13  2011/04/01 18:13:25  bmynars
# Added ability to switch enviornments: prod, qual, and dev.
#
# Revision 1.12  2011/03/28 18:10:23  bmynars
#
# Revision 1.11  2011/03/25 18:14:19  bmynars
# Updated user message and _getZoneComputer function
#
# Revision 1.10  2011/03/25 15:38:17  bmynars
# Added _getZoneComputer function to provid targeted querying
# capabilities.
#
# Revision 1.9  2011/03/21 12:02:48  bmynars
# Working version
#
# Revision 1.8  2011/03/18 15:15:15  bmynars
# Added new functionality to query groups in zones.
#
# Revision 1.7  2011/03/17 11:57:59  bmynars
# Work in progress.  Checking in to preserver incremental changes.
#
# Revision 1.6  2011/03/14 15:37:54  bmynars
# Fixed typo
#
# Revision 1.5  2011/03/14 15:32:47  bmynars
# Updated info message related to wildcards.
#
# Revision 1.4  2011/03/14 14:59:29  bmynars
# Updating authentication mechanism so a regular user
# could execute the script.
#
# Revision 1.3  2011/03/11 19:53:56  bmynars
# Fully working copy.
#
# Revision 1.2  2011/03/11 16:48:49  bmynars
# Added user and group functionality.
#
# Revision 1.1  2011/03/11 00:07:07  bmynars
# Zone info is ready.  More to come.
#
# $RCSfile: zoneInfo.sh,v $
# $Source: /ncs/cvsroot/ncsbin/utils/zoneInfo.sh,v $
# $State: Exp $
# ----------------------------------------------------------------------------
