#!/usr/bin/ksh
# Author: Sahul Hameed <shameed@its.jnj.com>
# $Revision: 1.21 $
# $Date: 2012/12/03 14:54:24 $
# $Header: /ncs/cvsroot/ncsbin/utils/alrm.sh,v 1.21 2012/12/03 14:54:24 gdhaese1 Exp $ 
# $Id: alrm.sh,v 1.21 2012/12/03 14:54:24 gdhaese1 Exp $
# $Locker:  $
# History: Check the bottom of the file for revision history
# ----------------------------------------------------------------------------
#
#
#Script alrm.sh
#The Version # below is for alarmdef. Do not delete.
ALARMDEFVER=3.5
#
# Syntax :
#       alrm.sh
#
# The script is to deploy a standard alarmdef to a set of HP or Sun
# servers using OVO and restart mwa so that the new alarmdef will go
# into effect.
#
# HISTORY
# 04/22/05 SH   Created.
#               Version1.0
#
# 08/19/05 SH   Changed alert levels from red to major to avoid critical
#               PICASSO tickets.
#               Remove the "%" (percent) on network collisions alert.
#               Network collisions alert will be generated only if the
#               condition exists for 4 minutes or more.
#               version 1.1
#
# 11/07/05      Uses /opt/perf/bin/mwa to start and stop mwa.
# 11/07/05 SH   modified CPU alert login to consider the QUEUE, in
#               addition to UTILIZATION.
#               Version 1.2
#
# 03/07/05 SH   Removed the repeat CPU usage alerts.
#               Version 1.3
# 03/21/06 SH   Change the alerts to MINOR for initial condition and
#               MAJOR if a severe condition exists.
#               In sun systems CPU RUN QUEUE comparison is adjusted
#               to be based on QUE/CPU.
#               Version 1.4
#
# 05/03/06 SH	Major revamp of the script to carryforward thresholds.
#		Also, the default thresholds are adjusted to reduce 
#		non actionable alerts. Added mail based alert for low
#		number of network collisions.
#               Version 2.0
# 10/30/07 SH	Incorporated runaway process detection, mail alert
#		and local script execution. Also major revamp of the script
#		was done, in the section to carryforward thresholds.
#		Version 3.0
# 11/20/07 SH	Adjusted the runaway process detection logic to reduce
#		or eliminate false alerts.
#		Version 3.1
# 11/21/07 SH	Added the runaway process logic i Perfalert.sh script
#		itself.
#		Version 3.2
#
# 11/26/07 SH	Added the cleanup function in PerfAlert.sh script and 
#		adjusted alarmdef to call this, instead of dedicated
#		Cleanup script.
#
# 06/29/09 PME	Moved part of the runaway process detection to cronjob:
#		/opt/ncsbin/utils/AlertRunawayProcesses.sh.  This to:
#		- further reduce false alerts
#		- control alerting through an exclude-list:
#		  /var/opt/perf/runaways.exc
#		- improve cleanup of runawayprocs.track
#
# 01/29/10 PME See bottom of the file for changes (Revision 1.16)
#

OS=`uname -s`
OS_Ver=`uname -r`
ALARMDEF=/var/opt/perf/alarmdef
NEW_ALARMDEF=${ALARMDEF}.new
ALARMDEF_TMP1=${ALARMDEF}.tmp1
OLD_RUNAWAYFILE=/var/opt/perf/runawayprocs
RUNAWAYFILE=/var/opt/perf/runawayprocs.track
TMP_CRON=/var/tmp/cron_AlertRunAwayProcesses.tmp
TMP_CRON2=/var/tmp/cron2_AlertRunAwayProcesses.tmp
EXCLUDE_LIST=/var/opt/perf/runaways.exc
EXCLUDE_LIST_TMP1=/var/tmp/runaways.exc.tmp1
EXCLUDE_LIST_TMP2=/var/tmp/runaways.exc.tmp2
EXAMPLE_EXCLUDE_LIST=/var/opt/perf/runaways.exc.example
HOSTNAME=`uname -n`
if [ $OS = "HP-UX" ]
then
 PATH=/usr/bin:/usr/sbin:/opt/perf/bin:
else
 PATH=/usr/xpg4/bin:/usr/bin:/usr/sbin:/opt/perf/bin:
fi
EMAIL="root RA-NCSUS-UNIXAltDep@ncsus.jnj.com"
SCRIPT=$0
#
NOW=`date +%m%d%y_%H%M`
WARNING="No Errors"
LOG_DIR=/var/adm/install-logs/
LOG=$LOG_DIR/CC-alarmdef-deployment-${NOW}.log
ALARMDEF_SAVE=$ALARMDEF.$NOW
#
# Standard Variables and thier default threshold
#
VAR[1]=CPU_UTIL:99
VAR[2]=CPU_RUN_QUEUE:4.0
VAR[3]=MEM_PROB:90
VAR[4]=MEM_PROB_SEV:130
VAR[5]=PROC_CPU_UTIL:90
VAR[6]=MAX_PROC_IGNORE_ID:100
VAR[7]=PROC_IO:0
VAR[8]=SWAP_UTIL:70
VAR[9]=SWAP_UTIL_SEV:90
VAR[10]=DISK_PROB:90
VAR[11]=NET_COLL:100
VAR[12]=NET_COLL_SEV:1000
VAR[13]=FILE_TBL:70
VAR[14]=FILE_TBL_SEV:90
VAR[15]=FILE_LOCKS:70
VAR[16]=FILE_LOCKS_SEV:90
VAR[17]=PROC_TBL:70
VAR[18]=PROC_TBL_SEV:90
VAR[19]=SHM_TBL:70
VAR[20]=SHM_TBL_SEV:90
VAR[21]=SEM_TBL:70
VAR[22]=SEM_TBL_SEV:90
VAR[23]=MSG_TBL:70
VAR[24]=MSG_TBL_SEV:90

say ()
{
 if [ $RET_CODE -eq 0 ]
 then
  date >> $LOG
  echo "INFO: The operation to $OPERATION was successful" >> $LOG
  echo "\n\n" >> $LOG
 else
  date >> $LOG
  echo "ERROR: The operation to $OPERATION was not successful" >> $LOG
  if [ "$EXIT" = "exit" ]
  then
   echo "Exiting due to error..." >> $LOG
   echo "\n\n" >> $LOG
   cat $LOG|mailx -s "${HOSTNAME}-Alarmdef deployment failed" $EMAIL
   echo "${HOSTNAME}-Exiting due to error..."
   $EXIT $RET_CODE
  else
   WARNING="Error encountered in one or more steps."
   echo "\n\n" >> $LOG
  fi
 fi
}

add_header()
{
 echo "# @(#)alarmdef   Standard Alarmdef version $ALARMDEFVER - Time $NOW\n#" > $NEW_ALARMDEF
 RET_CODE=$?
 OPERATION="create new alarmdef file"
 EXIT=exit
 say
 echo "# MeasureWare Agent alarm configurations\n#" >> $NEW_ALARMDEF
 echo "# The variables hold the thrshhold values." >> $NEW_ALARMDEF
 echo "# Adjust threshold depending upon the server requrements." >> $NEW_ALARMDEF
 echo "#\n#\n#" >> $NEW_ALARMDEF
 echo "# The following are the definitions for the variables." >> $NEW_ALARMDEF
 echo "#\n#" >> $NEW_ALARMDEF
 echo "# CPU_UTIL	:MAX CPU UTILIZATION in %. Recomended-99\n#" >> $NEW_ALARMDEF
 echo "# CPU_RUN_QUEUE	:MAX RUN QUEUE PER CPU. Recomended-4.0\n#" >> $NEW_ALARMDEF
 echo "# MEM_PROB	:MAX MEMORY BOTTLENECK PROBABILITY. Recomended-90\n#" >> $NEW_ALARMDEF
 echo "# MEM_PROB_SEV	:MAX SEVERE MEMORY BOTTLENECK PROBABILITY. Recomended-90\n#" >> $NEW_ALARMDEF
 echo "# PROC_CPU_UTIL	:ANY PROCESS UTILIZING GREATER THAN THIS, WILL BE TESTED FOR  RUNAWAY. RECOMENDED 90.\n#" >> $NEW_ALARMDEF
 echo "# MAX_PROC_IGNORE_ID	:ANY PROCESS WITH PID GREATER THAN THIS, WILL BE TESTED FOR  RUNAWAY. RECOMENDED 100.\n#" >> $NEW_ALARMDEF
 echo "# PROC_IO	:ANY PROCESS WITH IO THAN THIS, WILL BE TESTED FOR  RUNAWAY. RECOMENDED 0.\n#" >> $NEW_ALARMDEF
 echo "# SWAP_UTIL	:MAX SWAP UTILIZATION in %. Recomended-70\n#" >> $NEW_ALARMDEF
 echo "# SWAP_UTIL_SEV	:MAX SWAP UTILIZATION in % (SEVERE). Recomended-90\n#" >> $NEW_ALARMDEF
 echo "# DISK_PROB	:MAX IO BOTTLENECK PROBABILITY.\n#" >> $NEW_ALARMDEF
 echo "# NET_COLL	:MAX NET COLLISIONS PER MIN. Recomended-100\n#" >> $NEW_ALARMDEF
 echo "# NET_COLL_SEV	:MAX NET COLLISIONS PER MIN (SEVERE) Recomended-1000.\n#" >> $NEW_ALARMDEF
 echo "# FILE_TBL	:MAX FILE TABLE UTILIZATION in %. Recomended-70\n#" >> $NEW_ALARMDEF
 echo "# FILE_TBL_SEV	:MAX FILE TABLE UTILIZATION in % (SEVERE). Recomended-90\n#" >> $NEW_ALARMDEF
 echo "# FILE_LOCKS	:MAX FILE LOCKS UTILIZATION in %. Recomended-70\n#" >> $NEW_ALARMDEF
 echo "# FILE_LOCKS_SEV	:MAX FILE LOCKS UTILIZATION in % (SEVERE). Recomended-90\n#" >> $NEW_ALARMDEF
 echo "# PROC_TBL	:MAX PROC TABLE UTILIZATION in %. Recomended-70\n#" >> $NEW_ALARMDEF
 echo "# PROC_TBL_SEV	:MAX PROC TABLE UTILIZATION in % (SEVERE). Recomended-90\n#" >> $NEW_ALARMDEF
 echo "# SHM_TBL	:MAX SHARED MEMORY UTILIZATION in %. Recomended-70\n#" >> $NEW_ALARMDEF
 echo "# SHM_TBL_SEV	:MAX SHARED MEM UTILIZATION in % (SEVERE). Recomended-90\n#" >> $NEW_ALARMDEF
 echo "# SEM_TBL	:MAX SEMAPHORE UTILIZATION in %. Recomended-70\n#" >> $NEW_ALARMDEF
 echo "# SEM_TBL_SEV	:MAX SEMAPHORE UTILIZATION in % (SEVERE). Recomended-90\n#" >> $NEW_ALARMDEF
 echo "# SEM_TBL	:MAX MESSAGE STRUCTURES UTILIZATION in %. Recomended-70\n#" >> $NEW_ALARMDEF
 echo "# SEM_TBL_SEV	:MAX MESSAGE STRUCTURES UTILIZATION in % (SEVERE). Recomended-90\n#" >> $NEW_ALARMDEF
 echo "#\n#\n#" >> $NEW_ALARMDEF
}
#
#
set_variables()
{
echo "# See above for explanation for the variables." >> $NEW_ALARMDEF
echo "# Including recomended values, which are also default.\n#" >> $NEW_ALARMDEF
I=1
while [ $I -le ${#VAR[*]} ]
do
 echo ${VAR[$I]}| awk -F : '{print $1, $2}'| read VARIABLE DEFAULT
 if [ -f $ALARMDEF_SAVE ]
 then
  grep "^VAR  *$VARIABLE" $ALARMDEF_SAVE | awk '{print $4}' |read VALUE
 else
  VALUE=""
 fi
 if [ -n "$VALUE" ]
 then
  echo "VAR $VARIABLE = $VALUE" >> $NEW_ALARMDEF
 else
  echo "VAR $VARIABLE = $DEFAULT" >> $NEW_ALARMDEF
 fi
 grep -q "^VAR $VARIABLE =" $NEW_ALARMDEF
 RET_CODE=$?
 if [ $RET_CODE -ne 0 ]
 then
  OPERATION="set varibale $VARIABLE"
  EXIT=exit
  say
 fi
 ((I=$I+1))
done
}
create_exclude_file()
{
cat - <<EndOfExcludeFile
# specify processes that should not be alerted by the runaway-process-monitor
#
# Format:
# command-name [username]
# Notes on the syntax:
# 1) command-name should match the field PROC_PROC_NAME.
#    PROC_PROC_NAME is the first 16 characters of the comm field from 'ps'
#    e.g. use this command to report the comm field: 'UNIX95= ps -o comm'
# 2) command-name and username will be used for pattern-matching
# 3) be cautious to use special characters in the directives in this file.
#    Wrong syntax can cause the matching process to fail.
#    You can check the syntax with the following statement:
#        (change PROCESSNAME and USERNAME with values you want to test)
#    awk -v name=PROCESSNAME -v user=USERNAME \\
#          'name ~ \$1 && (\$2 == "" || user ~ \$2) {printf "MATCH "} {print}' \\
#          /var/opt/perf/runaways.exc
#
# Some examples:
#
#    'vi' will match any process having vi in his name; So it will match
#    processes called 'vi' as well as processes called 'virus_check'
#
#    '^vi$ ^root$' will only match the vi process if it's owned by root.
#
#    '.* pmertens' will match any process owned by pmertens
#
^gzip$ ^root$
^dw.sap
EndOfExcludeFile
}
#
echo "Alarmdef job started at $NOW - logfile: $LOG"
echo "Alarmdef job started at $NOW" > $LOG
echo "This will save the current alarmdef and" >> $LOG
echo "replace it with a standard alamdef and restart MWA." >> $LOG
echo "This will also carry forward custom threshold settings." >> $LOG
echo "\n\n\n" >> $LOG
#
#step 0 Exit if glance is not installled properly.
#
echo "\n\nStep 0 : Ensure Openview perfagent (glancePlus) is installed properly.\n" >> $LOG
OPERATION="verify proper installation of Openview perfagent (glancePlus)"
EXIT=exit
if [ $OS = "HP-UX" ]
then
  if [ "$OS_VER" = "B.11.31" ]
    then 
     HPUX_Ver=$(swlist HPUX11i-VSE-OE | grep Virtual | awk '{print $3}')
     if [ "$HPUX_Ver" = "B.11.31.1103" ]
      then
       echo "# swverify -x mount_all_filesystems=false TC097AA" >> $LOG
       swverify -x mount_all_filesystems=false TC097AA >> $LOG 2>&1
      else
       echo "# swverify -x mount_all_filesystems=false B3701AA" >> $LOG
       swverify -x mount_all_filesystems=false B3701AA >> $LOG 2>&1
     fi
  fi  
else
 echo "# pkginfo HPglance" >> $LOG
 pkginfo HPglance >> $LOG 2>&1
fi
if [ $? -ne 0 ]
then
 #RET_CODE=29
 RET_CODE=0
else
 RET_CODE=0
fi
say
#
#step 1 Save a copy of current alarmdef
#
echo "\n\nStep 1 : Save a copy of current alarmdef\n" >> $LOG
if [ -f $ALARMDEF ]
then
 cp -p $ALARMDEF $ALARMDEF_SAVE
 RET_CODE=$?
 OPERATION="save current alarmdef"
 EXIT=exit
 say
 else
 echo "Currently no $ALARMDEF file is found. Proceeding..." >> $LOG
 echo "\n\n" >> $LOG
fi
#
#Step 2 Add standard header information to the new alarmdef file.
#
echo "\n\nStep 2 : Add Header to new ALARMDEF\n" >> $LOG
add_header
#
#
#Step 3
#Set alarmdef variables file by setting the threshold either
#from defaults, defined in this script or by carrying forward from
#current alarmdef in the system. The current values in the system
#are used,if they defined defined.
#
echo "\n\nStep 3 : Set variables in new ALARMDEF\n" >> $LOG
set_variables
#
#
#
#Step 4
#Extract the logic part of alarmdef from the end of this script and 
#save it in a temp file.
#
echo "\n\nStep 4 : Extract logic portion alarmdef and save it to tmp file, $ALARMDEF_TMP1.\n" >> $LOG
sed -n '/^###BEGIN-HP-ALARMDEF###$/,/^###END-SUN-ALARMDEF###$/p' \
$SCRIPT > $ALARMDEF_TMP1 2>> $LOG
RET_CODE=$?
OPERATION="extract logic portion of alarmdef "
EXIT=exit
say
#
#
#Step 5
# Configure alarmgen to send alerts to OVO and
#         execute local scripts (if any) always.
#
echo "\n\nStep 5 : Configure alarmgen to send alert to OVO and execure local scripts alsways.\n" >> $LOG
agsysdb -ito on >> $LOG 2>&1
RET_CODE=$?
OPERATION="Configure alarmgen to sent alerts to OVO"
EXIT="echo Return code $RET_CODE"
say
#
agsysdb -actions always >> $LOG 2>&1
RET_CODE=$?
OPERATION="Configure alarmgen to always execute local scripts (if any)"
EXIT="echo Return code $RET_CODE"
say
#
#Step 6
# Replace alarmdef with the new file.
#
echo "\n\nStep 6 : Add alarmdef logic to new ALARMDEF and make it current.\n" >> $LOG
 if [ $OS = "HP-UX" ]
 then
  echo "Adding logic portion to new alarmdef \n\n" >> $LOG
  sed -n '/^###BEGIN-HP-ALARMDEF###$/,/^###END-HP-ALARMDEF###$/p' \
  $ALARMDEF_TMP1|grep -vE '^###BEGIN-HP-ALARMDEF###$|^###END-HP-ALARMDEF###$' \
  >> $NEW_ALARMDEF 2>> $LOG
  RET_CODE=$?
  echo "\n" >> $LOG
  OPERATION="append logic to new alarmdef"
  EXIT=exit
  say
  echo "Replacing alarmdef \n\n" >> $LOG
  mv $NEW_ALARMDEF $ALARMDEF
  RET_CODE=$?
  echo "\n" >> $LOG
  OPERATION="replace alarmdef"
  EXIT=exit
  say
  rm -f $ALARMDEF_TMP1
 elif [ $OS = "SunOS" ]
 then
  echo "Adding logic portion to new alarmdef \n\n" >> $LOG
  sed -n '/^###BEGIN-SUN-ALARMDEF###$/,/^###END-SUN-ALARMDEF###$/p' \
  $ALARMDEF_TMP1|/usr/xpg4/bin/grep -vE \
  '^###BEGIN-SUN-ALARMDEF###$|^###END-SUN-ALARMDEF###$' \
  >> $NEW_ALARMDEF 2>> $LOG
  RET_CODE=$?
  echo "\n" >> $LOG
  OPERATION="append logic to new alarmdef"
  EXIT=exit
  say
  echo "Replacing alarmdef \n\n" >> $LOG
  mv $NEW_ALARMDEF $ALARMDEF
  RET_CODE=$?
  echo "\n" >> $LOG
  OPERATION="replace alarmdef"
  EXIT=exit
  say
  rm -f $ALARMDEF_TMP1
 else
  echo "OS $OS unsupported" >> $LOG
  RET_CODE=1
  OPERATION="replace alarmdef"
  EXIT=exit
  say
 fi 
#
 chmod 644 $ALARMDEF
 chown root:bin $ALARMDEF
#
#Step 7
#Create blank file for local alarm definitions.
echo " Step 7: Creatng blank local alarmdef file /var/opt/ITS/alarmdef.local..."  >> $LOG 2>&1
if [ -d /var/opt/ITS ]
then
 touch -a /var/opt/ITS/alarmdef.local
 RET_CODE=$?
else
 mkdir -m 755 /var/opt/ITS
 touch /var/opt/ITS/alarmdef.local
 RET_CODE=$?
fi
echo "\n" >> $LOG
OPERATION="create/touch /var/opt/ITS/alarmdef.local"
EXIT="echo create/touch /var/opt/ITS/alarmdef.local"
say
#
# Restart mwa
# Step 8 - Restart MWA.
#
echo " Step 8: Restarting mwa..."  >> $LOG 2>&1
/opt/perf/bin/mwa restart >> $LOG 2>&1
RET_CODE=$?
echo "\n" >> $LOG
OPERATION="restarting MWA"
EXIT="echo restart mwa"
say
#
# Step 9 - Remove temporary file /var/opt/perf/runawayprocs and /var/opt/perf/runawayprocs.track
#          /var/opt/perf/runawprocs is obsolete from version 3.4 of alarmdef (in future versions
#          we can skip this file (step 9a.))
echo " Step 9a: Remove temporary file $OLD_RUNAWAYFILE...."  >> $LOG 2>&1
if [ -f $OLD_RUNAWAYFILE ]
then
 echo "Removing temporary file $OLD_RUNAWAYFILE...."  >> $LOG 
 rm -f $OLD_RUNAWAYFILE
 RET_CODE=$?
 OPERATION="remove old runaway file"; EXIT="echo $OPERATION"; say
else
 echo "No temporary file $OLD_RUNAWAYFILE present...."  >> $LOG 
fi
#
echo " Step 9b: Remove temporary file $RUNAWAYFILE...."  >> $LOG 2>&1
if [ -f $RUNAWAYFILE ]
then
 echo "Removing temporary file $RUNAWAYFILE...."  >> $LOG 
 rm -f $RUNAWAYFILE
 RET_CODE=$?
 OPERATION="remove old runaway file"; EXIT="echo $OPERATION"; say
else
 echo "No temporary file $RUNAWAYFILE present...."  >> $LOG 
fi
#
#
# Step 10 - Create default EXCLUDE-LIST for runaway processes
# as of Revision 1.17 the example exclude list will become obsolete
# so step 10.a can be removed in future revisions
#
echo " Step 10.a - Remove example EXCLUDE-LIST for runaway processes..." >> $LOG 2>&1
if [ -f $EXAMPLE_EXCLUDE_LIST ]
then
 echo "Removing example exclude list $EXAMPLE_EXCLUDE_LIST...."  >> $LOG 
 rm -f $EXAMPLE_EXCLUDE_LIST
 RET_CODE=$?
 OPERATION="remove example exclude list"; EXIT="echo $OPERATION"; say
fi

echo " Step 10.b - Save relevant entries from current EXCLUDE-LIST..." >> $LOG 2>&1
grep -Ev '^#|gzip root|\^gzip\$ \^root\$|\^dw.sap$|/var/opt/perf/runaways.exc.example' $EXCLUDE_LIST > $EXCLUDE_LIST_TMP1

echo " Step 10.c - Create default EXCLUDE-LIST and add any saved customizations..." >> $LOG 2>&1
echo "Creating default exclude list $EXCLUDE_LIST_TMP2...."  >> $LOG 
create_exclude_file > $EXCLUDE_LIST_TMP2
RET_CODE=$?
if [ $RET_CODE -ne 0 ]
then echo "ERROR: problem creating $EXCLUDE_LIST_TMP2. rc=$RET_CODE" >> $LOG
     echo "       please verify contents of this file." >> $LOG
     echo "       Older customisations can be found in $EXCLUDE_LIST_TMP1" >> $LOG
     OPERATION="Create exclude list (1)"; EXIT="echo $OPERATION"; say
else
     if [ -s $EXCLUDE_LIST_TMP1 ]
     then cat $EXCLUDE_LIST_TMP2 $EXCLUDE_LIST_TMP1 > $EXCLUDE_LIST
          RET_CODE=$?
          if [ $RET_CODE -ne 0 ]
          then echo "ERROR: problem customizing $EXCLUDE_LIST. rc=$RET_CODE" >> $LOG
               echo "       please verify contents of this file." >> $LOG
               echo "       Default list to be found in $EXCLUDE_LIST_TMP2" >> $LOG
               echo "       Older customisations can be found in $EXCLUDE_LIST_TMP1" >> $LOG
               OPERATION="Creating exclude list (2)"; EXIT="echo $OPERATION"; say
          else rm -f $EXCLUDE_LIST_TMP2 $EXCLUDE_LIST_TMP1
          fi
     else mv $EXCLUDE_LIST_TMP2 $EXCLUDE_LIST
          RET_CODE=$?
          if [ $RET_CODE -ne 0 ]
          then echo "ERROR: problem moving $EXCLUDE_LIST_TMP2 to $EXCLUDE_LIST. rc=$RET_CODE" >> $LOG
               echo "       please verify contents of this file." >> $LOG
               OPERATION="Creating exclude list (3)"; EXIT="echo $OPERATION"; say
          fi
          rm -f $EXCLUDE_LIST_TMP1
     fi
fi
#
#
# Step 11 - Create crontab entry
#
echo " Step 11: Create crontab entry..." >> $LOG 2>&1
crontab -l > $TMP_CRON
RET_CODE=$?
if [ $RET_CODE -ne 0 ]
then echo "ERROR: problem saving current crontab in $TMP_CRON. rc=$RET_CODE" >> $LOG
     echo "crontab entry won't be updated. Please check" >> $LOG
     OPERATION="Reading crontab (1)"; EXIT="echo $OPERATION"; say
else
     crontab_entry=$(awk 'BEGIN {result="empty";}
         /^#alarm-upgrade# .*\/opt\/ncsbin\/utils\/AlertRunawayProcesses.sh/ {result="disabled";}
         /^[0-9].*\/opt\/ncsbin\/utils\/AlertRunawayProcesses.sh/ {result="active";}
         END {print result}' $TMP_CRON)

     case "$crontab_entry" in
     active) echo "crontab entry is already present." >> $LOG ;;
     empty) echo "Creating crontab entry." >> $LOG
            echo "#MONITOR RUNAWAY PROCESSES" >> $TMP_CRON
            echo "2,22,42 * * * * /opt/ncsbin/utils/AlertRunawayProcesses.sh 3600  > /var/adm/log/AlertRunawayProcesses.log 2>&1"\
		 >> $TMP_CRON
            crontab $TMP_CRON ||
		 {
		 echo "ERROR: problem while adding new crontab entry from $TMP_CRON. Please check." >> $LOG
		 OPERATION="Updating crontab (2)"; EXIT="echo $OPERATION"; say
		 }
            ;;
     disabled) awk '{if ($1 == "#alarm-upgrade#" && $7 == "/opt/ncsbin/utils/AlertRunawayProcesses.sh")
                                     print substr ($0,17);
                                     else print;}' $TMP_CRON > $TMP_CRON2
               RET_CODE=$?
               if [ $RET_CODE -ne 0 ]
               then echo "ERROR: problem updating current crontab from $TMP_CRON to $TMP_CRON2. rc=$RET_CODE" >> $LOG
                    echo "crontab entry won't be updated. Please check" >> $LOG
		    OPERATION="Updating crontab (3)"; EXIT="echo $OPERATION"; say
               else
                    crontab $TMP_CRON2 || 
			{
			echo "ERROR: problem updating current crontab with $TMP_CRON2. Please check." >> $LOG
			OPERATION="updating crontab (4)"; EXIT="echo $OPERATION"; say
			}
               fi
               ;;
     *) echo "ERROR: problem with reading crontab entry from $TMP_CRON." >> $LOG
        echo "       crontab entry won't be updated. Please check" >> $LOG
	OPERATION="Reading crontab (5)"; EXIT="echo $OPERATION"; say
	;;
     esac
fi
rm -f $TMP_CRON $TMP_CRON2
#
#
# Step 12 - Email Result.
#
 echo " Step 12: Email Result...."  >> $LOG 2>&1
 echo "Alarmdef successfully replaced." >> $LOG
 echo "\n" >> $LOG
 echo "perfstat output....." >> $LOG 2>&1
 perfstat >> $LOG
 echo "\n\n" >> $LOG
 echo "It will take a few minutes for alarmgen to start. Please verify." \
 >> $LOG
 echo "Another report with perfstat output will be generated in 30 mins." \
 >> $LOG
 echo "The second report should indicate all processes are up. If not please \
 check your system." >> $LOG
 echo "\n" >> $LOG
 echo "The details of the batch job....." >> $LOG
 echo "\n" >> $LOG
 #
 #Schedule a batch job to run in 30 minutes to
 # report the status of measureware agent.
 #
 echo "perfstat 2>&1| mailx -s \"$HOSTNAME - Perfstat, 30 minutes after\
 alarmdef deployment.\" $EMAIL"| at now + 30 minutes >> $LOG 2>&1
 #
 echo "\n\n" >> $LOG
 echo "Content of the new alarmdef......" >> $LOG
 echo >> $LOG
 cat $ALARMDEF >> $LOG 
 cat $LOG|mailx -s "${HOSTNAME}-Alarmdef deployment successful with ${WARNING}" $EMAIL
 echo "${HOSTNAME}-Successful with ${WARNING}..."
 exit
#
#
#
#
#
#
###BEGIN-HP-ALARMDEF###
#
###################################################
# FOR CPU UTIL
#
###################################################
#
ALARM GBL_CPU_TOTAL_UTIL >= CPU_UTIL FOR 5 minutes
      GBL_RUN_QUEUE >= CPU_RUN_QUEUE FOR 5 minutes
 type = "CPU"
START
   {
    MINOR alert "CPU Bottleneck Alert-Run Queue= ", GBL_RUN_QUEUE, " for 5 minutes or more."
    exec "/usr/bin/ksh /opt/ncsbin/utils/PerfAlert.sh CPU MINOR ",  GBL_CPU_TOTAL_UTIL, " " , GBL_RUN_QUEUE
   }
END reset alert "End of CPU Bottleneck Alert"
#
ALARM GBL_CPU_TOTAL_UTIL >= CPU_UTIL FOR 15 minutes
      GBL_RUN_QUEUE >= CPU_RUN_QUEUE FOR 15 minutes
 type = "CPU"
START
   {
    MAJOR alert "CPU Bottleneck Alert-Run Queue= ", GBL_RUN_QUEUE, " for 15 minutes or more."
    exec "/usr/bin/ksh /opt/ncsbin/utils/PerfAlert.sh CPU MAJOR ",  GBL_CPU_TOTAL_UTIL, " " , GBL_RUN_QUEUE
   }
END reset alert "End of CPU Bottleneck Alert"
#
ALARM GBL_CPU_TOTAL_UTIL >= CPU_UTIL FOR 20 minutes
 type = "CPU"
START
   if GBL_RUN_QUEUE < CPU_RUN_QUEUE then
   {
    MINOR alert "HIGH CPU Usage- ", GBL_CPU_TOTAL_UTIL, "%"
    exec "/usr/bin/ksh /opt/ncsbin/utils/PerfAlert.sh CPU MINOR ",  GBL_CPU_TOTAL_UTIL, " " , GBL_RUN_QUEUE
   }
END reset alert "End of CPU Bottleneck Alert"
#
#
###################################################
# FOR MEMORY UTIL
#
###################################################
symptom Memory_Bottleneck type=MEMORY
rule GBL_MEM_UTIL              >   99  prob 50
rule GBL_MEM_QUEUE             >    2  prob 20
rule GBL_MEM_PAGEOUT_RATE      >   50  prob 20
rule GBL_DISK_VM_WRITE_RATE    >   50  prob 20
rule GBL_MEM_SWAPOUT_RATE      >    1  prob 20
rule GBL_MEM_SWAPOUT_RATE      >    4  prob 50
#
alarm Memory_Bottleneck > MEM_PROB for 10 minutes
type = "Memory"
start
 if Memory_Bottleneck < MEM_PROB_SEV then
   {
    MINOR alert "Memory Bottleneck Probability= ", Memory_Bottleneck, "%"
    exec "/usr/bin/ksh /opt/ncsbin/utils/PerfAlert.sh MEMORY MINOR ",  Memory_Bottleneck
   }
end
reset alert "End of Memory Bottleneck Alert"
#
alarm Memory_Bottleneck > MEM_PROB_SEV for 10 minutes
type = "Memory"
start
   {
    MAJOR alert " Severe Memory Bottleneck Probability= ", Memory_Bottleneck, "%"
    exec "/usr/bin/ksh /opt/ncsbin/utils/PerfAlert.sh MEMORY MAJOR ",  Memory_Bottleneck
   }
end
reset alert "End of Memory Bottleneck Alert"
#
#
###################################################
#Detect runaway processes.
#
###################################################
#
PROCESS LOOP
{
  IO_SUM = PROC_IO_BYTE + PROC_DISK_LOGL_READ + PROC_DISK_LOGL_WRITE + PROC_DISK_PHYS_IO
  if (PROC_CPU_TOTAL_UTIL > PROC_CPU_UTIL ) and
     (PROC_CPU_TOTAL_TIME_CUM > 300 ) and
     (PROC_PROC_ID > MAX_PROC_IGNORE_ID ) and
     (IO_SUM <= PROC_IO ) then
  {
    exec "/usr/bin/echo ", PROC_PROC_ID, " ", PROC_PROC_NAME, " ", PROC_USER_NAME, " ", DATE, " ", TIME, " ", PROC_CPU_TOTAL_UTIL, " ", PROC_IO_BYTE_CUM, " ", PROC_DISK_LOGL_IO_CUM, " >> /var/opt/perf/runawayprocs.track"
  }
}

#
#
#
###################################################
# FOR SWAP UTIL
#
###################################################
#
alarm GBL_SWAP_SPACE_UTIL > SWAP_UTIL FOR 20 MINUTES
type = "Swap"
start
 if GBL_SWAP_SPACE_UTIL < SWAP_UTIL_SEV then
  {
   MINOR alert "SWAP Utilization Limit has reached", GBL_SWAP_SPACE_UTIL , "%"
   exec "/usr/bin/ksh /opt/ncsbin/utils/PerfAlert.sh SWAP MINOR ",  GBL_SWAP_SPACE_UTIL
  }
end
reset alert "End of Swap Utilization Alert"
#
alarm GBL_SWAP_SPACE_UTIL > SWAP_UTIL_SEV FOR 10 MINUTES
type = "Swap"
start
 {
  MAJOR alert "Severe SWAP space shortage ", GBL_SWAP_SPACE_UTIL , "%"
  exec "/usr/bin/ksh /opt/ncsbin/utils/PerfAlert.sh SWAP MINOR ",  GBL_SWAP_SPACE_UTIL
 }
end
reset alert "End of Swap Utilization Alert"
#
###################################################
# FOR DISK UTIL (OPTIONAL-COMMENTED OUT BY DEFAULT)
#
###################################################
#symptom Disk_Bottleneck type=DISK
#rule GBL_DISK_UTIL_PEAK       > 50   prob GBL_DISK_UTIL_PEAK
#rule GBL_DISK_SUBSYSTEM_QUEUE >  3   prob 25
#
#alarm Disk_Bottleneck > DISK_PROB for 10 minutes
#type = "Disk"
#start
#{
# MINOR alert "Disk Bottleneck Probability= ", Disk_Bottleneck, "%"
# exec "/usr/bin/ksh /opt/ncsbin/utils/PerfAlert.sh DISK MINOR ",  Disk_Bottleneck
#}
#end
#reset alert "End of Disk Bottleneck Alert"
#
#
###################################################
# FOR GOOD NETWORK
#
###################################################
#
alarm GBL_NET_COLLISION_1_MIN_RATE > NET_COLL FOR 10 MINUTES
type = "NetIF"
start
 {
  MINOR alert "Network Collision Rate High (per Minute)", GBL_NET_COLLISION_1_MIN_RATE
  exec "/usr/bin/ksh /opt/ncsbin/utils/PerfAlert.sh NETWORK MINOR ",  GBL_NET_COLLISION_1_MIN_RATE
 }
end
reset alert "End of Network Collisions Alert"
#
alarm GBL_NET_COLLISION_1_MIN_RATE > NET_COLL_SEV FOR 20 MINUTES
start
 {
  MAJOR alert "Network Collision Rate High (per Minute)", GBL_NET_COLLISION_1_MIN_RATE
  exec "/usr/bin/ksh /opt/ncsbin/utils/PerfAlert.sh NETWORK MAJOR ",  GBL_NET_COLLISION_1_MIN_RATE
 }
end
reset alert "End of Network Collisions Alert"
#
#
###################################################
##  File Table Alerts
##
###################################################
#
alarm tbl_file_table_util > FILE_TBL FOR 4 MINUTES
type = "FILE_TBL"
start
 if tbl_file_table_util < FILE_TBL_SEV then
 {
  MINOR alert "File Table Full" ,tbl_file_table_util , "%"
  exec "/usr/bin/ksh /opt/ncsbin/utils/PerfAlert.sh FILE_TABLE MINOR ",  tbl_file_table_util
 }
end
reset alert "End of File Table Full Alert"
#
alarm tbl_file_table_util > FILE_TBL_SEV FOR 4 MINUTES
type = "FILE_TBL"
start
 {
  MAJOR alert "File Table Full" ,tbl_file_table_util , "%"
  exec "/usr/bin/ksh /opt/ncsbin/utils/PerfAlert.sh FILE_TABLE MAJOR ",  tbl_file_table_util
 }
end
reset alert "End of File Table Full Alert"
#
###################################################
# FOR FILE LOCKS
#
###################################################
alarm tbl_file_lock_util > FILE_LOCKS FOR 4 MINUTES
type = "FILE_LCK"
start
 if tbl_file_lock_util < FILE_LOCKS_SEV then
  {
   MINOR alert "File Lock Limit has reached" , tbl_file_lock_util , "%"
   exec "/usr/bin/ksh /opt/ncsbin/utils/PerfAlert.sh FILE_LOCK MAJOR ",  tbl_file_lock_util
  }
end
reset alert "End of File Lock Alert"
#
alarm tbl_file_lock_util > FILE_LOCKS_SEV FOR 4 MINUTES
type = "FILE_LCK"
start
 {
  MAJOR alert "File Lock Limit has reached" , tbl_file_lock_util , "%"
  exec "/usr/bin/ksh /opt/ncsbin/utils/PerfAlert.sh FILE_LOCK MAJOR ",  tbl_file_lock_util
 }
end
reset alert "End of File Lock Alert"
#
###################################################
# FOR PROCESS TABLE
#
###################################################
alarm tbl_proc_table_util > PROC_TBL FOR 4 MINUTES
type = "PROC_TBL"
start
 if tbl_proc_table_util < PROC_TBL_SEV then
  {
   MINOR alert "Process Table Limit has reached" , tbl_proc_table_util, "%"
   exec "/usr/bin/ksh /opt/ncsbin/utils/PerfAlert.sh PROC_TABLE MINOR ",  tbl_proc_table_util
  }
end
reset alert "End of Process Table Alert"
#
alarm tbl_proc_table_util > PROC_TBL_SEV FOR 4 MINUTES
type = "PROC_TBL"
start
 {
  MAJOR alert "Process Table Limit has reached" , tbl_proc_table_util, "%"
  exec "/usr/bin/ksh /opt/ncsbin/utils/PerfAlert.sh PROC_TABLE MAJOR ",  tbl_proc_table_util
 }
end
reset alert "End of Process Table Alert"
#
###################################################
# FOR SHMEM TABLE
#
###################################################
alarm tbl_shmem_table_util > SHM_TBL FOR 4 MINUTES
type = "SHM_TBL"
start
 if tbl_shmem_table_util < SHM_TBL_SEV then
  {
   MINOR alert "Shared Memory Table Full" , tbl_shmem_table_util,  "%"
   exec "/usr/bin/ksh /opt/ncsbin/utils/PerfAlert.sh SHMEM_TABLE MINOR ",  tbl_shmem_table_util
  }
end
reset alert "End of Shared Memory Table Alert"
#
alarm tbl_shmem_table_util > SHM_TBL_SEV FOR 4 MINUTES
type = "SHM_TBL"
start
 {
  MAJOR alert "Shared Memory Table Full" , tbl_shmem_table_util,  "%"
  exec "/usr/bin/ksh /opt/ncsbin/utils/PerfAlert.sh SHMEM_TABLE MAJOR ",  tbl_shmem_table_util
 }
end
reset alert "End of Shared Memory Table Alert"
#
###################################################
# FOR SEM TABLE
#
###################################################
alarm tbl_sem_table_util > SEM_TBL FOR 4 MINUTES
type = "SEM_TBL"
start
 if tbl_sem_table_util < SEM_TBL_SEV then
  {
   MINOR alert "Semaphore Table Limit has reached" , tbl_sem_table_util,  "%"
   exec "/usr/bin/ksh /opt/ncsbin/utils/PerfAlert.sh SEM_TABLE MINOR ",  tbl_sem_table_util
  }
end
reset alert "End of Semaphore Table Alert"
#
alarm tbl_sem_table_util > SEM_TBL_SEV FOR 4 MINUTES
type = "SEM_TBL"
start
 {
  MAJOR alert "Semaphore Table Limit has reached" , tbl_sem_table_util,  "%"
  exec "/usr/bin/ksh /opt/ncsbin/utils/PerfAlert.sh SEM_TABLE MAJOR ",  tbl_sem_table_util
 }
end
reset alert "End of Semaphore Table Alert"
#
###################################################
#
# FOR MSG TABLE
#
###################################################
alarm tbl_msg_table_util > MSG_TBL FOR 4 MINUTES
type = "MSG_TBL"
start
 if tbl_msg_table_util < MSG_TBL_SEV then
 {
  MINOR alert "Message Table Full", tbl_msg_table_util , "%"
  exec "/usr/bin/ksh /opt/ncsbin/utils/PerfAlert.sh MSG_TABLE MINOR ",  tbl_msg_table_util
 }
end
reset alert "End of Message Table Alert"
#
alarm tbl_msg_table_util > MSG_TBL_SEV FOR 4 MINUTES
type = "MSG_TBL"
start
 {
  MAJOR alert "Message Table Full", tbl_msg_table_util , "%"
  exec "/usr/bin/ksh /opt/ncsbin/utils/PerfAlert.sh MSG_TABLE MAJOR ",  tbl_msg_table_util
 }
end
reset alert "End of Message Table Alert"
#
#
#Include locally defined alarm definitions.
#
INCLUDE "/var/opt/ITS/alarmdef.local"
#
#
###END-HP-ALARMDEF###
################################
################################
###BEGIN-SUN-ALARMDEF###
#
###################################################
# FOR CPU UTIL
#
###################################################
#
PER_CPU_RUN_Q = GBL_RUN_QUEUE / GBL_ACTIVE_CPU
#
ALARM GBL_CPU_TOTAL_UTIL >= CPU_UTIL FOR 5 minutes
      PER_CPU_RUN_Q >= CPU_RUN_QUEUE FOR 5 minutes
 type = "CPU"
START
   {
    MINOR alert "CPU Bottleneck Alert-Run Queue= ", PER_CPU_RUN_Q, " for 5 minutes or more."
    exec "/usr/bin/ksh /opt/ncsbin/utils/PerfAlert.sh CPU MINOR ",  GBL_CPU_TOTAL_UTIL, " " , PER_CPU_RUN_Q
   }
END reset alert "End of CPU Bottleneck Alert"
#
ALARM GBL_CPU_TOTAL_UTIL >= CPU_UTIL FOR 15 minutes
      PER_CPU_RUN_Q >= CPU_RUN_QUEUE FOR 15 minutes
 type = "CPU"
START
   {
    MAJOR alert "CPU Bottleneck Alert-Run Queue= ", PER_CPU_RUN_Q, " for 15 minutes or more."
    exec "/usr/bin/ksh /opt/ncsbin/utils/PerfAlert.sh CPU MAJOR ",  GBL_CPU_TOTAL_UTIL, " " , PER_CPU_RUN_Q
   }
END reset alert "End of CPU Bottleneck Alert"
#
ALARM GBL_CPU_TOTAL_UTIL >= CPU_UTIL FOR 20 minutes
 type = "CPU"
START
   if PER_CPU_RUN_Q < CPU_RUN_QUEUE then
   {
    MINOR alert "HIGH CPU Usage- ", GBL_CPU_TOTAL_UTIL, "%"
    exec "/usr/bin/ksh /opt/ncsbin/utils/PerfAlert.sh CPU MINOR ",  GBL_CPU_TOTAL_UTIL, " " , PER_CPU_RUN_Q
   }
END reset alert "End of CPU Bottleneck Alert"
#
#
###################################################
# FOR MEMORY UTIL
#
###################################################
symptom Memory_Bottleneck type=MEMORY
rule GBL_MEM_UTIL              >   98  prob 40
rule GBL_MEM_PG_SCAN_RATE      >10000  prob 20
rule GBL_MEM_PAGEOUT_BYTE_RATE >   20  prob 15
rule GBL_MEM_PAGEOUT_BYTE_RATE >  200  prob 20
rule GBL_MEM_SWAPOUT_BYTE_RATE >    0  prob 40
#
alarm Memory_Bottleneck > MEM_PROB for 10 minutes
type = "Memory"
start
 if Memory_Bottleneck < MEM_PROB_SEV then
   {
    MINOR alert "Memory Bottleneck Probability= ", Memory_Bottleneck, "%"
    exec "/usr/bin/ksh /opt/ncsbin/utils/PerfAlert.sh MEMORY MINOR ",  Memory_Bottleneck
   }
end
reset alert "End of Memory Bottleneck Alert"
#
alarm Memory_Bottleneck > MEM_PROB_SEV for 10 minutes
type = "Memory"
start
   {
    MAJOR alert " Severe Memory Bottleneck Probability= ", Memory_Bottleneck, "%"
    exec "/usr/bin/ksh /opt/ncsbin/utils/PerfAlert.sh MEMORY MAJOR ",  Memory_Bottleneck
   }
end
reset alert "End of Memory Bottleneck Alert"
#
#
###################################################
#Detect runaway processes.
#
###################################################
#
PROCESS LOOP
{
  IO_SUM = PROC_IO_BYTE + PROC_DISK_BLOCK_IO 
  if (PROC_CPU_TOTAL_UTIL > PROC_CPU_UTIL ) and
     (PROC_CPU_TOTAL_TIME_CUM > 300 ) and
     (PROC_PROC_ID > MAX_PROC_IGNORE_ID ) and
     (IO_SUM <= PROC_IO ) then
  {
    exec "/usr/bin/echo ", PROC_PROC_ID, " ", PROC_PROC_NAME, " ", PROC_USER_NAME, " ", DATE, " ", TIME, " ", PROC_CPU_TOTAL_UTIL, " ", PROC_IO_BYTE_CUM, " ", PROC_DISK_LOGL_IO_CUM, " >> /var/opt/perf/runawayprocs.track"
  }
}
#
#
#
###################################################
# FOR SWAP UTIL
#
###################################################
#
alarm GBL_SWAP_SPACE_UTIL > SWAP_UTIL FOR 20 MINUTES
type = "Swap"
start
 if GBL_SWAP_SPACE_UTIL < SWAP_UTIL_SEV then
  {
   MINOR alert "SWAP Utilization Limit has reached", GBL_SWAP_SPACE_UTIL , "%"
   exec "/usr/bin/ksh /opt/ncsbin/utils/PerfAlert.sh SWAP MINOR ",  GBL_SWAP_SPACE_UTIL
  }
end
reset alert "End of Swap Utilization Alert"
#
alarm GBL_SWAP_SPACE_UTIL > SWAP_UTIL_SEV FOR 10 MINUTES
type = "Swap"
start
 {
  MAJOR alert "Severe SWAP space shortage ", GBL_SWAP_SPACE_UTIL , "%"
  exec "/usr/bin/ksh /opt/ncsbin/utils/PerfAlert.sh SWAP MINOR ",  GBL_SWAP_SPACE_UTIL
 }
end
reset alert "End of Swap Utilization Alert"
#
###################################################
# FOR DISK UTIL (OPTIONAL-COMMENTED OUT BY DEFAULT)
#
###################################################
#symptom Disk_Bottleneck type=DISK
#rule GBL_DISK_UTIL_PEAK       > 50   prob GBL_DISK_UTIL_PEAK
#rule GBL_DISK_SUBSYSTEM_QUEUE >  3   prob 25
#
#alarm Disk_Bottleneck > DISK_PROB for 10 minutes
#type = "Disk"
#start
#{
# MINOR alert "Disk Bottleneck Probability= ", Disk_Bottleneck, "%"
# exec "/usr/bin/ksh /opt/ncsbin/utils/PerfAlert.sh DISK MINOR ",  Disk_Bottleneck
#}
#end
#reset alert "End of Disk Bottleneck Alert"
#
#
###################################################
# FOR GOOD NETWORK
#
###################################################
#
alarm GBL_NET_COLLISION_1_MIN_RATE > NET_COLL FOR 10 MINUTES
type = "NetIF"
start
 {
  MINOR alert "Network Collision Rate High (per Minute)", GBL_NET_COLLISION_1_MIN_RATE
  exec "/usr/bin/ksh /opt/ncsbin/utils/PerfAlert.sh NETWORK MINOR ",  GBL_NET_COLLISION_1_MIN_RATE
 }
end
reset alert "End of Network Collisions Alert"
#
alarm GBL_NET_COLLISION_1_MIN_RATE > NET_COLL_SEV FOR 20 MINUTES
start
 {
  MAJOR alert "Network Collision Rate High (per Minute)", GBL_NET_COLLISION_1_MIN_RATE
  exec "/usr/bin/ksh /opt/ncsbin/utils/PerfAlert.sh NETWORK MAJOR ",  GBL_NET_COLLISION_1_MIN_RATE
 }
end
reset alert "End of Network Collisions Alert"
#
#
#
###################################################
# FOR PROCESS TABLE
#
###################################################
alarm tbl_proc_table_util > PROC_TBL FOR 4 MINUTES
type = "PROC_TBL"
start
 if tbl_proc_table_util < PROC_TBL_SEV then
  {
   MINOR alert "Process Table Limit has reached" , tbl_proc_table_util, "%"
   exec "/usr/bin/ksh /opt/ncsbin/utils/PerfAlert.sh PROC_TABLE MINOR ",  tbl_proc_table_util
  }
end
reset alert "End of Process Table Alert"
#
alarm tbl_proc_table_util > PROC_TBL_SEV FOR 4 MINUTES
type = "PROC_TBL"
start
 {
  MAJOR alert "Process Table Limit has reached" , tbl_proc_table_util, "%"
  exec "/usr/bin/ksh /opt/ncsbin/utils/PerfAlert.sh PROC_TABLE MAJOR ",  tbl_proc_table_util
 }
end
reset alert "End of Process Table Alert"
#
###################################################
# FOR SHMEM TABLE
#
###################################################
alarm tbl_shmem_table_util > SHM_TBL FOR 4 MINUTES
type = "SHM_TBL"
start
 if tbl_shmem_table_util < SHM_TBL_SEV then
  {
   MINOR alert "Shared Memory Table Full" , tbl_shmem_table_util,  "%"
   exec "/usr/bin/ksh /opt/ncsbin/utils/PerfAlert.sh SHMEM_TABLE MINOR ",  tbl_shmem_table_util
  }
end
reset alert "End of Shared Memory Table Alert"
#
alarm tbl_shmem_table_util > SHM_TBL_SEV FOR 4 MINUTES
type = "SHM_TBL"
start
 {
  MAJOR alert "Shared Memory Table Full" , tbl_shmem_table_util,  "%"
  exec "/usr/bin/ksh /opt/ncsbin/utils/PerfAlert.sh SHMEM_TABLE MAJOR ",  tbl_shmem_table_util
 }
end
reset alert "End of Shared Memory Table Alert"
#
###################################################
# FOR SEM TABLE
#
###################################################
alarm tbl_sem_table_util > SEM_TBL FOR 4 MINUTES
type = "SEM_TBL"
start
 if tbl_sem_table_util < SEM_TBL_SEV then
  {
   MINOR alert "Semaphore Table Limit has reached" , tbl_sem_table_util,  "%"
   exec "/usr/bin/ksh /opt/ncsbin/utils/PerfAlert.sh SEM_TABLE MINOR ",  tbl_sem_table_util
  }
end
reset alert "End of Semaphore Table Alert"
#
alarm tbl_sem_table_util > SEM_TBL_SEV FOR 4 MINUTES
type = "SEM_TBL"
start
 {
  MAJOR alert "Semaphore Table Limit has reached" , tbl_sem_table_util,  "%"
  exec "/usr/bin/ksh /opt/ncsbin/utils/PerfAlert.sh SEM_TABLE MAJOR ",  tbl_sem_table_util
 }
end
reset alert "End of Semaphore Table Alert"
#
###################################################
#
# FOR MSG TABLE
#
###################################################
alarm tbl_msg_table_util > MSG_TBL FOR 4 MINUTES
type = "MSG_TBL"
start
 if tbl_msg_table_util < MSG_TBL_SEV then
 {
  MINOR alert "Message Table Full", tbl_msg_table_util , "%"
  exec "/usr/bin/ksh /opt/ncsbin/utils/PerfAlert.sh MSG_TABLE MINOR ",  tbl_msg_table_util
 }
end
reset alert "End of Message Table Alert"
#
alarm tbl_msg_table_util > MSG_TBL_SEV FOR 4 MINUTES
type = "MSG_TBL"
start
 {
  MAJOR alert "Message Table Full", tbl_msg_table_util , "%"
  exec "/usr/bin/ksh /opt/ncsbin/utils/PerfAlert.sh MSG_TABLE MAJOR ",  tbl_msg_table_util
 }
end
reset alert "End of Message Table Alert"
#
#Include locally defined alarm definitions.
#
INCLUDE "/var/opt/ITS/alarmdef.local"
#
#
###END-SUN-ALARMDEF###
# ----------------------------------------------------------------------------
# $Log: alrm.sh,v $
# Revision 1.21  2012/12/03 14:54:24  gdhaese1
# force the return code to 0 after a swverify Glance
#
# Revision 1.20  2011/08/05 19:43:53  caucone
# Update script to check the new version of glance called HP Operations agent TC097AA
#
# Revision 1.19  2010/02/08 22:05:10  pmertens
# inserted step 0 again with swverify on glance - but added the option:
#    mount_all_filesystems=false
#
# Revision 1.18  2010/01/29 13:17:47  pmertens
# Remove temporary files used for crontab-enablement
#
# Revision 1.17  2010/01/29 12:17:51  pmertens
# - Removed the swverify check on glance (step 0) because it's giving issues
#   at deployment time
# - Removed the check on the opctemplate (step 9) since the old template has been
#   replaced by various others templates.
# - Changed the crontab-entry creation.  With this release the crontab entry for
#   AlertRunawayProcesses.sh will be disabled by a pre-install-step in
#   smspkgs/SMS_JNJ_HPUX-NCS_UTILSinstall.sh.
# - Removed the example-exclude-list.  With this release only the active exclude
#   list will be kept and any existing customisations will be saved.
# - Added one entry to the exclude-list ('^dw.sap'), that will
#   suppress all alerts from certain sap processes.
#
# Revision 1.16  2009/10/02 12:26:43  pmertens
# added reference to example file in runaways.exc if it already exists.
#
# Revision 1.15  2009/08/15 07:26:09  pmertens
# added cleanup for runawayprocs.track file
#
# Revision 1.14  2009/08/05 11:13:46  pmertens
# removed pmetens EMAIL-address (so root and RA-NCSUS-UNIXAltDep@ncsus.jnj.com are active again)
#
# Revision 1.13  2009/07/31 11:31:39  pmertens
# corrected variable substitution in example exclude file
#
# Revision 1.12  2009/07/30 15:06:41  pmertens
# 1) Update alarmdef logic for runaway-process-detection: replace IO_SUM with cumulative IO metrics;
# 2) Step 6: Added cleanup of ALARMDEF_TMP1 + call of 'say' function in HP-branch.
# 3) Updated the default exclude file creation. Added an example file with more comments.
#
# Revision 1.11  2009/06/29 21:32:36  pmertens
# added step to create crontab-entry.
#
# Revision 1.10  2009/06/29 20:00:35  pmertens
# updated alarmdef definition for runaway-processes + added 2 steps to create runaways.exc and cleanup runawayprocs
#
# Revision 1.9  2008/03/27 13:08:00  shameed
# Modified step 0 to redirect the output of test command to log file,
# instead of just relying on the return code.
#
# Revision 1.8  2008/03/26 21:28:50  shameed
# Added check to make sure OV perfagent (glanceplus) is installed properly.
#
# Revision 1.7  2007/11/29 14:44:12  shameed
# The cleanup fuction is added in PerfAlert.sh and alarmdef is adjusted to
# call PerfAlert.sh, to cleanup, once every 6 hours.
#
# Revision 1.6  2007/11/21 17:01:52  shameed
# The runaway process detection logic is added in PerfAlert.sh script.
#
# Revision 1.5  2007/11/20 21:27:47  shameed
# Alarmdef is modified to alert on runaway process more effectively,
# by avoiding false alert. This is accomplished by
# 1. Considering process logic IO instead of Phyiscal IO in detection logic
# 2. Considering differential in cumulative IO, rather than momentory IO
# 3. increasing the time the process has to run, before being considered for
#    runaway
#
# Revision 1.4  2007/11/01 15:10:33  shameed
# Fix VER variable.
#
# Revision 1.3  2007/11/01 14:00:48  shameed
# Cleanup header & footer
#
# Revision 1.2  2007/10/31 23:44:17  bmynars
# Added Header and Footer only.  KoRN reports error on line 457
#
#
# $RCSfile: alrm.sh,v $
# $Source: /ncs/cvsroot/ncsbin/utils/alrm.sh,v $
# $State: Exp $
# ----------------------------------------------------------------------------

