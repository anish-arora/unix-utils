#!/usr/dt/bin/dtksh
# Author: Bolek Mynarski <bmynars@ncsus.jnj.com>
#
# $Revision: 1.5 $
# $Date: 2007/01/04 15:38:15 $
# $Header: /ncs/cvsroot/ncsbin/utils/fibercard.sh,v 1.5 2007/01/04 15:38:15 bmynars Stab $
# $Id: fibercard.sh,v 1.5 2007/01/04 15:38:15 bmynars Stab $
# $Locker:  $
# History: Check the bottom of the file for revision history
# ----------------------------------------------------------------------------

typeset -x PRGNAME=${0##*/}
typeset -x PRGDIR=${0%/*}

[[ $PRGDIR == . || $PRGDIR != /* ]] && PRGDIR=$(pwd)

# Purpose of this script is to give an easily parsable fiber channel
# attribute output.  Attributes listed in rec[] array will be the ones
# listed.  Depending on how you want to list them, you can add new ones
# to the bottom of the array.  If you want to keep order the same as it
# appears on displaying fiber channel attributes using fcmsutil, then
# add them in the right order remembering to provide correct array index.

# This script will be used both, by Altiris and interactively.  Because
# Altiris is very strict how it can process raw data for database import,
# we cannot produce any headers.  However, when running this script manually,
# we want to ensure that we know what we are looking for.  -i (for header/info) can
# be used to do just that (do not confuse it with help).

function _line {
	typeset -i i=0
	typeset j=$1 # pass the length of the line

	for (( i = 0; i <= (( ${j:-2} - 2)); i++ )); do
		print "=\c"
	done
	print
}

typeset fcm=/opt/fcms/bin/fcmsutil
typeset fcrecord
typeset -i header=0

rec[1]="Chip"
rec[2]="Topology"
rec[3]="Link Speed"
rec[4]="N_Port_id"
rec[5]="N_Port Node"
rec[6]="N_Port Port"
rec[7]="Driver state"
rec[8]="Hardware Path"

case "$1" in
	-i) header=1 ;;
	*)
		if [ -n "$1" ]; then
			cat <<-eof
  Try: $PRGNAME -i
       This will print headers and legend of info displayed.
	eof
		fi
	;;
esac

# ------------------------------------------------------------------------------
#                                   MAIN BODY
# ------------------------------------------------------------------------------

# typeset -ft _line _header

if [ $header -eq 1 ]; then
	resize
	_line $COLUMNS
	printf "%7s | %5s | %5s | %5s | %5s | %5s | %5s | %5s | %5s\n" "Col 0" \
	"Col 1" "Col 2" "Col 3" "Col 4" "Col 5" "Col 6" "Col 7" "Col 8"
	print " ** Legend below"
	_line $COLUMNS
fi


# Rather than going for /dev directory, we will always scan for what we currunetly have
# available on the system by running 'ioscan' command.

for i in $(ioscan -funC fc | grep '/dev/'); do
	[ -n "$i" ] || continue

	typeset -A fcprop
	fcrecord="$i"

	# Once we have found a fiber channel card, then, we will stuff its elements
	# into fcprop associative array.  $key var is our attribute name and
	# $value is our content of that attribute.

	$fcm $i |\
	while IFS='=' read key value; do
	
		[[ $key == '' ]] && continue
		fcprop["$key"]="${value# *}"
		
	done # End of 'while' loop collecting card attrib info

	# Checking if our property exists on the card  Our most outter array is
	# indexed rec array (setup up top).  We will walk through each element
	# of rec and then, in the inner loop we will match its content against
	# fcprop associative array.  If nothing matches (for example, card speed),
	# then, we will assign 'NONE' keyword to it.

	for (( j = 1; j <= ${#rec[@]}; j++ )); do
		for k in "${!fcprop[@]}"; do
			if [[ $k == *"${rec[$j]}"* ]]; then
					fcrecord="$fcrecord ${fcprop[$k]}"; continue 2
			else
				 continue
			fi
		done # End of fcprop associative array

		fcrecord="$fcrecord NONE"
	done # End of rec indexed array setup in the beginning of the script

	# Finally, we will send the output to STDOUT.  If one needs to have it
	# recorded into a file, simply redirect an output as in any other program.

	print "$fcrecord"
	fcrecord=""
	unset fcprop

done # End of big 'for' loop walking through current fiber channel cards

# If run manually and -h is passed, display the legend
if [ $header -eq 1 ]; then
	_line 25
	printf "%5s: %-s\n" "Col 0" "FCcrd"
	for (( i = 1; i <= ${#rec[@]}; i++ )); do
		printf "%5s: %-s\n" "Col $i" "${rec[$i]}"
	done
fi

# ----------------------------------------------------------------------------
# $Log: fibercard.sh,v $
# Revision 1.5  2007/01/04 15:38:15  bmynars
#  - Put $i in quotes when checking whether or not it holds any value
#  - Added extra space before and after condition statement in the while
#    loop stuffing fcprop associated array.
#
# Revision 1.4  2007/01/04 15:33:27  bmynars
# Removed extra space between FC device and release number as per request to
# accomodate SQL load.
#
# Revision 1.3  2006/12/31 21:30:11  bmynars
# Second version of the script.  In the second take, we added a swich
# that can be used to add useful header and legend information if
# the script is run interactively.
#
# Revision 1.2  2006/12/23 14:09:07  bmynars
# Simplified 'grep' to include larger number of card types
#
# Revision 1.1  2006/12/23 13:40:58  bmynars
# Initial commit.  Fiber channel attribute collector.
#
#
# $RCSfile: fibercard.sh,v $
# $Source: /ncs/cvsroot/ncsbin/utils/fibercard.sh,v $
# $State: Stab $
# ----------------------------------------------------------------------------

