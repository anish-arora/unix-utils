#!/usr/bin/ksh
# Author: Bolek Mynarski <bmynars@ncsus.jnj.com>
#
# $Revision: 1.1 $
# $Date: 2006/09/02 00:57:14 $
# $Header: /ncs/cvsroot/ncsbin/utils/oralinks.sh,v 1.1 2006/09/02 00:57:14 bmynars Stab $ 
# $Id: oralinks.sh,v 1.1 2006/09/02 00:57:14 bmynars Stab $
# $Locker:  $
# History: Check the bottom of the file for revision history
# ----------------------------------------------------------------------------

typeset -x PRGNAME=${0##*/}
typeset -x PRGDIR=${0%/*}

[[ $PRGDIR = . || $PRGDIR != /* ]] && PRGDIR=$(pwd)

function _note {
	echo " ** $*"
}

# ------------------------------------------------------------------------------
#                                   MAIN BODY
# ------------------------------------------------------------------------------

if [ $(id -u) -ne 0 ]; then
	_note "$PRGNAME ($LINENO): you have to be root to run this script!"
	exit 1
fi

# The purpose of this script is to fix missing Oracle links in HP-UX
# distribution.

typeset libdir=/usr/lib
libs[0]=libX11.3
libs[1]=libXIE.2
libs[2]=libXext.3
libs[3]=libXhp11.3
libs[4]=libXi.3
libs[5]=libXm.4
libs[6]=libXp.2
libs[7]=libXt.3
libs[8]=libXtst.2

cd $libdir || { echo Failed; exit 1; }

for i in ${libs[@]}; do
	lk=${i%?}sl

	if [ ! -h $lk ]; then
		ln -s $i $lk 
		ls -l $lk 
	else
		_note "$PRGNAME ($LINENO): $lk already exists"	
	fi
done

# ----------------------------------------------------------------------------
# $Log: oralinks.sh,v $
# Revision 1.1  2006/09/02 00:57:14  bmynars
# oralinks.sh script can be used to fixed library links required by
# Oracle installation routines which are missing in every HP-UX
# installation.
#
# $RCSfile: oralinks.sh,v $
# $Source: /ncs/cvsroot/ncsbin/utils/oralinks.sh,v $
# $State: Stab $
# ----------------------------------------------------------------------------
