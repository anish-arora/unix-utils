function bbdf {
if [[ `uname -s` = "HP-UX" ]] ; then
        DFCMD="/usr/bin/bdf"
else
  DFCMD="/bin/df -k"
fi
FS=$1
$DFCMD $FS | awk '{if (split($0, f) == 1) {
                   getline
                   split($0, rest)
                   for (i = 1; i <= NF; i++) f[i+1] = rest[i]
                                          }
printf ("%-50s %10s %10s %10s %5s %s\n", f[1], f[2], f[3], f[4], f[5],f[6]) }'
}
>/tmp/fsgreater80
bbdf |grep -v Filesystem|awk '{print $6}'|while read i
do
usage=`bbdf $i|grep -v Filesystem|awk '{print $5}' |cut -f1 -d"%"`
if [ ${usage} -ge 80 ]
then
echo "`bbdf $i|grep -v Filesystem`\t::FSMON_LEVEL::\t`cat /var/opt/OV/conf/osspi/osspi_fsmon.cfg|grep -w $i|head -1|awk '{print $2}'`"  >>/tmp/fsgreater80
else
continue
fi
done
cat /tmp/fsgreater80
