#!/usr/dt/bin/dtksh
# Author: Bolek Mynarski <bmynars@ncsus.jnj.com>
#
# $Revision: 1.2 $
# $Date: 2006/06/19 00:32:09 $
# $Header: /ncs/cvsroot/ncsbin/utils/make_tape_recovery.sh,v 1.2 2006/06/19 00:32:09 bmynars Stab $ 
# $Id: make_tape_recovery.sh,v 1.2 2006/06/19 00:32:09 bmynars Stab $
# $Locker:  $
# History: Check the bottom of the file for revision history
# ----------------------------------------------------------------------------

typeset -x PRGNAME=${0##*/}
typeset -x PRGDIR=${0%/*}
export PATH=$PATH:/usr/bin:/usr/sbin:/sbin

[[ $PRGDIR == . || $PRGDIR != /* ]] && PRGDIR=$(pwd)

typeset igndir=/opt/ignite/bin                      # ignite directory
typeset ignbin=make_tape_recovery                   # ignte tape recovery binary
typeset mt=/usr/bin/mt                              # binary for tape manipulation
typeset OpC="Operating Company"                     # Used for Log header.  Change it to suite your needs
typeset host=$(hostname)                            # extracting host name
typeset today=$(date +'%m/%d/%Y %H:%M')             # setting today's date: MM/DD/YY HH:MM
typeset logdir=/var/adm/log                         # location you can find your logs in
typeset logfil=${PRGNAME%???}.$(date +'%b').log     # log file name
typeset segrp=8649                                  # Group used by UNIX admins

function _note {
	echo " ** $*"
}

function _tapeDevice {
	typeset drv=$(ioscan -funC tape | awk '/[0-9]mn / { print $1 }' | tail -1)
	if [ -n "$drv" ]; then
		echo "$drv"
	else
		echo NODRV
	fi
}

function _line {
	typeset -i i=0
	for (( i = 0; i <= ${1:-80}; i++ )); do
		echo "-\c"
	done
	
	echo
}

function _mail {
	typeset email
	typeset mail

	pwget |\
	while IFS=: read -A acct; do
		[ ${acct[3]} -eq $segrp ] || continue # Only folks in se group are chosen
		
		# Not all servers are setup for resolving SMTP addresses
		# via JJEDS.  Hence, we will try to do it ourselves.  If a user
		# which is part of 'se' group has .forward file with the correct
		# email address, we will know about it and use it for notification.
		# Otherwise, we will simply skip it.

		mail=$(/usr/sbin/sendmail -bv ${acct[0]} | awk '/@/ { print $NF }')

		[ -n "$mail" ] && email="$email, $mail"

	done
	
	if [ ${#email} -lt 15 ]; then
		echo root
	else
		echo "${email#, }"
	fi
}

# ------------------------------------------------------------------------------
#                                   MAIN BODY
# ------------------------------------------------------------------------------

typeset tapedrv=$(_tapeDevice)

if [[ $tapedrv == NODRV ]]; then
	_note "${PRGNAME%???} ($LINENO): could not find viable tape device driver." |\
	mailx -s "${PRGNAME%???}: I cold not find valid tape device on $host!" $(_mail)
	exit 1
fi

_note "Rewinding [$tapedrv]: \c"
$mt -f $tapedrv rewind && {
	echo "[  OK  ]"
} || {
	echo "[FAILED]"
	_note "$PRGNAME ($LINENO): make sure tape is loaded and not ejected!" |\
	mailx -s "${PRGNAME%???}: tape rewind failed on $host!" $(_mail)
	exit 1
}


# ------------------------------------------------------------------------------

{
_line
printf "%-34s %8s %37s\n" "| $OpC" "$host" "$today |"
_line

$igndir/$ignbin -l -v -x inc_entire=vg00 -a $tapedrv

# If tape was created successfully, we will simply dismounted.  Otherwise,
# we will generate an error notification.

if [ $? -eq 0 ]; then
	echo "\n                   *  *  *"
	_note "${PRGNAME%???} ($LINENO): executing $mt -f $tapedrv offline: \c"

	$mt -f $tapedrv offline || echo "[  OK  ]" || {
		echo "[FAILED]"
		echo "  -- There was a problem dismounting tape."
	}

	mailx -s "${PRGNAME%???}: Success! Host: $host - $(date)" $(_mail) < $logdir/$logfil
else
	echo "\n                   *  *  *"
	mailx -s "${$PRGNAME%???}: Warnings! Host: $host - $(date)" $(_mail) < $logdir/$logfil
fi

} >> $logdir/$logfil 2>&1

# ----------------------------------------------------------------------------
# $Log: make_tape_recovery.sh,v $
# Revision 1.2  2006/06/19 00:32:09  bmynars
# Modified SMTP check by explicitly using SMTP email address instead of
# relying on sendmai.cf's ability to lookup JJEDS.
#
# Revision 1.1  2006/06/19 00:13:08  bmynars
# Adjusted for general purpose
#
#
# $RCSfile: make_tape_recovery.sh,v $
# $Source: /ncs/cvsroot/ncsbin/utils/make_tape_recovery.sh,v $
# $State: Stab $
# ----------------------------------------------------------------------------
