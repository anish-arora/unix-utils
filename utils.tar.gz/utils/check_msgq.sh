#!/usr/dt/bin/dtksh
# Author: Doug Boesch <dboesch@ncsus.jnj.com>
#
# $Revision: 1.2 $
# $Date: 2006/08/11 11:48:58 $
# $Header: /ncs/cvsroot/ncsbin/utils/check_msgq.sh,v 1.2 2006/08/11 11:48:58 bmynars Stab $ 
# $Id: check_msgq.sh,v 1.2 2006/08/11 11:48:58 bmynars Stab $
# $Locker:  $
# History: Check the bottom of the file for revision history
# ----------------------------------------------------------------------------

typeset -x PRGNAME=${0##*/}
typeset -x PRGDIR=${0%/*}

[[ $PRGDIR = . || $PRGDIR != /* ]] && PRGDIR=$(pwd)

function _line {
	typeset -i i=0
	while [ $i -lt ${1:-80} ]; do
		(( i+=1 ))
		echo "-\c"
	done
	echo
}

# ------------------------------------------------------------------------------
#                                   MAIN BODY
# ------------------------------------------------------------------------------

# Update mailing lists below accordingly to fit your needs.
INFORECIP=root
HIGHRECIP=root
CRITRECIP=root

LOG1=/var/adm/log/ipcs-qa-full.out
LOG2=${LOG1%/*}/ipcs-qa-used.log
LOG3=${LOG1%/*}/ipcs-msgtql-alert.log

typeset -i info high msgtql crit
typeset hostname=$(hostname)
typeset opcmsg=/opt/OV/bin/OpC/opcmsg

kmtune -q msgtql |\

while read val1 value junk; do
	case $value in
		[0-9]*) msgtql=$value ;;
		*) continue ;;
	esac
done

# Setting up default values for threshold levels
typeset -i info_pct=3 high_pct=10 crit_pct=15 i=0

info=$((($msgtql * 3) / 100)) 
high=$((($msgtql * 10) / 100)) 
crit=$((($msgtql * 15) / 100)) 

# ------------------------------------------------------------------------------

ipcs -qa > $LOG1
head -3 $LOG1 > $LOG2

while read -A rec; do
	# ${rec[0] will contain value of 'q'.  If not, we will skip the record
	[[ ${rec[0]} = q ]] || continue

	# ${rec[9]} will contain value of Qnum
	if [ ${rec[9]} -ne 0 ]; then
		# Grepping for hex value
		grep ${rec[3]} $LOG1 >> $LOG2
		i=$(($i+${rec[9]}))
	fi
done < $LOG1

if [[ $i -lt $high && $i -ge $info ]]; then
	#	echo "$(date +'%Y-%m-%d %H:%M'): msgtql parm = $msgtql" >> $LOG3
	_line 80 >> $LOG3
	head -3 $LOG1 >> $LOG3
	grep ^q $LOG2 | sort -rn -k 10,10 >> $LOG3
	printf "%15s: %d %s\n" "`date` - Informational Alert.  Current msgtql Value" "$i" "is >= $info_pct% of $msgtql" >> $LOG2
	printf "%15s: %d %s\n" "`date` - Informational Alert.  Current msgtql Value" "$i" "is >= $info_pct% of $msgtql" >> $LOG3
	printf "%15s: %d %s\n" "`date` - Informational Alert.  Current msgtql Value" "$i" "is >= $info_pct% of $msgtql" | \
	mailx -s "$hostname MSGTQL INFORMATIONAL ALERT (>= $info_pct%)" $INFORECIP
	mailx -s "$hostname MSGTQL INFORMATIONAL ALERT (>= $info_pct%)" $INFORECIP < $LOG2
	
	if [ -x $opcmsg ]; then
		$opcmsg sev=normal app="IPC Alert >= $info_pct%" \
		obj=alarmgen msg_grp=Performance \
		msg_text="IPC Message Queue NORMAL Alert >= $info_pct% of $msgtql.  No action necessary."
	fi
fi

if [[ $i -lt $crit && $i -ge $high ]]; then
	#	echo "$(date +'%Y-%m-%d %H:%M'): msgtql parm = $msgtql" >> $LOG3
	_line 80 >> $LOG3
	head -3 $LOG1 >> $LOG3
	grep ^q $LOG2 | sort -rn -k 10,10 >> $LOG3
	printf "%15s: %d %s\n" "`date` - High Alert.  Current msgtql Value" "$i" "is >= $info_pct% of $msgtql" >> $LOG2
	printf "%15s: %d %s\n" "`date` - High Alert.  Current msgtql Value" "$i" "is >= $high_pct% of $msgtql" >> $LOG3
	mailx -s "$hostname MSGTQL HIGH ALERT (>= $info_pct%)" $HIGHRECIP < $LOG2
	
	if [ -x $opcmsg ]; then
		$opcmsg sev=critical app="IPC Alert >= $high_pct%" \
		obj=alarmgen msg_grp=Performance msg_text="IPC Message Queue HIGH Alert >= $high_pct% of $msgtql.  Contact SE for $hostname."
	else
		printf "%15s: %d %s\n" "`date` - High Alert.  Current msgtql Value" "$i" "is >= $high_pct% of $msgtql" | \
		mailx -s "$hostname MSGTQL HIGH ALERT (>= $high_pct%)" $HIGHRECIP
	fi
fi

if [[ $i -ge $crit ]]; then
	#	echo "$(date +'%Y-%m-%d %H:%M'): msgtql parm = $msgtql" >> $LOG3
	_line 80 >> $LOG3
	head -3 $LOG1 >> $LOG3
	grep ^q $LOG2 | sort -rn -k 10,10 >> $LOG3
	printf "%15s: %d %s\n" "`date` - Critical Alert.  Current msgtql Value" "$i" "is >= $info_pct% of $msgtql" >> $LOG2
	printf "%15s: %d %s\n" "`date` - Critical Alert.  Current msgtql Value" "$i" "is >= $crit_pct% of $msgtql" >> $LOG3

	mailx -s "$hostname MSGTQL CRITICAL ALERT (>= $info_pct%)" $CRITRECIP < $LOG2
	
	if [ -x $opcmsg ]; then
		$opcmsg sev=critical app="IPC Alert >= $crit_pct%" obj=alarmgen msg_grp=Performance \
		msg_text="IPC Message Queue CRITICAL Alert >= $crit_pct% of $msgtql.  Contact SE for $hostname."
	else
		printf "%15s: %d %s\n" "`date` - Critical Alert.  Current msgtql Value" "$i" "is >= $crit_pct% of $msgtql" | \
		mailx -s "$hostname MSGTQL CRITICAL ALERT (>= $crit_pct%)" $CRITRECIP	
	fi
fi

# ----------------------------------------------------------------------------
# $Log: check_msgq.sh,v $
# Revision 1.2  2006/08/11 11:48:58  bmynars
# Cleaned up version for general use
#
# Revision 1.1  2006/08/10 17:54:33  bmynars
# Initial commit
#
# $RCSfile: check_msgq.sh,v $
# $Source: /ncs/cvsroot/ncsbin/utils/check_msgq.sh,v $
# $State: Stab $
# ----------------------------------------------------------------------------
