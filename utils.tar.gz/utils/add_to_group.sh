#!/bin/sh
# Author: Bolek Mynarski <bmynars@ncsus.jnj.com>
#
# $Revision: 1.2 $
# $Date: 2005/11/19 05:40:47 $
# $Header: /ncs/cvsroot/ncsbin/utils/add_to_group.sh,v 1.2 2005/11/19 05:40:47 bmynars Stab $ 
# $Id: add_to_group.sh,v 1.2 2005/11/19 05:40:47 bmynars Stab $
# $Locker:  $
# History: Check the bottom of the file for revision history
# ----------------------------------------------------------------------------

typeset -x PRGNAME=${0##*/}
typeset -x PRGDIR=${0%/*}

[[ $PRGDIR = . || $PRGDIR != /* ]] && PRGDIR=$(pwd)

export FPATH=${PRGDIR%/utils}/acctutil/functions
export PATH=$PATH:/usr/sbin:/sbin

# Sanity Checks

if [ -d $FPATH ]; then
	: # Everything is fine
	
else
	echo " *** $PRGNAME ($LINENO): Fatal error occured.  [$FPATH] missing!"
	exit 1
fi

# ------------------------------------------------------------------------------
#                                   MAIN BODY
# ------------------------------------------------------------------------------


# Purpose: To enable network security personnel to add users
#          to more than one group.
#
# Steps:
#      1. Receive the input from the user
#      2. Check if the user id exists on the server
#      3. If it does, display a list of available groups
#         (mask system groups that would be used by UNIX
#          sysadmin)
#      4. Append the user to the group in /etc/group

grpfile=/etc/group
now=$(date +'%a')
host=$(hostname)
lock=/var/tmp/${PRGNAME%???}.lck

# ------------------------------------------------------------------------------
#                                 Local Functions
# ------------------------------------------------------------------------------

function _message {
	printf "  ** %s\n\n" "Usage: $PRGNAME -u <user> -g <group>"
}


function _die {
	_note "$1"
	exit 1
}

# ------------------------------------------------------------------------------
#                                 Local settings
# ------------------------------------------------------------------------------

typeset host user group

# Check for the lock file

if [ -f $lock ]; then
	_note "Try again in a couple of minutes."
	_note "[$lock] is present."
	sleep 3
	exit
else
	touch $lock || {
		_note "Could not set the lock file."
		exit 1
	}
fi

trap "rm -f $lock; exit" 0 1 2 3 9 15

# ------------------------------------------------------------------------------
#                                   Main Body
# ------------------------------------------------------------------------------

# We will parse arguments/parameters passed to the script.  Most of the error/
# logic checking will take place below

[ $# -ne 4 ] && { _message; exit 1; }

while [ $# -gt 0 ]; do
	case $1 in
		-u)
			user=$2
			[ -n "$user" ] || _die "Must specify uid with '-u'"
			pwget -n $user 1> /dev/null || _die "User [$user] does not exist on [$host]"			
			shift 2
		;;
		-g)
			group=$2
			
			# Checking if the passed group is a valid one
			
			grep -q "^$group:" /etc/group || _die "Group [$group] does not exist on [$host]"
			
			# Finaly, is the user already assigned to the request group?
			
			for i in $(groups $user); do
				[ "$i" = "$group" ] && _die "[$user] already belongs to [$group] on $host"
			done
			
			shift 2
		;;
		*) _message; exit 1 ;;
	esac
done

# Core of the script.  To add the user to a new group (additional group), we will
# use 'perl' one liner using -p -i -e parameters.  Before we do it, however, we
# will create a copy of $grpfile

cksum $grpfile | read orgHash orgSize orgFile

# ------------------------------------------------------------------------------

# Only after successful copying of the group file, we proceed with further
# processing:

cp -p $grpfile $grpfile.$now && {
	cksum $grpfile.$now | read oldHash oldSize oldFile
	[ "$orgHash" = "$oldHash" ] || _die "[$grpfile] has changed while trying to add a user (Different hash size)"
	[ "$orgSize" = "$oldSize" ] || _die "[$grpfile] has changed while trying to add a user (Different file size)"
	
	# Adding a user to a group

	_note "Added [$user] to group [$group]: \c"
	
	# Making sure that the entry is not the first for the group.
	# If it is, we want to make sure that the comma does not
	# preceed the user.
	
	if [ -n "$(grep "^$group:" $grpfile | cut -d: -f4)" ]; then
		adduser=",$user"
	else
		adduser="$user"
	fi
	
	perl -p -i -e "s/^($group:.*)$/\1${adduser}/" $grpfile && {
		cksum $grpfile | read newHash newSize newFile
		
		if [ $newSize -eq 0 ]; then
			# We have to rollback.  Something went terribly wrong!
			echo "[Failed]"
			_note "Rolling back the changes: \c"
			cp $grpfile.$now  $grpfile 	&& echo "[  OK  ]" || {
				echo "[Failed]"
				{
				echo "While rolling back the group file to its original state,"
				echo "an error has occured.  Please, investigate immediately!"
				echo "Rollback was taking place on [$host] at $(date)"
				} | mailx -s "Error has occured [$PRGNAME]" root 
			}
		else
			# Checking for the hash size.  They SHOULD BE different
			[ "$newHash" = "$oldHash" ] && {
				echo "[Failed]"
				{
				echo "After checking the hash size of $group"
				echo "before and after change, both hashes are"
				echo "the same.  We would expect them to be different."
				echo "Please, investigate>"
				} | mailx -s "[$PRGNAME]: $hostname" root 
			} || {
				echo "[  OK  ]"
			}
		fi
	} # End of perl routine
} || {
	_note "$PRGNAME ($LINENO): could not copy [$grpfile].  Quitting."
} # End of grouping of creating a backup copy of $grpfile

# ----------------------------------------------------------------------------
# $Log: add_to_group.sh,v $
# Revision 1.2  2005/11/19 05:40:47  bmynars
# Replaced elm with mailx and sysadm with root
#
# Revision 1.1  2005/11/19 05:25:41  bmynars
# Initial checkin
#
# $RCSfile: add_to_group.sh,v $
# $Source: /ncs/cvsroot/ncsbin/utils/add_to_group.sh,v $
# $State: Stab $
# ----------------------------------------------------------------------------
