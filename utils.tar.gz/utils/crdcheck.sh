#!/bin/sh
# Author: Bolek Mynarski <bmynars@ncsus.jnj.com>
#
# $Revision: 1.1.1.1 $
# $Date: 2005/10/05 12:32:26 $
# $Header: /ncs/cvsroot/ncsbin/utils/crdcheck.sh,v 1.1.1.1 2005/10/05 12:32:26 bmynars Stab $ 
# $Id: crdcheck.sh,v 1.1.1.1 2005/10/05 12:32:26 bmynars Stab $
# $Locker:  $
# History: Check the bottom of the file for revision history
# ----------------------------------------------------------------------------

# Purpose of this program is to provide a quick survey of
# what ethernet cards are active on our server.

typeset -x PRGNAME=${0##*/}
typeset -x PRGDIR=${0%/*}

typeset link=/usr/sbin/linkloop
typeset scan=/usr/sbin/lanscan

function _note {
	echo " ** $*"
}

function _line {
	typeset -i i=0
	while [ $i -lt ${1:-80} ]; do
		(( i+=1 ))
		echo "=\c"
	done
	
	echo
}

# ------------------------------------------------------------------------------
# SANITY CHECKS
# ------------------------------------------------------------------------------

for i in $link $scan; do
	[ -x "$i" ] || { _note "$PRGNAME ($LINENO): missing [$i]"; exit 1; }
done

# ------------------------------------------------------------------------------
# MAIN BODY
# ------------------------------------------------------------------------------

typeset -i i=0
set -A card

$scan |\
while read path addr crd hdw ppa id junk; do
	case $path in
		+([0-9])/+([0-9])/*) : ;; # OK.  We have a valid hw path
		LinkAgg+([0-9])) : ;; # OK.  Port Aggregation is used
		*) continue ;;
	esac
	card[(( i+=1 ))]="${path}:${addr}:${crd}:${ppa}"	
done


if [ ${#card[@]} -lt 1 ]; then
	_note "$PRGNAME ($LINENO): no cards were found!"	
fi

unset i

printf  "%21s %15s %4s %6s %5s\n" \
"$(_line 21)" "$(_line 15)" "====" "$(_line 6)" "$(_line 5)"

printf "%21s %15s %4s %6s %5s\n" "Hardware Path" "MAC" "In" "PPA" "State"

printf  "%21s %15s %4s %6s %5s\n" \
"$(_line 21)" "$(_line 15)" "====" "$(_line 6)" "$(_line 5)"

# ------------------------------------------------------------------------------

for x in "${card[@]}"; do

	# 'tr' was used originally.  I will replace
	# it with faster IFS split.
	# set -A crdinfo $(echo $x | tr ':' '\n')

	oIFS=$IFS; IFS=:
	set -A crdinfo $x; IFS=$oIFS

	# crdinfo[0] - card's hardware path
	# crdinfo[1] - card's MAC address
	# crdinfo[2] - card's instance number
	# crdinfo[3] - card's PPA name
	
	if [ ${#crdinfo[@]} -ne 4 ]; then
		_note "$PRGNAME ($LINENO): one of card's elements is missing!"
		exit 1
	fi
	
	$link -i ${crdinfo[2]} ${crdinfo[1]} 2> /dev/null |\
	while read LINE; do
		case $LINE in
			*'-- OK') state=UP ;;
			*) state=DOWN ;;
		esac
	done
	
	printf "%21s %15s %4s %6s %5s\n" "${crdinfo[0]}" "${crdinfo[1]}" \
	"${crdinfo[2]}" "${crdinfo[3]}" "$state"
	
done

# ----------------------------------------------------------------------------
# $Log: crdcheck.sh,v $
# Revision 1.1.1.1  2005/10/05 12:32:26  bmynars
# Import
#
# Revision 1.4  2005/09/20 02:26:54  bmynars
# Replaced external calls with built ins
#
# Revision 1.3  2005/09/04 12:23:52  bmynars
# Changed state description
#
# Revision 1.2  2005/09/03 23:58:29  bmynars
# Modified to account for port aggregation
#
# Revision 1.1  2005/09/02 13:37:25  bmynars
# Initial check in
#
# $RCSfile: crdcheck.sh,v $
# $Source: /ncs/cvsroot/ncsbin/utils/crdcheck.sh,v $
# $State: Stab $
# ----------------------------------------------------------------------------
