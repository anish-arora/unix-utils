#!/usr/bin/ksh
# Author: Unknown
# Expanded and modified by: Bolek Mynarski <bmynars@ncsus.jnj.com>
#
# $Revision: 1.6 $
# $Date: 2010/06/18 18:22:27 $
# $Header: /ncs/cvsroot/ncsbin/utils/serverinfo.sh,v 1.6 2010/06/18 18:22:27 bmynars Exp $
# $Id: serverinfo.sh,v 1.6 2010/06/18 18:22:27 bmynars Exp $
# $Locker:  $
# History: Check the bottom of the file for revision history
# ----------------------------------------------------------------------------

typeset -x PRGNAME=${0##*/}
typeset -x PRGDIR=${0%/*}

[[ $PRGDIR = . || $PRGDIR != /* ]] && PRGDIR=$(pwd)

typeset -x FPATH=${PRGDIR%/*}/functions
typeset -x PATH=$PATH:/usr/sbin:/sbin:/bin:/usr/bin

[ -d $FPATH ] || { printf "  ** %s\n" "[$FPATH] does not exist.  Cannot continue."; exit 1; }

# You must be ROOT to execute this since it uses adb to
# examine the running kernel

_idCheck

function _GetKernelSymbol {

	# This is a main function as we are using adb debugger with passed arguments.
	# Depending on what is passed, we will get info on memory, cpu count, etc.

	typeset cmp=''
	typeset machinfo=$(which machinfo); machinfo=${machinfo%% *}
	typeset cpn

	case $os in
		B.11.[01]*) cmp='' ;; # We are OK
		*) cmp=' -o' ;;
	esac

	if [[ $1 = processor_count ]]; then
		if [[ $os = B.11.3* ]]; then
			$machinfo |\
			while read LINE; do
				typeset -l proc=$LINE
				if [[ $proc = *itanium?([ ])+([[:digit:]])?([ ])proc* ]]; then
					cpn="${proc##*itanium }"; cpn=${cpn%% *}
					kval=$cpn
					return
				fi
			done
		else
			echo "$1/D" | adb${cmp} $hpux /dev/kmem |\
			tail -1 | cut -d: -f2 | read kval
		fi
	else
		echo "$1/D" | adb${cmp} $hpux /dev/kmem |\
		tail -1 | cut -d: -f2 | read kval
	fi # This is a condition for proc count on 11.31.  kernel read does not
       # give us an accurate number so we will use 'machinfo' instead of
       # adb debugger.
}

function _swapinfo {
	typeset -i sval=totalsval=0
	typeset lv

	for lv in $(swapinfo -tam | awk '/dev/ { print $NF }'); do
		sval=$(lvdisplay -v $lv | awk '/Mbytes/ { print $NF }')
		totalsval=$(($totalsval + $sval))
		_print "swapspace" "$totalsval MB"
	done
}

function _upTime {
	typeset up=$(uptime)
	up=${up%%,*}; up=${up#*up }
	echo $up
}

function _print {
	printf "%25s: %-s\n" "$1" "$2"
}

typeset hpux=/stand/vmunix
typeset os=$(uname -r)
typeset host=$(hostname)
typeset hwsup=`getconf HW_CPU_SUPP_BITS 2> /dev/null`
typeset ksup=`getconf KERNEL_BITS 2> /dev/null`
typeset mser=`getconf MACHINE_SERIAL 2> /dev/null`

# ------------------------------------------------------------------------------
#                                   MAIN BODY
# ------------------------------------------------------------------------------

uname -a
_print "Model" "$(model)"
_print "OS Version" "$os"
_print "HostName" "$(nslookup $host | awk '/Name/ { print $2 }')"

_GetKernelSymbol "processor_count"
_print "CPU Count" "$kval"

_GetKernelSymbol "itick_per_tick"
speed=$(($kval/10000))
_print "CPU Speed" "$speed MHz"

[ -n "$hwsup" ] || hwsup="NoInfo"
[ -n "$ksup" ] || ksup="NoInfo"
[ -n "$mser" ] || mser="NoInfo"

_print "CPU HW Support" "$hwsup -bit"
_print "Kernel Support" "$ksup -bit"


case $os in
	B.11.[01]*)
		_GetKernelSymbol "memory_installed_in_machine"
		mb=$((kval*4/1024)) # convert pages to MB
		_print "RAM Size" "$mb MB"
	;;
	B.11.2*)
		_print "RAM Size" "$(machinfo | awk '/^Memory/ { print $3 }') MB"
	;;
	B.11.3*)
		_print "RAM Size" "$(machinfo | awk '/^Memory/ { print $2 }') MB"
	;;
	*) _print "RAM Size" "Unknown" ;;
esac


_swapinfo

_print "Serial#" "$mser"

_GetKernelSymbol "bufpages"
mb=$((kval*4/1024)) # convert pages to MB
_print "bufpages" "$mb MB"

_GetKernelSymbol "maxuprc"
_print "maxuprc" "$kval"

_GetKernelSymbol "maxvgs"
_print "maxvgs" "$kval"

_GetKernelSymbol "maxfiles"
_print "maxfiles" "$kval"

_GetKernelSymbol "max_thread_proc"
_print "max_thread_proc" "$kval"

_GetKernelSymbol "nfile"
_print "nfile" "$kval"

if [[ $os = B.11.[01]* ]]; then
	_GetKernelSymbol "nflocks"
	_print "nflocks" "$kval"
elif [[ $os = B.11.2* ]]; then
	_print "nflocks" "$(kctune | awk '/^nflocks/ { print $2 }')"
fi

_GetKernelSymbol "nproc"
_print "nproc" "$kval"

_GetKernelSymbol "ninode"
_print "ninode" "$kval"

_GetKernelSymbol "vfd_cw"
_print "shmmax" "$kval"

_GetKernelSymbol "shmmni"
_print "shmmni" "$kval"

case $os in
	B.11.3*) _print "dbc_max_pct" "[ N/A ]" ;;
	*)
		_GetKernelSymbol "dbc_max_pct"
		_print "dbc_max_pct" "$kval"
	;;
esac

_print "Uptime" "$(_upTime)"
_print "LocalTime" "$(date)"

# ----------------------------------------------------------------------------
# $Log: serverinfo.sh,v $
# Revision 1.6  2010/06/18 18:22:27  bmynars
# Modified routine for CPU count on B.11.31 as adb
# was providing us with an incorrect information.  Utilized
# machinfo instead.
#
# Revision 1.5  2010/06/11 15:36:16  bmynars
# Updated for HP-UX 11.31
#
# Revision 1.4  2010/06/11 15:11:09  bmynars
# Added uptime to the list of returned attributes.
#
# Revision 1.3  2007/01/28 03:18:33  bmynars
# Modified script so now it can be run on Itanium platform.  Display
# output looks the same like on PA RISC preserving the same 'look & feel'.
#
# Revision 1.2  2006/11/26 00:31:50  bmynars
# This script only works with HP-UX 11.00 & 11.11 systems.  After testing
# it on 11.23, majority of stuff used by 'adb' commnad is no longer applicable.
#
# Revision 1.1  2006/11/25 15:26:58  bmynars
# Script originally written by "anonymous".  Provides info on vital
# system settings.
#
#
# $RCSfile: serverinfo.sh,v $
# $Source: /ncs/cvsroot/ncsbin/utils/serverinfo.sh,v $
# $State: Exp $
# ----------------------------------------------------------------------------
