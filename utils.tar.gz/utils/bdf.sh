#!/usr/dt/bin/dtksh
# Author: Bolek Mynarski <bmynars@ncsus.jnj.com>
#
# $Revision: 1.1.1.1 $
# $Date: 2005/10/05 12:32:26 $
# $Header: /ncs/cvsroot/ncsbin/utils/bdf.sh,v 1.1.1.1 2005/10/05 12:32:26 bmynars Stab $ 
# $Id: bdf.sh,v 1.1.1.1 2005/10/05 12:32:26 bmynars Stab $
# $Locker:  $
# History: Check the bottom of the file for revision history
# ----------------------------------------------------------------------------

# If you want to turn tracing on, uncomment line below
# set -x

typeset -x PRGNAME=${0##*/}
typeset -x PRGDIR=${0%/*}

[[ $PRGDIR == . ]] && PRGDIR=$(pwd)

function _line {
	typeset -i i=0
	while [ $i -lt ${1:-80} ]; do
		(( i+=1 ))
		echo "-\c"
	done
	echo
}

function _note {
	echo " ** $*"
}

function _mb {

	typeset mb=$1
	
	mb=$(_reverse $mb); mb=$(_split $mb); mb=$(_reverse $mb)
	
	# This is mainly to give more clear representation of sizes lower than 1 Gb
	# in grand total section.  So, if there are only 200Gb, it will display
	# 0.2 rather than '2' by itself and so on.
	
	if [ ${#mb} -le 3 ]; then
		echo 0.${mb}
	else
		echo $mb
	fi
}

function _reverse {
	typeset mb="$1"
	typeset i=${#mb}
	typeset temp="";  typeset num=""

	while [ $i -gt 0 ]; do
		temp=${mb:(( i-=1 )):1}
		num="${num}${temp}"
	done
	echo $num
}

function _split {
	typeset mb="$1"
	typeset i=0
	typeset temp=""; typeset num=""
	typeset j=0

	while [ $i -lt ${#mb} ]; do
        temp=${mb:$i:1}
        if [ $(( $i%3 )) -eq 0 ]; then
			(( j+=1 ))
			
			if [ $j -le 2 ]; then
				c="."
			else
				c=","
			fi
			
			num="${num}${c}${temp}"
        else
			num="${num}${temp}"
        fi

        (( i+=1 ))
	done

	echo ${num#.}
}


function _header {
	printf "%33s %12s %12s %12s %5s %-s\n" "$(_line 33)" "$(_line 12)" "$(_line 12)" "$(_line 12)" "$(_line 5) $(_line 15)"
	printf "%33s %12s %12s %12s %5s %-s\n" "Logical Volume" "Total MB" "Used MB" "Free MB" "%Used" "Mounted On"
	printf "%33s %12s %12s %12s %5s %-s\n" "$(_line 33)" "$(_line 12)" "$(_line 12)" "$(_line 12)" "$(_line 5) $(_line 15)"
}

# If you want to turn tracing on, uncomment line below
# typeset -fx _next; typeset -fx _split; typeset -fx _reverse; typeset -fx _mb

# ------------------------------------------------------------------------------
#                                  MAIN BODY
# ------------------------------------------------------------------------------

lflag=""; tflag=""

while getopts :lt: opt; do
	case $opt in
		l) lflg="-l" ;;
		t) tflg="-t $OPTARG" ;;
		:) _note "$PRGNAME: $OPTARG requires a value"
			exit 2
		;;
		\?) _note "$PRGNAME: unknown options: $OPTARG"
			echo "    Usage: $PRGNAME [-l -t <vxfs|nfs|[...]>]"
			exit 2
		;;
	esac
done

shift $((OPTIND-1))
typeset -x BDF="/usr/bin/bdf $lflg $tflg ${*:-}"
_header

typeset -i i=j=count=0
typeset -i kbyte=used=free=0

$BDF |\
while read LINE; do

	set -A arry $(echo $LINE)
	[[ ${arry[0]} == File* ]] && continue # Skip original bdf header

	if [ ${#arry[@]} -eq 6 ]; then
		i=0
		vol=${arry[0]#/dev/}
	elif [ ${#arry[@]} -eq 5 ]; then
		i=0
	else
		vol=${arry[0]#/dev/}
		i=1
		continue
	fi

	if [ $i -eq 0 ]; then
		if [ ${#arry[@]} -eq 6 ]; then
			k=${arry[1]}; u=${arry[2]}; f=${arry[3]}; p=${arry[4]}; mount=${arry[5]}
		elif [ ${#arry[@]} -eq 5 ]; then
			k=${arry[0]}; u=${arry[1]}; f=${arry[2]}; p=${arry[3]}; mount=${arry[4]}
		fi

		kbyte=$(( $kbyte+$(($k/1024)) ))
		used=$(( $used+$(($u/1024)) ))
		free=$(( $free+$(($f/1024)) ))

		[ ${#vol} -gt 33 ] && vol=${vol#*/}
		printf "%33s %12s %12s %12s %5s %-s\n" "$vol" "$(_mb $k)" "$(_mb $u)" "$(_mb $f)" "$p" "$mount"

		(( count+=1 ))
	
		[ $(($count%54)) -eq 0 ] && _header
	fi
done

k=$kbyte; u=$used; f=$free

printf "%33s %12s %12s %12s\n" "$(_line 33)" "$(_line 12)" "$(_line 12)" "$(_line 12)"
printf "%33s %12s %12s %12s\n" "Total (GB)" "$(_mb $k)" "$(_mb $u)" "$(_mb $f)"

# ----------------------------------------------------------------------------
# $Log: bdf.sh,v $
# Revision 1.1.1.1  2005/10/05 12:32:26  bmynars
# Import
#
# Revision 1.10  2005/06/02 15:16:10  bmynars
# Updated bdf.sh by making more clear sizes lower than 1Gb in grand total
#
# Revision 1.9  2005/04/14 14:01:12  bmynars
# Added a check for current path.  If it is set to '.', we will expand it
# to fully qualified name.
#
# Revision 1.8  2005/04/13 02:11:18  bmynars
# Simplified calc between 5 and 6 elements
#
# Revision 1.7  2005/04/12 13:02:21  bmynars
# Removed vg00 display only
#
# Revision 1.6  2005/04/05 04:56:23  bmynars
# Added options
#
# Revision 1.5  2005/04/04 00:18:04  bmynars
# Included a decimal point to make it more clear whether we speak of mega
# bytes, kilobytes or other.
#
# Revision 1.3  2005/04/03 22:47:28  bmynars
# Simplified calculations of totals.
#
# Revision 1.2  2005/04/03 20:49:55  bmynars
# Added comments about 'app' argument
#
# $RCSfile: bdf.sh,v $
# $Source: /ncs/cvsroot/ncsbin/utils/bdf.sh,v $
# $State: Stab $
# ----------------------------------------------------------------------------


