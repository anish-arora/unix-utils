#!/usr/bin/ksh
# Original Author: Bolek Mynarski <bmynars@its.jnj.com>
#
# $Revision: 1.2 $
# $Date: 2009/01/16 21:05:23 $
# $Header: /ncs/cvsroot/ncsbin/utils/log_cleanup.sh,v 1.2 2009/01/16 21:05:23 bmynars Exp $
# $Id: log_cleanup.sh,v 1.2 2009/01/16 21:05:23 bmynars Exp $
# $Locker:  $
# History: Check the bottom of the file for revision history
# ----------------------------------------------------------------------------

typeset -x PRGNAME=${0##*/}
typeset -x PRGDIR=${0%/*}

[[ $PRGDIR = /* ]] || PRGDIR=$(pwd) # Acquire absolute path to the script

function _note {
	echo " ** $*"
}

function _errNote {
	echo " ** ERROR: $*"
}

function _ok {
	echo "[  OK  ]"
}

function _nok {
	echo "[FAILED]"
}

function _line {
	typeset -i count=0
	while (( count < ${1:-80} )); do
		(( count+=1 ))
		echo "-\c"
	done
	echo
}

function _revision {
	typeset rev
	rev=$(awk '/Revision:/ { print $3 }' $PRGDIR/$PRGNAME | head -1)
	[ -n "$rev" ] || rev="UNKNOWN"
	echo $rev
}

function _whoami {
	typeset u=$(id)
	u=${u%%\)*}; u=${u#*\(}
	[ -n "$u" ] && echo "$u" || echo UNKNOWN
}

typeset archdir=/var/adm/log_archive
typeset logdir=/var/adm/log
typeset logfil=$logdir/${PRGNAME%???}-$(date +'%a').log
typeset lhost=$(uname -n)
typeset osVer=$(uname -r)
typeset model=$(model)
typeset days=365

# -----------------------------------------------------------------------------
#                                 SANITY CHECKS
# -----------------------------------------------------------------------------

for i in $logdir $archdir; do
	if [ ! -d $i ]; then
		if [[ $i = *_archive ]]; then
			_errNote "[$archdir] is not present on [$lhost]"
    		exit 1
		fi

		_note "Creating [$i]: \c"
		if mkdir -p $i 2> /dev/null; then
			_ok
		else
			_nok
			_errNote "Could not create [$i]"
			exit 1
		fi
	fi
done

# -----------------------------------------------------------------------------
#                                  MAIN BODY
# -----------------------------------------------------------------------------

{
_line
echo "       Cleanup Script: $PRGNAME"
echo "             Revision: $(_revision)"
echo "           OS Release: $osVer"
echo "                Model: $model"
echo "           Local Host: $lhost"
echo "         Running User: $(_whoami)"
echo "         Running Date: $(date +'%Y-%m-%d @ %H:%M:%S')"
echo "          Running Log: $logfil"
_line; echo


for i in $(find $archdir -type f -mtime +${days}); do
		[ -f "$i" ] || continue
		_note "Removing [$i]: \c"
		rm -f "$i" && _ok || _nok
done

echo
} > $logfil 2>&1

# ----------------------------------------------------------------------------
# $Log: log_cleanup.sh,v $
# Revision 1.2  2009/01/16 21:05:23  bmynars
# Simplified cleanup script.  No arguments required.
#
#
# $RCSfile: log_cleanup.sh,v $
# $Source: /ncs/cvsroot/ncsbin/utils/log_cleanup.sh,v $
# $State: Exp $
# ----------------------------------------------------------------------------