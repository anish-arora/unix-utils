Getting information from the customer

In order to get information from the customer, the customer must run the script.
The script can be sent per e-mail (size is about 60kB).
The script can be placed in any directory, but to run it root capability is required.
First thing that happens when the script starts is checking if the customer is having root
capability etc.
Next the customer is requested to fill in data about his system contract etc, needed in case of a service call has to be made (will be saved on the system, one time input only).
The remaining part of the script collects automatically the technical data.
When the script is completed a file is created with the name of the computer and the extension.
In case the system name is Sap_db, the file would be called Sap_db_date_time.gz.
The file is in gzip format, (compressed) so that it requires a minimal time to send the information per e-mail to the HP response center.

Dear customer:

In our efforts to shorten time to investigate hardware or software issues with HP9000 systems we have developed a 2 component application.
The first part is a script called check that will collect data of the HP9000 server and the second part is an application called Healthcheck 9000 that is used by HP engineers to analyze the collected data.
With this application we hope that we have simplified the process of collecting data and that in most cases enough data is collected to resolve the issue.
The output of the script will be zipped using gzip and has the name of the system plus the date and time so that the name becomes unique.
When sending the script output, please make sure that a binary transfer method is used all the way trough otherwise the file will become useless.

In order to run the check script it needs to be made executable using the command 'chmod 544 check'.
The latest version of the script is dated July 19, 2004, and can be checked by using the command 'what check'.
The script is not using any special commands, all commands are standard HP-UX commands like ioscan etc and collects device information using the Mesa diagnostic that should not cause any problems.

Warnings:

Tape devices do sequential I/O and may experience problems when commands like ioscan are executed, direct access devices (DAS) like disk drives are not sensitive to this.
For that reason we advise never to run this script when a backup is running on any of the tape drives that are connected to the system directly or in a zone in the Storage Area Network.

When the script is running on an active HP9000 cluster, the script is checking the NODE_TIMEOUT parameter by using the cmgetconf command.
Whenever the cmgetconf command is finding errors, it will not detect the NODE_TMEOUT value and the script stops.
When the script stops, we advise to investigate first why the cmgetconf command is giving these errors and correct the situation before running the script again!
There can be rare circumstances in which some older Processor Dependent Code procedures could take up to 4 seconds, this is why the NODE_TIMEOUT value is checked.

