#!/bin/sh
# Author: Possibly Gregg Ralston
#
# $Revision: 1.4 $
# $Date: 2006/03/12 08:14:26 $
# $Header: /ncs/cvsroot/ncsbin/utils/lvminf.sh,v 1.4 2006/03/12 08:14:26 bmynars Stab $ 
# $Id: lvminf.sh,v 1.4 2006/03/12 08:14:26 bmynars Stab $
# $Locker:  $
# History: Check the bottom of the file for revision history
# ----------------------------------------------------------------------------

typeset -x PRGNAME=${0##*/}
typeset -x PRGDIR=${0%/*}

[[ $PRGDIR = . || $PRGDIR != /* ]] && PRGDIR=$(pwd)

# ------------------------------------------------------------------------------
#                                   MAIN BODY
# ------------------------------------------------------------------------------


function show_help {
cat <<-EnD | pg -p"$(basename $0) help, page %d:" -c

 NAME
      $(basename $0) - list system LVM information in tabular form

 SYNOPSIS
      $(basename $0) [-d] [-h] [-g vol_group_name] [-u] [-f] [-q] [-s] [-i]
                 [[[-p printer-id | -l printer-id] -x [v | h]] | -n | 
                 -m destination] [-D output_directory] [-t]

 DESCRIPTION
      This shellscript scans the system on which it is run and creates a file
      which contains a columnar formatted report of the LVM info for the
      system.  The content and disposition of the output file varies depending
      upon the command line options supplied.

    Options
      lvminfo recognizes the following options:

      Ordering:
           -d	Sort the output file by ascending hardware address.  This is
                useful for seeing what is located on a specific disk or 
                disks.  If this option is omitted, the output file is sorted
                by LV name within VG name.
        
      Filtering:
           -g   Causes the shellscript to report only the information for
                the specified VG.  In this case, no hardware scan is done;
                the VG is queried for the pertinent disk information.
                This option is not allowed when the -u is supplied.
        
           -u	Restricts the contents of the output file to available free
                devices only, i.e. those disks which are not part of any VGs.
                This option is not allowed when the -g is supplied.
        
           -f	Restricts the contents of the output file to available free
                extents only, i.e. those areas of disks in VGs which are not
                in use.
        
           -i	Restricts the contents of the output file to disks which are 
                in inactive VGs (such as might be found on nodes in a 
                ServiceGuard cluster).

     Formatting:
           -t   Causes the output file to be created with tab-separated fields.
                The default is space-separated fields.

      Disposition:
           -p	Specfies that the output file is to be queued to print to the
                specified printer in portrait orientation.  If the destination
                does not exist, the shellscript exits with an error.  If a
                destination of "default" is specified, the following are tried
                in order:
        
                1)  The destination specified by the PRINTQUEUE variable
                2)  The destination specified by the LPDEST variable
                3)  The destination specified by the PRINTER variable
                4)  The system default destination, if one exists
        
                If none of the above are applicable, the output file is pg'ed
                to stdout.
        
           -l   Same as the -p, except that landscape orientation will
                be applied.
        
           -x   Specifies that output is to be printed duplex (double-sided).
                The two choices are v (long edge binding) and h (short edge
                binding).  This option is not permitted unless either the -p
                or -l is also specified.

           -v	This option assumes the presence of Vista online report
                viewing software by Quest Systems.  If the file capture.cfg
                is not found in either /opt/vcs or /opt/vcs_remote,
                the shellscript exits with an error.
        
           -m   Specifies that output is to be mailed to the destination.
                No check is made to see that the destination is valid or
                reachable.

           -n   No special action is taken.  The output file is created only.
        
           -D   Specifies an alternate directory into which the output file
                is placed.  If not supplied, /tmp is assumed. In addition, the
                the following also apply:

                If -f is supplied, the output file name is
                     $(hostname)_free_VG_space
                If -g is supplied, the output file name is
                     $(hostname)_<vg-name>_info
                If -u is supplied, the output file name is
                     $(hostname)_unused_disks
                If none of the above applies, the output file name is
                     /$(hostname)_lvm_info

                In addition, if -d is supplied, the name has "by_hardware_path"
                appended to it.

      Miscellaneous:
           -q   Run quietly.  This is the default when the script is run from
                cron or in an environment with no associated tty.

           -s   Search the system's symbolic links to see if any raw space
                is being used for data.  NOTE:  This option may add significant
                time to the scan if many devices are involved.  The default is
                not to search symbolic links.

           -h   Displays this help using pg(1), then exits.

        If no options are specified, all visible disks are scanned, all disk
        information is written to the /tmp/$(hostname)_lvm_info, and the file
        is paged to stdout.
        
 RETURN VALUES
          0	 Successful completion.
         >0	 Error condition occurred.

EnD
} # show_help

function format_for_printing {
	IFS=""
	while read LINE; do
		if [ "$PR_OPTS" = "-l60" -a ${#LINE} -gt 177 ]; then
			LANDSCAPE_PAD=$(echo $LINE | cut -c97-)
			echo $LINE | cut -c-97
			echo $LANDSCAPE_PAD
		elif [ "$PR_OPTS" = "-l80" -a ${#LINE} -gt 134 ]; then
			PORTRAIT_PAD=$(echo $LINE | cut -c97-)
			echo $LINE | cut -c-97
			echo $PORTRAIT_PAD
		else
			echo $LINE
		fi
	done
	unset IFS
} # format_for_printing

function get_perms {
	NUMERIC_PERMS=0
	USER_PERMS=$(echo $1 | cut -c-3)
	GROUP_PERMS=$(echo $1 | cut -c4-6)
	OTHER_PERMS=$(echo $1 | cut -c7-)
	USER_NAME=$2; GROUP_NAME=$3

	TEMP_NUMERIC_PERMS=0
	ALPHA_USER_PERMS="u="
	
	case $USER_PERMS in
		"---") continue ;;
		"r--")
			TEMP_NUMERIC_PERMS=$(($TEMP_NUMERIC_PERMS+400))
			ALPHA_USER_PERMS="${ALPHA_USER_PERMS}r"
		;;
		"-w-")
			TEMP_NUMERIC_PERMS=$(($TEMP_NUMERIC_PERMS+200))
			ALPHA_USER_PERMS="${ALPHA_USER_PERMS}w"
		;;
		"--x")
			TEMP_NUMERIC_PERMS=$(($TEMP_NUMERIC_PERMS+100))
			ALPHA_USER_PERMS="${ALPHA_USER_PERMS}x"
		;;
		"--s")
			TEMP_NUMERIC_PERMS=$(($TEMP_NUMERIC_PERMS+4100))
			ALPHA_USER_PERMS="${ALPHA_USER_PERMS}xs"
		;;
		"--S")
			TEMP_NUMERIC_PERMS=$(($TEMP_NUMERIC_PERMS+4000))
			ALPHA_USER_PERMS="${ALPHA_USER_PERMS}xs"
		;;
		"rw-")
			TEMP_NUMERIC_PERMS=$(($TEMP_NUMERIC_PERMS+600))
			ALPHA_USER_PERMS="${ALPHA_USER_PERMS}rw"
		;;
		"-wx")
			TEMP_NUMERIC_PERMS=$(($TEMP_NUMERIC_PERMS+300))
			ALPHA_USER_PERMS="${ALPHA_USER_PERMS}wx"
		;;
		"-ws")
			TEMP_NUMERIC_PERMS=$(($TEMP_NUMERIC_PERMS+4300))
			ALPHA_USER_PERMS="${ALPHA_USER_PERMS}wxs"
		;;
		"-wS")
			TEMP_NUMERIC_PERMS=$(($TEMP_NUMERIC_PERMS+4200))
			ALPHA_USER_PERMS="${ALPHA_USER_PERMS}wxs"
		;;
		"r-x")
			TEMP_NUMERIC_PERMS=$(($TEMP_NUMERIC_PERMS+500))
			ALPHA_USER_PERMS="${ALPHA_USER_PERMS}rx"
		;;
		"r-s")
			TEMP_NUMERIC_PERMS=$(($TEMP_NUMERIC_PERMS+4500))
			ALPHA_USER_PERMS="${ALPHA_USER_PERMS}rxs"
		;;
		"r-S")
			TEMP_NUMERIC_PERMS=$(($TEMP_NUMERIC_PERMS+4400))
			ALPHA_USER_PERMS="${ALPHA_USER_PERMS}rxs"
		;;
		"rwx")
			TEMP_NUMERIC_PERMS=$(($TEMP_NUMERIC_PERMS+700))
			ALPHA_USER_PERMS="${ALPHA_USER_PERMS}rwx"
		;;
		"rws")
			TEMP_NUMERIC_PERMS=$(($TEMP_NUMERIC_PERMS+4700))
			ALPHA_USER_PERMS="${ALPHA_USER_PERMS}rwxs"
		;;
		"rwS")
			TEMP_NUMERIC_PERMS=$(($TEMP_NUMERIC_PERMS+4600))
			ALPHA_USER_PERMS="${ALPHA_USER_PERMS}rwxs"
		;;
	esac
	
	NUMERIC_PERMS=$(($NUMERIC_PERMS+$TEMP_NUMERIC_PERMS))

	TEMP_NUMERIC_PERMS=0
	ALPHA_GROUP_PERMS="g="

case $GROUP_PERMS in
"---")
     continue
     ;;
"r--")
     TEMP_NUMERIC_PERMS=$(($TEMP_NUMERIC_PERMS+40))
     ALPHA_GROUP_PERMS="${ALPHA_GROUP_PERMS}r"
     ;;
"-w-")
     TEMP_NUMERIC_PERMS=$(($TEMP_NUMERIC_PERMS+20))
     ALPHA_GROUP_PERMS="${ALPHA_GROUP_PERMS}w"
     ;;
"--x")
     TEMP_NUMERIC_PERMS=$(($TEMP_NUMERIC_PERMS+10))
     ALPHA_GROUP_PERMS="${ALPHA_GROUP_PERMS}x"
     ;;
"--s")
     TEMP_NUMERIC_PERMS=$(($TEMP_NUMERIC_PERMS+2010))
     ALPHA_GROUP_PERMS="${ALPHA_GROUP_PERMS}xs"
     ;;
"--l")
     TEMP_NUMERIC_PERMS=$(($TEMP_NUMERIC_PERMS+2000))
     ALPHA_GROUP_PERMS="${ALPHA_GROUP_PERMS}l"
     ;;
"rw-")
     TEMP_NUMERIC_PERMS=$(($TEMP_NUMERIC_PERMS+60))
     ALPHA_GROUP_PERMS="${ALPHA_GROUP_PERMS}rw"
     ;;
"-wx")
     TEMP_NUMERIC_PERMS=$(($TEMP_NUMERIC_PERMS+30))
     ALPHA_GROUP_PERMS="${ALPHA_GROUP_PERMS}wx"
     ;;
"-ws")
     TEMP_NUMERIC_PERMS=$(($TEMP_NUMERIC_PERMS+2030))
     ALPHA_GROUP_PERMS="${ALPHA_GROUP_PERMS}wxs"
     ;;
"-wl")
     TEMP_NUMERIC_PERMS=$(($TEMP_NUMERIC_PERMS+2020))
     ALPHA_GROUP_PERMS="${ALPHA_GROUP_PERMS}wl"
     ;;
"r-x")
     TEMP_NUMERIC_PERMS=$(($TEMP_NUMERIC_PERMS+50))
     ALPHA_GROUP_PERMS="${ALPHA_GROUP_PERMS}rx"
     ;;
"r-s")
     TEMP_NUMERIC_PERMS=$(($TEMP_NUMERIC_PERMS+2050))
     ALPHA_GROUP_PERMS="${ALPHA_GROUP_PERMS}rxs"
     ;;
"r-l")
     TEMP_NUMERIC_PERMS=$(($TEMP_NUMERIC_PERMS+2040))
     ALPHA_GROUP_PERMS="${ALPHA_GROUP_PERMS}rl"
     ;;
"rwx")
     TEMP_NUMERIC_PERMS=$(($TEMP_NUMERIC_PERMS+70))
     ALPHA_GROUP_PERMS="${ALPHA_GROUP_PERMS}rwx"
     ;;
"rws")
     TEMP_NUMERIC_PERMS=$(($TEMP_NUMERIC_PERMS+2070))
     ALPHA_GROUP_PERMS="${ALPHA_GROUP_PERMS}rwxs"
     ;;
"rwl")
     TEMP_NUMERIC_PERMS=$(($TEMP_NUMERIC_PERMS+2060))
     ALPHA_GROUP_PERMS="${ALPHA_GROUP_PERMS}rwl"
     ;;
esac
NUMERIC_PERMS=$(($NUMERIC_PERMS+$TEMP_NUMERIC_PERMS))

TEMP_NUMERIC_PERMS=0
ALPHA_OTHER_PERMS="o="
case $OTHER_PERMS in
"---")
     continue
     ;;
"r--")
     TEMP_NUMERIC_PERMS=$(($TEMP_NUMERIC_PERMS+4))
     ALPHA_OTHER_PERMS="${ALPHA_OTHER_PERMS}r"
     ;;
"-w-")
     TEMP_NUMERIC_PERMS=$(($TEMP_NUMERIC_PERMS+2))
     ALPHA_OTHER_PERMS="${ALPHA_OTHER_PERMS}w"
     ;;
"--x")
     TEMP_NUMERIC_PERMS=$(($TEMP_NUMERIC_PERMS+1))
     ALPHA_OTHER_PERMS="${ALPHA_OTHER_PERMS}x"
     ;;
"--t")
     TEMP_NUMERIC_PERMS=$(($TEMP_NUMERIC_PERMS+1001))
     ALPHA_OTHER_PERMS="${ALPHA_OTHER_PERMS}x"
     ALPHA_USER_PERMS="${ALPHA_USER_PERMS}t"
     ;;
"--T")
     TEMP_NUMERIC_PERMS=$(($TEMP_NUMERIC_PERMS+1000))
     ALPHA_USER_PERMS="${ALPHA_USER_PERMS}t"
     ;;
"rw-")
     TEMP_NUMERIC_PERMS=$(($TEMP_NUMERIC_PERMS+6))
     ALPHA_OTHER_PERMS="${ALPHA_OTHER_PERMS}rw"
     ;;
"-wx")
     TEMP_NUMERIC_PERMS=$(($TEMP_NUMERIC_PERMS+3))
     ALPHA_OTHER_PERMS="${ALPHA_OTHER_PERMS}wx"
     ;;
"-wt")
     TEMP_NUMERIC_PERMS=$(($TEMP_NUMERIC_PERMS+1003))
     ALPHA_OTHER_PERMS="${ALPHA_OTHER_PERMS}wx"
     ALPHA_USER_PERMS="${ALPHA_USER_PERMS}t"
     ;;
"-wT")
     TEMP_NUMERIC_PERMS=$(($TEMP_NUMERIC_PERMS+1002))
     ALPHA_OTHER_PERMS="${ALPHA_OTHER_PERMS}w"
     ALPHA_USER_PERMS="${ALPHA_USER_PERMS}t"
     ;;
"r-x")
     TEMP_NUMERIC_PERMS=$(($TEMP_NUMERIC_PERMS+5))
     ALPHA_OTHER_PERMS="${ALPHA_OTHER_PERMS}rx"
     ;;
"r-t")
     TEMP_NUMERIC_PERMS=$(($TEMP_NUMERIC_PERMS+1005))
     ALPHA_OTHER_PERMS="${ALPHA_OTHER_PERMS}rx"
     ALPHA_USER_PERMS="${ALPHA_USER_PERMS}t"
     ;;
"r-T")
     TEMP_NUMERIC_PERMS=$(($TEMP_NUMERIC_PERMS+1004))
     ALPHA_OTHER_PERMS="${ALPHA_OTHER_PERMS}r"
     ALPHA_USER_PERMS="${ALPHA_USER_PERMS}t"
     ;;
"rwx")
     TEMP_NUMERIC_PERMS=$(($TEMP_NUMERIC_PERMS+7))
     ALPHA_OTHER_PERMS="${ALPHA_OTHER_PERMS}rwx"
     ;;
"rwt")
     TEMP_NUMERIC_PERMS=$(($TEMP_NUMERIC_PERMS+1007))
     ALPHA_OTHER_PERMS="${ALPHA_OTHER_PERMS}rwx"
     ALPHA_USER_PERMS="${ALPHA_USER_PERMS}t"
     ;;
"rwT")
     TEMP_NUMERIC_PERMS=$(($TEMP_NUMERIC_PERMS+1006))
     ALPHA_OTHER_PERMS="${ALPHA_OTHER_PERMS}rw"
     ALPHA_USER_PERMS="${ALPHA_USER_PERMS}t"
     ;;
esac

NUMERIC_PERMS=$(($NUMERIC_PERMS+$TEMP_NUMERIC_PERMS))
ALPHA_PERMS=$ALPHA_USER_PERMS,$ALPHA_GROUP_PERMS,$ALPHA_OTHER_PERMS
echo "$USER_NAME:$GROUP_NAME:$NUMERIC_PERMS"
} # get_perms

function check_for_mirrors {
	while read EXTENTS; do
		set $EXTENTS
	
		if [ $# -gt 1 ]; then
			if [ "$PV_LINK" = "" ]; then
				if [ "${2##*/}" = "${DEVFILE##*/}" -o "${3##*/}" = "${DEVFILE##*/}" ]; then
					return 1
				else
					return 0
				fi
			else
				if [ "${2##*/}" = "$PV_LINK" -o "${3##*/}" = "$PV_LINK" ]; then
					return 1
				else
					return 0
				fi
			fi
		fi    
	done
} # check_for_mirrors

function get_lv_info {
	while read LVINFO; do
		set $LVINFO
		LV="$VG/${1##*/}"
		LV_STRIP=$(echo $LV | tr -d ' ')
     
		lvdisplay -v /dev/$LV_STRIP >$LVDISPLAY_OUTPUT 2>&1
		
		if [ "$PV_LINK" = "" ]; then
			sed -e '1,/^.*LE  *PV1/d' $LVDISPLAY_OUTPUT | \
			grep $DEVFILE | awk '{print $2,$5,$8}' | head -1 | check_for_mirrors
		else
			sed -e '1,/^.*LE  *PV1/d' $LVDISPLAY_OUTPUT | \
			grep /dev/dsk/$PV_LINK | awk '{print $2,$5,$8}' | head -1 | check_for_mirrors
		fi
		
		[ $? -eq 1 ] && LV_MIRROR=1 || LV_MIRROR=0

		LV_STRIPE=$(awk '/^Stripes/ {print $2}' $LVDISPLAY_OUTPUT)
		USE="$3"
		MBUSE=$(($USE*$PE))
		LVMINFO="$LV   $SEP_CHAR${MBUSE} MB"
		SYSUSE=$(grep "^#*.*/dev/$LV_STRIP[[:space:]]" /etc/fstab | sed -e 's/^#* *//' | awk '{print $2,$3}')
		
		if [ -z "$SYSUSE" ]; then
			SYSUSE=$(mount -p | grep "^/dev/$LV_STRIP[[:space:]]" | awk '{print $2,$3}')
		fi
		
		if echo $SYSUSE | grep -q swap; then
			#
			# Logical volume is used for secondary swap
			#

			if swapinfo | grep -q "/dev/${LV_STRIP}$"; then
				DETAIL=swap
			else
	 			DETAIL="swap (UNUSED)"
			fi

			if [ $LV_MIRROR = 1 ]; then
				if [ "$PV_LINK" = "" ]; then
					if [ $LV_STRIPE != 0 ]; then
						if echo $DETAIL | grep -q UNUSED; then
							DETAIL="swap (UNUSED, MIRROR, STRIPE)"
						else
							DETAIL="swap (MIRROR, STRIPE)"
						fi
					elif echo $DETAIL | grep -q UNUSED; then
						DETAIL="swap (UNUSED, MIRROR)"
					else
						DETAIL="swap (MIRROR)"
					fi
				elif [ $LV_STRIPE != 0 ]; then
					if echo $DETAIL | grep -q UNUSED ; then
						DETAIL="swap (UNUSED, MIRROR, STRIPE, ALT PATH TO $PV_LINK)"
					else
						DETAIL="swap (MIRROR, STRIPE, ALT PATH TO $PV_LINK)"
					fi
				elif echo $DETAIL | grep -q UNUSED; then
					DETAIL="swap (UNUSED, MIRROR, ALT PATH TO $PV_LINK)"
				else
					DETAIL="swap (MIRROR, ALT PATH TO $PV_LINK)"
				fi
			else
				if [ "$PV_LINK" = "" ]; then
					if [ $LV_STRIPE != 0 ]; then
						if echo $DETAIL | grep -q UNUSED; then
							DETAIL="swap (UNUSED, STRIPE)"
						else
							DETAIL="swap (STRIPE)"
						fi
					elif echo $DETAIL | grep -q UNUSED; then
						DETAIL="swap (UNUSED)"
					else
						DETAIL="swap"
					fi
				elif [ $LV_STRIPE != 0 ]; then
					if echo $DETAIL | grep -q UNUSED; then
						DETAIL="swap (UNUSED, STRIPE, ALT PATH TO $PV_LINK)"
					else
						DETAIL="swap (STRIPE, ALT PATH TO $PV_LINK)"
					fi
				elif echo $DETAIL | grep -q UNUSED; then
					DETAIL="swap (UNUSED, ALT PATH TO $PV_LINK)"
				else
					DETAIL="swap (ALT PATH TO $PV_LINK)"
				fi
			fi
          
			echo "$LVMINFO$SEP_CHAR$DISKINFO$SEP_CHAR$DETAIL"

		elif [ -z "$SYSUSE" ]; then
		
			#
			# Logical volume is not used for filesystem
			#

			SYSUSE=$(grep "/dev/$VG/r${1##*/}$" $LINKS_LIST | cut -f1 -d" ")
		
			if [ -z "$SYSUSE" ]; then
				#
				# Logical volume is used for primary swap
				#
               
				LVMINFO="$LV   $SEP_CHAR${MBUSE} MB"
			
				if swapinfo | grep -q "/dev/${LV_STRIP}$"; then
					SYSUSE=swap
				else
					ll /dev/$VG/r${1##*/} | awk '{if ($3 == "oracle" && $4 == "dba") {exit 0} else {exit 1}}'
				
					if [ $? = 0 ]; then
						SYSUSE="ORACLE DBSPACE OR LOG"
					else
						SYSUSE="(UNASSIGNED)"
					fi
				fi
			else
		
				#
				# Logical volume is used for raw I/O (e.g., Informix RDBMS space)
				#
               
				LVMINFO="$LV   $SEP_CHAR${MBUSE} MB"
				SYSUSE="$SYSUSE (RAW LINK)"
			fi
		
			if [ $LV_MIRROR = 1 ]; then
				if [ "$(echo $SYSUSE | cut -c${#SYSUSE})" = ")" ]; then
					if [ "$PV_LINK" != "" ]; then
						if [ $LV_STRIPE != 0 ]; then
							DETAIL="$(echo $SYSUSE | cut -c-$((${#SYSUSE}-1))), MIRROR, STRIPE, ALT PATH TO $PV_LINK)"
						else
							DETAIL="$(echo $SYSUSE | cut -c-$((${#SYSUSE}-1))), MIRROR, ALT PATH TO $PV_LINK)"
						fi
					elif [ $LV_STRIPE != 0 ]; then
						DETAIL="$(echo $SYSUSE | cut -c-$((${#SYSUSE}-1))), MIRROR, STRIPE)"
					else
						DETAIL="$(echo $SYSUSE | cut -c-$((${#SYSUSE}-1))), MIRROR)"
					fi
				elif [ "$PV_LINK" != "" ]; then
					if [ $LV_STRIPE != 0 ]; then
						DETAIL="$SYSUSE (MIRROR, STRIPE, ALT PATH TO $PV_LINK)"
					else
						DETAIL="$SYSUSE (MIRROR, ALT PATH TO $PV_LINK)"
					fi
				elif [ $LV_STRIPE != 0 ]; then
					DETAIL="$SYSUSE (MIRROR, STRIPE)"
				else
					DETAIL="$SYSUSE (MIRROR)"
				fi
			elif [ "$(echo $SYSUSE | cut -c${#SYSUSE})" = ")" ]; then
				if [ "$PV_LINK" != "" ]; then
					if [ $LV_STRIPE != 0 ]; then
						DETAIL="$(echo $SYSUSE | cut -c-$((${#SYSUSE}-1))), STRIPE, ALT PATH TO $PV_LINK)"
					else
						DETAIL="$(echo $SYSUSE | cut -c-$((${#SYSUSE}-1))), ALT PATH TO $PV_LINK)"
					fi
				elif [ $LV_STRIPE != 0 ]; then
					DETAIL="$(echo $SYSUSE | cut -c-$((${#SYSUSE}-1))), STRIPE)"
				else
					DETAIL=$SYSUSE
				fi
			elif [ "$PV_LINK" != "" ]; then
				if [ $LV_STRIPE != 0 ]; then
					DETAIL="$SYSUSE (STRIPE, ALT PATH TO $PV_LINK)"
				else
					DETAIL="$SYSUSE (ALT PATH TO $PV_LINK)"
				fi
			elif [ $LV_STRIPE != 0 ]; then
				DETAIL="$SYSUSE (STRIPE)"
			else
				DETAIL=$SYSUSE
			fi
		
			echo "$LVMINFO$SEP_CHAR$DISKINFO$SEP_CHAR$DETAIL"
		else

			#
			# Logical volume is used for filesystem
			#
			
			FS_INFO=$(fstyp -v /dev/$VG/r${1##*/} 2>/dev/null | head -2 | paste -s -d" " - | sed -e 's/://')
			FS_TYPE=$(echo "$FS_INFO" | cut -f1 -d" ")
          
			if [ "$FS_TYPE" = "vxfs" ]; then
				LARGE_FILES=$(fsadm -F "$FS_TYPE" $(echo $SYSUSE | awk '/largefiles/ {print $1}') 2>/dev/null)
			elif [ "$FS_TYPE" = "hfs" ]; then
				LARGE_FILES=$(fsadm -F $FS_TYPE /dev/$VG/r${1##*/} | tail -1 | awk -F: '{print $2}' | sed -e 's/^ //')
			fi
			
			if [ $LV_MIRROR = 1 ]; then
				if [ "$PV_LINK" != "" ]; then
					if [ $LV_STRIPE != 0 ]; then
						SYSUSE="$(echo $SYSUSE | cut -f1 -d' ') (MIRROR, STRIPE, ALT PATH TO $PV_LINK)"
					else
						SYSUSE="$(echo $SYSUSE | cut -f1 -d' ') (MIRROR, ALT PATH TO $PV_LINK)"
					fi
				elif [ $LV_STRIPE != 0 ];then
					SYSUSE="$(echo $SYSUSE | cut -f1 -d' ') (MIRROR, STRIPE)"
				else
					SYSUSE="$(echo $SYSUSE | cut -f1 -d' ') (MIRROR)"
				fi
			elif [ "$PV_LINK" != "" ]; then
				if [ $LV_STRIPE != 0 ]; then
					SYSUSE="$(echo $SYSUSE | cut -f1 -d' ') (STRIPE, ALT PATH TO $PV_LINK)"
				else
					SYSUSE="$(echo $SYSUSE | cut -f1 -d' ') (ALT PATH TO $PV_LINK)"
				fi
			elif [ $LV_STRIPE != 0 ]; then
				SYSUSE="$(echo $SYSUSE | cut -f1 -d' '), (STRIPE)"
			else
				SYSUSE=$(echo $SYSUSE | cut -f1 -d' ')
			fi
			
			mount | grep -q "^$(echo $SYSUSE | cut -f1 -d" ") on /dev/$LV_STRIP"
			
			if [ $? = 1 ]; then
				mount | grep -q "^$(echo $SYSUSE | cut -f1 -d" ") on /export$(echo $SYSUSE | cut -f1 -d" ")"
				
				if [ $? = 1 ]; then
					if [ "$(echo $SYSUSE | cut -c${#SYSUSE})" = ")" ]; then
						DETAIL="$(echo $SYSUSE | cut -c-$((${#SYSUSE}-1))), UNMOUNTED)"
					else
						DETAIL="$SYSUSE (UNMOUNTED)"
					fi
				elif [ "$(echo $SYSUSE | cut -c${#SYSUSE})" = ")" ]; then
					DETAIL=$SYSUSE
				else
					DETAIL="$SYSUSE ($(bdf $SYSUSE | tail -1 | awk '{print $(NF-1)}'))"
				fi
			elif [ "$(echo $SYSUSE | cut -c${#SYSUSE})" = ")" ]; then
				DETAIL=$SYSUSE
			elif [ "$FS_TYPE" = "vxfs" ]; then
				DETAIL="$SYSUSE, $(get_perms $(ll -d $SYSUSE | awk '{print substr($1,2),$3,$4}')), $FS_INFO, $LARGE_FILES ($(bdf $SYSUSE | tail -1 | awk '{print $(NF-1)}'))"
			else
				DETAIL="$SYSUSE, $(get_perms $(ll -d $SYSUSE | awk '{print substr($1,2),$3,$4}')), $FS_TYPE, $LARGE_FILES ($(bdf $SYSUSE | tail -1 | awk '{print $(NF-1)}'))"
			fi
			
			echo "$LVMINFO$SEP_CHAR$DISKINFO$SEP_CHAR$DETAIL"
		fi
	done
} # get_lv_info

function get_pv_info {
while read LINE; do
     set $LINE
     if [ "$g_opt" = "1" ]; then
          HW=$(grep /dev/dsk/${1}$ $LSSF_OUTPUT | awk '{print $1}')
          if [ "$HW" = "" ]; then
               LV="Missing block device file"
               SZ=" "
               LVMINFO="$LV$SEP_CHAR$SZ$SEP_CHAR  "
               ID=" "; HW=" "
               DEVBASE="??????"
               DISKINFO="    $HW$SEP_CHAR$DEVBASE$SEP_CHAR$ID"
               echo "$LVMINFO$SEP_CHAR$DISKINFO"
               continue
          else
               diskinfo /dev/rdsk/$1 >$DISKINFO_OUTPUT 2>&1
               DEVFILE="/dev/dsk/$1"
          fi
     else
          HW=$1
          DEVFILE=$(grep "^${1} " $LSSF_OUTPUT | awk '{print $2}' | head -3 | tail -1)
          if [ "$DEVFILE" = "" ]; then
               LV="Missing block device file"
               SZ=" "
               LVMINFO="$LV$SEP_CHAR$SZ$SEP_CHAR  "
               ID=" "
               DEVBASE="??????"
               DISKINFO="    $HW$SEP_CHAR$DEVBASE$SEP_CHAR$ID"
               echo "$LVMINFO$SEP_CHAR$DISKINFO"
               continue
          else
               diskinfo /dev/rdsk/$(basename $DEVFILE) >$DISKINFO_OUTPUT 2>&1
	  fi
     fi
     if grep "No such file" $DISKINFO_OUTPUT >/dev/null 2>&1; then
     #
     #  Device file is missing
     #
          if [ "$g_opt$f_opt" = "" ]; then
               LV="Missing character device file"
               SZ=" "
               LVMINFO="$LV$SEP_CHAR$SZ$SEP_CHAR  "
               ID=" "
               DEVBASE="??????"
               DISKINFO="    $HW$SEP_CHAR$DEVBASE$SEP_CHAR$ID"
               echo "$LVMINFO$SEP_CHAR$DISKINFO"
               continue
          fi
     elif grep -E "No such device|Invalid argument|can't open" $DISKINFO_OUTPUT >/dev/null 2>&1; then
     #
     #  Disk has been removed 
     #
          if [ "$g_opt$f_opt" = "" ]; then
               DEVBASE=$(basename $DEVFILE)
               LV="Missing/inaccessible disk"
               SZ=" "
               LVMINFO="$LV$SEP_CHAR$SZ$SEP_CHAR  "
               ID=" "
               DISKINFO="    $HW$SEP_CHAR$DEVBASE$SEP_CHAR$ID"
               echo "$LVMINFO$SEP_CHAR$DISKINFO"
          fi
     else
          ID=$(grep "^.*product id:" $DISKINFO_OUTPUT | awk '{print $NF}')
          DEVBASE=$(basename $DEVFILE)
          if [ $q_opt = 0 ]; then
	       echo "Checking disk at path $(echo $HW | tr -d ' ') ($(echo $DEVBASE | tr -d ' '))... \c" >/dev/tty
          fi
          pvdisplay -v $DEVFILE 2>&1| sed '/Physical extents/,$d' >$PVDISPLAY_OUTPUT
          DISKINFO="    $HW$SEP_CHAR$DEVBASE$SEP_CHAR$ID"
          if grep "find the volume group" $PVDISPLAY_OUTPUT >/dev/null; then
	  #
	  # Disk is present, but is not part of any volume group
	  #
               if [ "$g_opt$f_opt$i_opt" = "" -o "$u_opt" = "1" ]; then
                    SZ=$(grep "^.*size:" $DISKINFO_OUTPUT | awk '{print $2}')
                    LV="Non-LVM disk"
                    LVMINFO="$LV$SEP_CHAR$SZ KB"
                    if [ $ID = SYMMETRIX -a \( $SZ = 2880 -o $SZ = 4800 -o $SZ = 5760 -o $SZ = 6720 -o $SZ = 7680 -o $SZ = 9600 -o $SZ = 240000 \) ]; then
         	         DETAIL="SERVICE DIRECTOR (NOT A DISK DEVICE)"
                         if [ $q_opt = 0 ]; then
	                      echo "Done." >/dev/tty
                         fi
                         continue
                    elif [ \( $ID = DISK-SUBSYSTEM -o $(echo $ID | cut -c-5) = OPEN- \) -a $SZ = 0 ]; then
 		         DETAIL="XP CONTROLLER (NOT A DISK DEVICE)"
                         if [ $q_opt = 0 ]; then
	                      echo "Done." >/dev/tty
                         fi
                         continue
                    else
                         DETAIL=" "
                         echo "$LVMINFO$SEP_CHAR$DISKINFO$SEP_CHAR$DETAIL"
                    fi
               fi
          elif grep "query physical volume \"/dev/dsk/$(basename $DEVFILE)\"" $PVDISPLAY_OUTPUT >/dev/null; then
               VG=$(grep "belonging to volume group" $PVDISPLAY_OUTPUT 2>/dev/null | awk -F/ '{print substr($NF,1,index($NF,"\"")-1)}')
               if vgdisplay $VG 2>&1 | grep "Volume group not activated" >/dev/null 2>&1; then
          #
	  # Disk is present, but is part of a deactivated volume group
	  #
                    if [ "$g_opt$f_opt$u_opt" = "" -o "$i_opt" = 1 ]; then
                          VG=$(grep "belonging to volume group" $PVDISPLAY_OUTPUT 2>/dev/null | awk -F/ '{print substr($NF,1,index($NF,"\"")-1)}')
                          SZ=$(grep "^.*size:" $DISKINFO_OUTPUT | awk '{print $2}')
                          LV="Inactive VG $VG"
                          LVMINFO="$LV$SEP_CHAR$SZ KB"
                          echo "$LVMINFO$SEP_CHAR$DISKINFO"
                    fi
               elif grep "Cannot display physical volume \"/dev/dsk/$(basename $DEVFILE)\"" $PVDISPLAY_OUTPUT >/dev/null; then
          #
	  # Disk has apparently been powererd off or disconnected
	  #
                    if [ "$g_opt$f_opt" = "" ]; then
                         DEVBASE=$(basename $DEVFILE)
                         LV="Missing/inaccessible disk"
                         SZ=" "
                         LVMINFO="$LV$SEP_CHAR$SZ$SEP_CHAR  "
                         ID=" "
                         DISKINFO="    $HW$SEP_CHAR$DEVBASE$SEP_CHAR$ID"
                         echo "$LVMINFO$SEP_CHAR$DISKINFO"
                    fi
               fi
          elif [ "$i_opt" = "" ]; then
  	  #
	  # Disk is present and is part of an activated volume group
	  #
               VG=$(basename $(grep "^VG Name" $PVDISPLAY_OUTPUT | awk '{print $3}'))
               PE=$(basename $(grep "^PE Size" $PVDISPLAY_OUTPUT | awk '{print $4}'))
               TOTAL_PE=$(basename $(grep "^Total PE" $PVDISPLAY_OUTPUT | awk '{print $3}'))
               
               if [ "$u_opt" = "" -o "$f_opt" = "1" ]; then
                    grep "^Device file path" $PVDISPLAY_OUTPUT >/dev/null
                    if [ $? = 0 ]; then
                         PV_LINK=$(basename $(grep "^to the Physical Volume." $PVDISPLAY_OUTPUT | awk '{print substr($NF,2,length($NF)-3)}'))
                    else
                         PV_LINK=""
                    fi
               fi
               if [ "$f_opt$u_opt" = "" -a \( "$g_opt$VG" = "1$(basename $VOL_GROUP)" -o "$g_opt" = "" \) ]; then
                    sed '1,/^   LV Name/d' $PVDISPLAY_OUTPUT | grep -v "^$" | get_lv_info
	       fi
               if [ "$u_opt" = "" -o "$f_opt" = "1" ]; then
                    LV="$VG/FREE"
                    FRE=$(basename $(grep "^Free PE" $PVDISPLAY_OUTPUT | awk '{print $3}'))
		    MBUSE=$(($FRE*$PE))
                    PV_CAPACITY=$(($TOTAL_PE*$PE))
                    LVMINFO="$LV   $SEP_CHAR${MBUSE} MB"
                    if [ -z "$PV_LINK" ]; then
                         echo "$LVMINFO$SEP_CHAR$DISKINFO (PHYSICAL/LOGICAL CAPACITY : $(($(grep "^.*size:" $DISKINFO_OUTPUT | awk '{print $2}')\/1024))/$PV_CAPACITY)"
                    else
                         echo "$LVMINFO$SEP_CHAR$DISKINFO (ALT PATH TO $PV_LINK)"
                    fi
               fi
          fi
	  echo $DEVFILE >>$IOSCAN_OUTPUT
          if [ $q_opt = 0 ]; then
	       echo "Done." >/dev/tty
          fi
     fi
done

sort -o $IOSCAN_OUTPUT $IOSCAN_OUTPUT
if [ "$g_opt" = "" ]; then
     for DEVFILE in $(grep "^???" $LSSF_OUTPUT | awk '{print $2}'); do
          LV="Missing/inaccessible disk"
          SZ=" "; HW="???"
          LVMINFO="$LV$SEP_CHAR$SZ$SEP_CHAR  "
          ID=" "
          DEVBASE=$(basename $DEVFILE)
          DISKINFO="    $HW$SEP_CHAR$DEVBASE$SEP_CHAR$ID"
          echo "$LVMINFO$SEP_CHAR$DISKINFO"
     done
     for HW_PATH in $(cut -f2 -d" " $LSSF_OUTPUT | comm -13 - $IOSCAN_OUTPUT); do
          LV="Missing device file(s)"
          SZ=" "; HW="$HW_PATH"
          LVMINFO="$LV$SEP_CHAR$SZ$SEP_CHAR  "
          ID=" "
          DEVBASE="??????"
          DISKINFO="    $HW$SEP_CHAR$DEVBASE$SEP_CHAR$ID"
          echo "$LVMINFO$SEP_CHAR$DISKINFO"
     done
fi
} # get_pv_info

LINKS_LIST=/tmp/$(basename $0)_links_$$
AWK_PROGRAM=/tmp/$(basename $0).awk_$$
LSSF_OUTPUT=/tmp/$(basename $0)_lssf_output_$$
VGDISPLAY_OUTPUT=/tmp/$(basename $0)_vgdisplay_output_$$
LVDISPLAY_OUTPUT=/tmp/$(basename $0)_lvdisplay_output_$$
PVDISPLAY_OUTPUT=/tmp/$(basename $0)_pvdisplay_output_$$
IOSCAN_OUTPUT=/tmp/$(basename $0)_ioscan_output_$$
DISKINFO_OUTPUT=/tmp/$(basename $0)_diskinfo_output_$$

trap "rm -f /tmp/$(basename $0)*_$$; echo \"\nAborted.\"; exit" 1 2 3 9 15
trap "rm -f /tmp/$(basename $0)*_$$" 0

USAGE="Usage: $(basename $0)  [-d] [-h] [-g vol_group_name] [-u] [-f] [-q] [-s]\n[ -i] [[[-p printer-id | -l printer-id] -x] | -v | -n] [-D output_directory]"
USAGE="$(basename $0) [-d] [-h] [-g vol_group_name] [-u] [-f] [-q] [-s] [-i]\n[[[-p printer-id | -l printer-id] -x [v | h]] | -v | -n | -m destination]\n[-D output_directory] [-t]"

PATH=$PATH:/usr/sbin:/sbin:$(cat /etc/PATH)

OUTPUT_DIR=/tmp; D_opt=""
OUTPUT_FILE=$(hostname)_lvm_info
PR_LP_TITLE="LVM information for host $(hostname)"

p_opt=" "; g_opt=""; PRINTER_ID=""; VOL_GROUP=""; d_opt=" "
u_opt=""; f_opt=""; n_opt=" "; h_opt=""; s_opt=0; x_opt=" "; LP_COMMAND="lp"
i_opt=""; m_opt=" "; t_opt=""; SEP_CHAR=" "
SORT_ARGS="-k1.1,1.30 -k1.49,1.73"  # First key is VG/LV; second is HW path

tty -s
q_opt=$?

while getopts g:p:l:duifm:nkhD:qsx:t OPTION; do
     case $OPTION in
     p|l) if [ "$PRINTER_ID" != "" -o "$n_opt" != " " -o "$h_opt" != "" -o "$m_opt" != " " ]; then
               echo $USAGE
               exit 1
          else
               p_opt=1
               if [ $(echo $OPTARG | cut -c1) = "-" ]; then
                    echo $USAGE
                    exit 1
               else
                    PRINTER_ID=$OPTARG
                    if [ $OPTION = p ]; then
                         LP_OPTS=""
                         PR_OPTS="-l80"
                    else
                         LP_OPTS="-olandscape"
                         PR_OPTS="-l60"
                    fi
               fi
          fi
          ;;
     d)   if [ "$d_opt" != " " -o "$h_opt" != "" ]; then
               echo $USAGE
               exit 1
          else
               d_opt=1
               SORT_ARGS=$(echo $SORT_ARGS | awk '{print $2,$1}')
          fi
          ;;
     g)   if [ "$VOL_GROUP" != "" -o "$u_opt" != "" -o "$h_opt" != "" -o "$i_opt" != "" ]; then
               echo $USAGE
               exit
          else
               g_opt=1
               VOL_GROUP=$OPTARG
               OUTPUT_FILE=$(hostname)_${VOL_GROUP}_info
               PR_LP_TITLE="Information for VG $VOL_GROUP on host $(hostname)"
          fi
          ;;
     f)   if [ "$f_opt" != "" -o "$h_opt" != "" ]; then
               echo $USAGE
               exit
          else
               f_opt=1
               OUTPUT_FILE=$(hostname)_free_VG_space
               PR_LP_TITLE="VG free space on host $(hostname)"
          fi
          ;;
     u)   if [ "$VOL_GROUP" != "" -o "$u_opt" != "" -o "$h_opt" != "" ]; then
               echo $USAGE
               exit
          else
               u_opt=1
               OUTPUT_FILE=$(hostname)_unused_disks
               PR_LP_TITLE="Unused disks on host $(hostname)"
          fi
          ;;
     i)   if [ "$VOL_GROUP" != "" -o "$i_opt" != "" -o "$h_opt" != "" ]; then
               echo $USAGE
               exit
          else
               i_opt=1
               OUTPUT_FILE=$(hostname)_inactive_VGS
               PR_LP_TITLE="Inactive VGs on host $(hostname)"
          fi
          ;;
     D)   if [ "$D_opt" != "" ]; then
               echo $USAGE
               exit
          else
               D_opt=1
               OUTPUT_DIR=$OPTARG 
               if [ $? != 0 ]; then
                    exit
               fi
          fi
          ;;
     h)   if [ "$h_opt" != "" ]; then
               echo $USAGE
               exit
          else
               h_opt=1
               show_help 
               exit
          fi
          ;;
     q)   q_opt=1
          LP_COMMAND="lp -s"
          ;;
     s)   if [ $s_opt = 1 ]; then
               echo $USAGE
               exit 1
          else
               s_opt=1
          fi
          ;;
     n)   if [ "$p_opt" != " " -o "$m_opt" != " " ]; then
               echo $USAGE
               exit 1
          else
               n_opt=1
          fi
          ;;
     x)   if [ "$x_opt" != " " ]; then
               echo $USAGE
               exit 1
          else
               x_opt=$OPTARG
               if [ "$x_opt" != "v" -a "$x_opt" != "h" ]; then
                    echo $USAGE
                    exit 1
               fi
          fi
          ;;
     m)   if [ "$p_opt" != " " -o "$n_opt" != " " -o "$h_opt" != "" ]; then
               echo $USAGE
               exit 1
          else
               m_opt=1
               MAIL_DESTINATION=$OPTARG
          fi
          ;;
     t)   if [ "$t_opt" != "" ]; then
               echo $USAGE
               exit 1
          else
               t_opt=1
               SEP_CHAR="\t"
          fi
          ;;
     ?)   echo $USAGE
          exit
          ;;
     esac
done

if [ "$x_opt" != " " ]; then
     if [ "$p_opt" != "1" ]; then
          echo $USAGE
          exit
     elif [ "$x_opt" = "v" ]; then
          LP_OPTS="$LP_OPTS -ovd"
     elif [ "$x_opt" = "h" ]; then
          LP_OPTS="$LP_OPTS -ohd"
     fi
fi

if [ "$g_opt$f_opt" = "11" ]; then
     OUTPUT_FILE=$(hostname)_${VOL_GROUP}_free_space
     PR_LP_TITLE="Free space in VG $VOL_GROUP on $(hostname)"
elif [ "$u_opt$f_opt" = "11" ]; then
     OUTPUT_FILE=$(hostname)_unused_disks_and_free_space
     PR_LP_TITLE="Unused disks and free space on $(hostname)"
fi

if [ "$d_opt" = "1" ]; then
     OUTPUT_FILE=${OUTPUT_FILE}_by_hardware_path
     PR_LP_TITLE="${PR_LP_TITLE} sorted by hardware path"
fi

OUTPUT_PATH=$OUTPUT_DIR/$OUTPUT_FILE
touch $OUTPUT_PATH

if [ "$p_opt" = "1" ]; then
     if [ $PRINTER_ID != default ]; then 
          lpstat -p$PRINTER_ID 2>&1 | grep "non-existent$"
          if [ $? = 0 ]; then
               exit 1
          elif  [ $q_opt = 0 ]; then
               echo "Output will be saved to $OUTPUT_PATH, then printed on $PRINTER_ID." >/dev/tty
          fi
     else
          if [ $q_opt = 0 ]; then
               echo "No printer specified."
          fi
          if [ "$PRINTQUEUE" != "" ]; then
               PRINTER_ID=$PRINTQUEUE
               if [ $q_opt = 0 ]; then
                    echo "Output will be saved to $OUTPUT_PATH, then printed on $PRINTER_ID (value of PRINTQUEUE)." >/dev/tty
               fi
               lpstat -p$PRINTER_ID 2>&1 | grep "non-existent$"
               if [ $? = 0 ]; then
                   exit 1
               fi
          elif [ "$LPDEST" != "" ]; then
               PRINTER_ID=$LPDEST
               if [ $q_opt = 0 ]; then
                    echo "Output will be saved to $OUTPUT_PATH, then printed on $PRINTER_ID (value of LPDEST)." >/dev/tty
               fi
               lpstat -p$PRINTER_ID 2>&1 | grep "non-existent$"
               if [ $? = 0 ]; then
                   exit 1
               fi
          elif [ "$PRINTER" != "" ]; then
               PRINTER_ID=$PRINTER
               if [ $q_opt = 0 ]; then
                    echo "Output will be saved to $OUTPUT_PATH, then printed on $PRINTER_ID (value of PRINTER)." >/dev/tty
               fi
               lpstat -p$PRINTER_ID 2>&1 | grep "non-existent$"
               if [ $? = 0 ]; then
                   exit 1
               fi
          elif lpstat -d | grep "^system " >/dev/null; then
               PRINTER_ID=$(lpstat -d | awk '{print $NF}')
               if [ $q_opt = 0 ]; then
                    echo "Output will be saved to $OUTPUT_PATH, then printed on $PRINTER_ID (system default printer)." >/dev/tty
               fi
               lpstat -p$PRINTER_ID 2>&1 | grep "non-existent$"
               if [ $? = 0 ]; then
                    exit 1
               fi
          elif  [ $q_opt = 0 ]; then
               echo "No default printer identified, no system default printer, and no printer specified -\c"
               echo "output will be saved to $OUTPUT_PATH, then be piped to \"pg\"."
          fi
     fi
elif [ "$n_opt" = "1" ]; then
     if [ $q_opt = 0 ]; then
          echo "Output will be saved to $OUTPUT_PATH."
     fi
elif [ "$m_opt" = "1" ]; then
     if [ $q_opt = 0 ]; then
          echo "Output will be saved to $OUTPUT_PATH, then mailed to $MAIL_DESTINATION."
     fi
elif [ $q_opt = 0 ]; then
     echo "Output will be saved to $OUTPUT_PATH, then piped to \"pg\"."
fi

if [ "$d_opt" = " " ]; then
     cat >$AWK_PROGRAM <<-XxX
BEGIN {previous_entry = " "; vg_total = 0}
{slash_position = index(\$1,"/");
 if (slash_position == 0)
      current_entry = \$1
 else
      current_entry = substr(\$1,1,slash_position);
 if (previous_entry != current_entry && NR != 1) 
      printf("\n",\$0);
 printf("%s\n",\$0);
 previous_entry = current_entry}
XxX
else
     cat >$AWK_PROGRAM <<-XxX
BEGIN {previous_entry = " "}
{current_entry = \$5;
 if (previous_entry != current_entry && NR != 1)
      printf("\n",\$0);
 printf("%s\n",\$0);
 previous_entry = current_entry}
XxX
fi

case "$p_opt$n_opt$m_opt" in  # determine sorting order based on cmdline option
"   ")
     OUTPUT_FILTER="sed -e 's/^Non-LVM /Non-LVM_/' -e 's/^Inactive /Inactive_/' | sort $SORT_ARGS | awk -f $AWK_PROGRAM | sed -e 's/^Non-LVM_/Non-LVM /' -e 's/^Inactive_/Inactive /' >$OUTPUT_PATH; pg -p\"$(basename $0) report, page %d:\" -c $OUTPUT_PATH"
     ;;
"1  ")
     OUTPUT_FILTER="sed -e 's/^Non-LVM /Non-LVM_/' -e 's/^Inactive /Inactive_/' | sort $SORT_ARGS | awk -f $AWK_PROGRAM | sed -e 's/^Non-LVM_/Non-LVM /' -e 's/^Inactive_/Inactive /' >$OUTPUT_PATH; cat $OUTPUT_PATH | format_for_printing | pr $PR_OPTS -h\"$PR_LP_TITLE\" | $LP_COMMAND -d$PRINTER_ID -oyb -t\"$PR_LP_TITLE\" -oc -olpi8 $LP_OPTS"
     ;;
" 1 ")
     OUTPUT_FILTER="sed -e 's/^Non-LVM /Non-LVM_/' -e 's/^Inactive /Inactive_/' | sort $SORT_ARGS | awk -f $AWK_PROGRAM | sed -e 's/^Non-LVM_/Non-LVM /' -e 's/^Inactive_/Inactive /' >$OUTPUT_PATH"
     ;;
"  1")
     OUTPUT_FILTER="sed -e 's/^Non-LVM /Non-LVM_/' -e 's/^Inactive /Inactive_/' | sort $SORT_ARGS | awk -f $AWK_PROGRAM | sed -e 's/^Non-LVM_/Non-LVM /' -e 's/^Inactive_/Inactive /' >$OUTPUT_PATH; cat $OUTPUT_PATH | mailx -s \"$PR_LP_TITLE\" $MAIL_DESTINATION"
     ;;
?)   echo USAGE
     exit
     ;;
esac

# Width specifiers to make the output align properly
#
#	LVMINFO = LV + MBUSE + 3 = 39
#	DISKINFO = HW + DEVBASE + ID + 6 = 56
#	display = LVMINFO + DISKINFO + DETAIL
#
# DETAIL cannot exceed 84 if landscape printing is requested, 41 otherwise.


typeset -L30 LV
typeset -L15 ID
typeset -L25 HW
typeset -R9  SZ
typeset -R5  FRE
typeset -R6  MBUSE
typeset -L10 DEVBASE
typeset -R134 PORTRAIT_PAD
typeset -R177 LANDSCAPE_PAD
		 
if [ $s_opt = 1 ]; then
     if [ $q_opt = 0 ]; then
          echo "Searching the system for symbolic links... \c" >/dev/tty
     fi
     find / -type l \( -fsonly hfs -o -fsonly vxfs \) ! -path '/sbin/rc?.d/*' -exec ll {} \; |
          grep /dev | sed 's/ * / /g' | cut -f9,11 -d' ' \
          >$LINKS_LIST
     if [ $q_opt = 0 ]; then
          echo "Done." >/dev/tty
     fi
else
     > $LINKS_LIST
fi

if [ $q_opt = 0 ]; then
     echo "\nPass 1:  Searching the system for existing device files... \c" >/dev/tty
fi
    
find /dev/dsk -type b -exec lssf {} \; | awk '{print $15,$16}' | sort -k2,2 >$LSSF_OUTPUT

if [ $q_opt = 0 ]; then
	echo "Done." >/dev/tty
fi

if [ "$g_opt" != "" ]; then
	if [ $q_opt = 0 ]; then
		echo "\nSearching for disk devices belonging to volume group $VOL_GROUP...\n" >/dev/tty
	fi
     
	vgdisplay -v $VOL_GROUP >$VGDISPLAY_OUTPUT 2>&1
	 
	if grep -q "does not exist in the \"/etc/lvmtab\" file" $VGDISPLAY_OUTPUT; then
		echo "Volume group $VOL_GROUP not found." 
		exit 1
	elif grep -q "Volume group not activated" $VGDISPLAY_OUTPUT; then
		echo "Volume group $VOL_GROUP not activated." 
		exit 1
	else
		INPUT_FILTER="sed '1,/--- Physical volumes ---/d' $VGDISPLAY_OUTPUT | sed '/--- Physical volume groups ---/,\$d' | grep \"PV Name\" | awk '{print \$3}' | cut -f4 -d'/'"
	fi
else
	if [ $q_opt = 0 ]; then
		echo "\nPass 2:  Searching the system for accessible disk devices...\n" >/dev/tty
	fi
	
	INPUT_FILTER="ioscan -FkC disk | awk -F: '{print \$11}'"
fi

COMMAND="$INPUT_FILTER | get_pv_info | $OUTPUT_FILTER"
eval $COMMAND

exit 0

# ----------------------------------------------------------------------------
# $Log: lvminf.sh,v $
# Revision 1.4  2006/03/12 08:14:26  bmynars
# Removed blank line
#
# Revision 1.3  2006/03/12 08:12:30  bmynars
# Added blank line
#
# Revision 1.2  2006/03/09 04:38:51  bmynars
# Updated and reformatted
#
# $RCSfile: lvminf.sh,v $
# $Source: /ncs/cvsroot/ncsbin/utils/lvminf.sh,v $
# $State: Stab $
# ----------------------------------------------------------------------------
