#!/usr/bin/sh
# Author: Peter Mertens <pmertens@its.jnj.com>
#
# $Revision: 1.9 $
# $Date: 2013/11/13 10:17:23 $
# $Header: /ncs/cvsroot/ncsbin/utils/CollectDiskServiceTime.sh,v 1.9 2013/11/13 10:17:23 gdhaese1 Exp $
# $Id: CollectDiskServiceTime.sh,v 1.9 2013/11/13 10:17:23 gdhaese1 Exp $
# $Locker:  $
# History: Check the bottom of the file for revision history
# ----------------------------------------------------------------------------
# Purpose:
#   Collect disk performance data (BYDSK_AVG_SERVICE_TIME and BYDSK_UTIL).
#   All data from yesterday will be collected and will be grouped by
#   hour.  For each group the n busiest disks will be selected and the average
#   and maximum service-time for these disks will be calculated.
#   The collected data will be stored in:
#              $NFS_DIR/BusiestDisksServiceTimes/YYYYMM.txt
#   This file will will be stored on a NAS-share.
#
# History File Layout ----------------------------------------------------------
##Date(YYYY/MM/DD-HH:MM) AvgDskSvcTime   MaxDskSvcTime   AvgDskUtil      MaxDskUtil      Count
#2011/02/01-00:00        5.65    20.00   0.00    12.81   88
#2011/02/01-01:00        6.62    20.00   0.00    16.99   81
#2011/02/01-02:00        6.85    26.66   0.00    19.75   93
#2011/02/01-03:00        7.51    30.00   0.00    12.84   104
#2011/02/01-04:00        6.60    20.00   0.00    10.61   102
# ...
# yyyy/mm/dd-HH:MM 9999.99 9999.99 999.99 999.99 9999
#
# Temporary Files --------------------------------------------------------------
# TMP1:
# Record layout (the extract command used further on will not include the headings)
# 
# OVPA Export 05/17/10 12:08    Logfile: /var/opt/perf/datafiles/logglob SCOPE/UX C.04.70.000(0) visdbp10
# Seconds  |       Device Name or                   |Dsk Avg|      |
#Since 1970|        mwa DISK-ID                     |SvcTime|Disk %|
#1291403400|0/0/6/1/0.25.45.0.0.14.4                |  14.28|  0.03|
#1291403400|0/0/2/1/0.25.10.0.0.9.1                 |   1.22|  0.04|
#
# TMP2:
# Record layout
# %d\t%.2f\t%.2f\t%.2f\t%.2f\t%d\n
# dateseconds disk avg-svc-time max-svc-time avg-disk-busy-util max-disk-busy-util no-of-records-during-interval

#set -x

typeset -x PRGNAME=${0##*/}
typeset -x PRGNAME=${PRGNAME%.sh}
typeset -x PRGDIR=${0%/*}

[[ $PRGDIR = /* ]] || PRGDIR=$(pwd) # Acquire absolute path to the script

typeset    HOST=$(uname -n)

typeset -r NFS_SHR="ncsusnasmid01.na.jnj.com:/vol/its/its_performlogs"  # name of nfs-share
typeset -r NFS_MNT=/var/mnt/${PRGNAME}                                  # name of mountpoint
typeset -r NFS_DIR=${NFS_MNT}/history/BusiestDisksServiceTimes/$HOST    # directory with input files

typeset    TMPDIR=/var/tmp
typeset    TMPREPORT=$TMPDIR/$PRGNAME-rep-$$.tmp # used for extracting the measureware data
typeset    TMP1=$TMPDIR/$PRGNAME-1-$$.tmp # used to store the extracted mwa data
typeset    TMP2=$TMPDIR/$PRGNAME-2-$$.tmp # used to store the aggregated data
typeset    TMPBUSIEST=$TMPDIR/$PRGNAME-busiest-$$.tmp
typeset    TMPHISTFILE1=$TMPDIR/$PRGNAME-hist-$$.tmp

typeset    LOGDEV="/var/opt/perf/datafiles/logdev"
typeset -i SHOW=10
typeset    RESTORED="FALSE"
typeset    BEGIN="LAST-1"
typeset    END="LAST-1"
typeset -i GROUP=3600 # number of seconds to group by
typeset    FORCE="FALSE"

typeset    perl=$(which perl)
[ -x "$perl" ] || perl=$(whereis -b perl | awk '{ print $2}') # use second field - gives less exotic perl versions

# this perl-script converts a date-time into seconds from 1/1/1970
alias -x ConvertToEpoch="${perl} -e 'use Time::Local;
 (\$mm, \$dd, \$yyyy) = split(/\//, \$ARGV[0]);
 (\$hh, \$mi, \$ss  ) = split(/:/,  \$ARGV[1]);
 printf \"%d\n\", timegm(\$ss,\$mi,\$hh,\$dd,\$mm-1,\$yyyy)'"

# this perl-script converts a date-time from seconds to ascii
alias -x ConvertFromEpoch="${perl} -e '
(\$ss,\$mi,\$hh,\$dd,\$mm,\$yyyy,\$wday,\$yday,\$isdst) = gmtime(\$ARGV[0]);
printf\"%4d/%02d/%02d-%02d:%02d\n\", \$yyyy+1900,\$mm+1,\$dd,\$hh,\$mi;'"

# ------------------------------------------------------------------------------
function Usage {
cat - <<EOT
usage: $0 [-b date] [-e date] [-n number] [-f] [-l logdev] [-T tmpdir] 
       where: -b = set starting date for extract    (DEFAULT=LAST-7)
	      -e = set ending   date for extract    (DEFAULT=LAST-0)
              -f = force startup of script without checking for space in $TMPDIR
	      -l = Location of alternative logdev file.
                   The DEFAULT value is: /var/opt/perf/datafiles/logdev.
                   If this option is used, the script will use BYDSK_ID instead
		   of BYDSK_DEVNAME.  When restoring datafiles, make sure to 
		   restore all datafiles in one directory.
              -n = number of TopDisks to list       (DEFAULT=10)
              -T = Location of temporary files.  This includes the temporary 
                   files used by sort.              (DEFAULT=/var/tmp)

example: $0 -l /tmp/datafiles/logdev -T /var/adm/crash
         creates the report based on a restored logdev file, using /var/adm/crash
         for temporary files.
Purpose:
   Collect disk performance data (BYDSK_AVG_SERVICE_TIME and BYDSK_UTIL).
   All data from yesterday will be collected and will be grouped by
   hour.  For each group the n busiest disks will be selected and the average
   and maximum service-time for these disks will be calculated.

IMPORTANT NOTE: this script will create quite some temporary files.  It's
       checking the available space in /var/tmp (or the location specified by
       -T).  There needs to be at least 50 MB free space.  This should be 
       enough for 1 day of data.  If you would be selecting more days, then
       this may or may not be enough.  Use -b or -e option to limit the 
       amount of data returned.  Or you may need to specify an alternative 
       location (-T) for the temporary files.
EOT
exit
}

# ------------------------------------------------------------------------------
function Cleanup {
	rm -f $TMPREPORT
	rm -f $TMP1
	rm -f $TMP2
        rm -f $TMPBUSIEST
        rm -f $TMPHISTFILE1
        /usr/sbin/mount | awk '{print $1}' | grep "^${NFS_MNT}$" && /usr/sbin/umount ${NFS_MNT}
        return
}

# ------------------------------------------------------------------------------
function CleanExit {
	echo "INFO: Last step executed: $2"
	echo "INFO: Last return code: $1"
	Cleanup
        exit
}

# ------------------------------------------------------------------------------
function CheckRC {
	[ $1 -ne 0 ] && CleanExit $1 "$2"
	return
}

# ------------------------------------------------------------------------------
function CheckDiskSpace {
	# Check how much space is available in TMPDIR for keeping the extracted data
	# and for sorting the reports
	# The minimum space available should be at least 50 MB
	typeset -i AVAIL=0
	typeset -i NEEDED=51200 

	AVAIL=$(df -k $TMPDIR| awk '/ free allocated Kb$/ {print $1}')
	if [ $AVAIL -le $NEEDED ]
	then
        	echo "ERROR: Data collection not started because of insufficient space in $TMPDIR."
        	echo "ERROR: $AVAIL MB available while $NEEDED MB is needed."
        	exit
	fi

	return
}

# ------------------------------------------------------------------------------
function GroupOnTmp2 {
	# this function starts runs an awk script on $TMP2, sorted on keys passed as arg1

sort -T $TMPDIR $1 $TMP2 |awk -v Show=$SHOW '
BEGIN {
 prev_date=-1;
 count=0;
 sum=0;
 maxsvc=0; 
 maxbus=0;
 totsvc=0; 
 totbus=0;
 }
{
date=$1
if (prev_date == -1) { prev_date=date } # first time 

if (prev_date != date) {
        if (count < Show) {n = count} else {n = Show }; # make sure to use right count for computing average
        printf "%d\t%.2f\t%.2f\t%.2f\t%.2f\t%d\n", prev_date, totsvc/n, maxsvc, totbus/n, maxbus, sum;
        prev_date=date;
        count=0;
	sum=0;
	maxsvc=0; 
	maxbus=0;
	totsvc=0; 
	totbus=0;
        }
++count;
if (count <= Show) {
	totsvc+=$3;
	if ($4 > maxsvc) maxsvc=$4; 
	totbus+=$5;
	if ($6 > maxbus) maxbus=$6; 
	sum+=$7;
	}
}
END {
if (count < Show) {n = count} else {n = Show }; # make sure to use right count for computing average
printf "%d\t%.2f\t%.2f\t%.2f\t%.2f\t%d\n", prev_date, totsvc/n, maxsvc, totbus/n, maxbus, sum;
}' |
while read dateseconds rest
do
	echo "$(ConvertFromEpoch $dateseconds)\t$rest"
done

return
}

# ------------------------------------------------------------------------------
function NFSMount {
        if [ ! -d ${NFS_MNT} ]
        then
                mkdir -p -m 755 ${NFS_MNT} && echo "INFO: Directory ${NFS_MNT} created." || {
                        CleanExit $? "mkdir -p -m 755 ${NFS_MNT} (FAILED WITH ERROR)"
                        }
	fi

	# check if filesystem is already mounted
	mounted_share=$(/usr/sbin/mount | awk -v dir=${NFS_MNT} '($1 == dir) {print $3}')
	if [ -z "${mounted_share}" ]
	then # nothing mounted
		/usr/sbin/mount -o soft ${NFS_SHR} ${NFS_MNT} && echo "INFO: Mount ${NFS_SHR} on ${NFS_MNT}" || {
			CleanExit $? "mount -o soft ${NFS_SHR} ${NFS_MNT}"
			}
	elif [ "${mounted_share}" != "${NFS_SHR}" ]
	then
		echo "ERROR: wrong share ($mounted_share) is mounted on ${NFS_MNT}. Stop script."
		CleanExit 1 "Checking if filesysstem is already mounted."
	else
		echo "WARNING: $NFS_SHARE already mounted on ${NFS_MNT}. Script will continue."
	fi

        if [ ! -d ${NFS_DIR} ]
        then
                mkdir -p -m 755 ${NFS_DIR} && echo "INFO: Directory ${NFS_DIR} created." || {
			CleanExit $? "mkdir -p -m 755 ${NFS_DIR} (2) (FAILED WITH ERROR)"
                        }
	fi

	return
	}

# ------------------------------------------------------------------------------
function NFSuMount {
        /usr/sbin/umount ${NFS_MNT} && echo "INFO: Unmount ${NFS_MNT}" || {
                rc=$?
                echo "ERROR: umount ${NFS_MNT} failed. Possibly other instance of this script is running."
                CleanExit $rc "umount ${NFS_MNT}"
                }
        return
}

# ------------------------------------------------------------------------------
#
# MAIN Program
#

# Argument Handling ------------------------------------------------------------

while getopts b:e:fl:n:T: name
do
        case $name in
	b) BEGIN="$OPTARG"   ;;
	e) END="$OPTARG"     ;;
	f) FORCE="TRUE"      ;;
        l) LOGDEV="$OPTARG" 
	   RESTORED="TRUE"   ;;
	n) SHOW="$OPTARG"    ;;
        T) TMPDIR="$OPTARG"  ;;
        ?) Usage             ;;
        esac
done
shift $(($OPTIND -1)) # in case you would want to use the remaining parameters
if [[ -n $1 ]] # check for extra parameters
then echo "ERROR: '$1' not allowed"
     Usage     # no extra parameters allowed
fi

{ # start logging (from here all output will be captured so cron doesn't catch it)

# List variables to stdout -----------------------------------------------------

cat - <<EOT
Used configuration--------------------------------------------------------------
                     Hostname: $HOST
        Startdate for extract: $BEGIN
          Enddate for extract: $END
   Number of TopDisks to list: $SHOW
Number of seconds to group by: $GROUP
      Measureware logdev file: $LOGDEV
                Restored file? $RESTORED
  Force (Disable Space Check)? $FORCE
                  Perl binary: $perl
Directory for temporary files: $TMPDIR
              Temporary files: $TMPREPORT
                               $TMP1
                               $TMP2
                               $TMPBUSIEST
                               $TMPHISTFILE1
                    NFS-share: $NFS_SHR
              NFS-mount-point: $NFS_MNT
EOT

# Additional validation --------------------------------------------------------

[[ ! -r $LOGDEV ]] && { echo "ERROR: logdev ($LOGDEV) is not readable.  Please check."; exit; }

[[ ! -d $TMPDIR ]] && { echo "ERROR: $TMPDIR is not a valid directory.  Please check."; exit; }

[[ $FORCE = "FALSE" ]] && CheckDiskSpace  # abort script if insufficient space in $TMPDIR 

# Sleep for a random time ------------------------------------------------------
#    to prevent the NFS mounts from all systems starting at the same time

sleep=$(( ($RANDOM % 60) * 5 )) # random generated number of seconds. (max 5 minutes)
echo "Going to sleep for $sleep seconds"
sleep $sleep

# ------------------------------------------------------------------------------
echo "Step 1: Extract the data - $(date)"
# ------------------------------------------------------------------------------

if [[ $RESTORED = "TRUE" ]]
then cat - > $TMPREPORT <<-EOT
	FORMAT ASCII
	HEADINGS OFF
	SEPARATOR="|"
	MISSING=0
	DATA TYPE DISK
	DATE_SECONDS
	BYDSK_ID
	BYDSK_AVG_SERVICE_TIME
	BYDSK_UTIL
	EOT
else cat - > $TMPREPORT <<-EOT
	FORMAT ASCII
	HEADINGS OFF
	SEPARATOR="|"
	MISSING=0
	DATA TYPE DISK
	DATE_SECONDS
	BYDSK_DEVNAME
	BYDSK_AVG_SERVICE_TIME
	BYDSK_UTIL
	EOT
fi

echo "INFO: $(date) - Starting extract of Measureware data"
echo "INFO:                                       (may take a few minutes)"
/opt/perf/bin/extract -xp -d -b $BEGIN -e $END -r $TMPREPORT -f $TMP1 -l $LOGDEV
CheckRC $? extract

if [[ ! -s $TMP1 ]]
then echo "ERROR: Could not extract mwa disk data.  File $TMP1 is empty."
     Cleanup
     exit
fi

rm $TMPREPORT

# ------------------------------------------------------------------------------
echo "Step 2: Aggregate the data per $GROUP seconds - $(date)"
# ------------------------------------------------------------------------------

sort -T $TMPDIR -t\| -k2,2 -k1,1 $TMP1 |
 awk -v Group=$GROUP -F\|  '
BEGIN {
 prev_date=-1;
 prev_disk="";
 count=0;
 maxsvc=0; 
 maxbus=0;
 totsvc=0; 
 totbus=0;
 }
$3 ~ " 0.00$" && $4 ~ " 0.00$" {continue} # skip rows that only contain zeroes
{
date=int($1/Group)*Group;
disk=$2

if (prev_date == -1) {
	# first time
	prev_date=date
	prev_disk=disk
	}

if (prev_date != date || prev_disk != disk) {
	printf "%d %s %7.2f %7.2f %6.2f %6.2f %d\n", prev_date, prev_disk, totsvc/count, maxsvc, totbus/count, maxbus, count;
	prev_date=date
	prev_disk=disk
	count=0;
	maxsvc=0; 
	maxbus=0;
	totsvc=0; 
	totbus=0;
	}

count+=1;
totsvc+=$3;
if ($3 > maxsvc) maxsvc=$3; 
totbus+=$5;
if ($4 > maxbus) maxbus=$4; 
}
END {
printf "%d %s %7.2f %7.2f %6.2f %6.2f %d\n", prev_date, prev_disk, totsvc/count, maxsvc, totbus/count, maxbus, count;
}' > $TMP2
CheckRC $? "sort $TMP1 and group per hour"

rm $TMP1

# ------------------------------------------------------------------------------
echo  "step 3: Now sort each group on DISK-UTIL and compute average/maximum for"
echo  "        the $SHOW BUSIEST DISKS per group - $(date)"
# ------------------------------------------------------------------------------

GroupOnTmp2 "-k1,1 -k5,5rn" > $TMPBUSIEST
CheckRC $? "Consolidate Busy Disks (summary) using $TMP2"

# ------------------------------------------------------------------------------
echo "step 4: Add extracted data to the history file - $(date)"
# ------------------------------------------------------------------------------

NFSMount

# process the data month per month
for month in $(cut -d/ -f1,2 $TMPBUSIEST | sort -u) 
do
    yyyymm=$(echo $month | tr -d "/") 
    HISTFILE=${NFS_DIR}/${yyyymm}.txt
    if [ ! -f $HISTFILE ]
    then echo "INFO: starting new month in $HISTFILE"
         { echo "#Date(YYYY/MM/DD-HH:MM)\tAvgDskSvcTime\tMaxDskSvcTime\tAvgDskUtil\tMaxDskUtil\tCount"
	   grep "^$month" $TMPBUSIEST
	   } | ux2dos > $HISTFILE
         CheckRC $? "grep ^$month $TMPBUSIEST | ux2dos > $HISTFILE"
    else echo "INFO: merge records from $TMPBUSIEST into $HISTFILE while skipping duplicates..."
         echo "INFO: (duplicates may come from overlapping input files)"

         { dos2ux $HISTFILE; CheckRC $? "dos2ux $HISTFILE"
           cat $TMPBUSIEST
           } | sort | awk -v select="^$month" '
	        BEGIN {
                      prevdate="";
                      prevcount=0;
                      }
	        ( $1 ~ select ) {
                date=$1;
                count=$6;
	        if (prevdate == "") { # first record
                    prevrec=$0; 
                    prevdate=date;
                    prevcount=count;
                    continue;
                    }
	        if (prevdate != date) { # record with new timestamp --> print previous one
                    print prevrec;
                    prevrec=$0; 
                    prevdate=date;
                    prevcount=count;
                    continue;
                    }
                if (count > prevcount) { # duplicate timestamp --> keep the record with the highest count
                    prevrec=$0;
                    prevcount=count;
                    continue;
                    }
                }
                END {
                    if (prevdate != "") {
                        print prevrec;
                        }
                    }' > $TMPHISTFILE1
         CheckRC $? "merge  $HISTFILE with $TMPBUSIEST into $TMPHISTFILE1 ..."
         { echo "#Date(YYYY/MM/DD-HH:MM)\tAvgDskSvcTime\tMaxDskSvcTime\tAvgDskUtil\tMaxDskUtil\tCount"
           cat $TMPHISTFILE1
	  } | ux2dos > $HISTFILE
        CheckRC $? "ux2dos $TMPHISTFILE1 > $HISTFILE"
    fi
done

NFSuMount

Cleanup
} 

exit

# ----------------------------------------------------------------------------
# $Log: CollectDiskServiceTime.sh,v $
# Revision 1.9  2013/11/13 10:17:23  gdhaese1
# chnage NFS share mount point again into the original name
#
# Revision 1.8  2013/09/03 09:38:35  gdhaese1
# Change the NAS volume name to new location
#
# Revision 1.7  2013/04/11 08:01:56  gdhaese1
# update NAS filer name in CollectDiskServiceTime.sh
#
# Revision 1.6  2011/10/24 14:29:50  pmertens
# use the second field in the 'whereis -b perl' output in stead of the last field.
# The second field often gives a more standard version of perl...
#
# Revision 1.5  2011/10/06 08:38:45  pmertens
# Changed the temporary mountpoint from /var/tmp/mnt to /var/mnt.
# Reason: on many systems cleanup jobs or cascading down /var/tmp/ to cleanup
# files older than 15 days.
#
# Revision 1.4  2011/02/21 14:06:52  pmertens
# removed the logfile - now writing to stdout
#
# Revision 1.3  2011/02/16 07:15:22  pmertens
# removed some unused variables
#
# Revision 1.2  2011/02/14 17:36:38  pmertens
# 1) split the PRGNAME construction (strip start and end of name) over two lines (to be compliant with ksh)
# 2) put the logfile on /var/adm/log in stead of /var/tmp
# 3) put the history files directly on NAS and eliminate the local copy
# 4) store the history files in dos-txt for improved readability on windows
#
# Revision 1.1  2011/02/14 13:35:10  pmertens
# Collect average service times for busy disks and store on NAS.  Initial version.
#
#
# $RCSfile: CollectDiskServiceTime.sh,v $
# $Source: /ncs/cvsroot/ncsbin/utils/CollectDiskServiceTime.sh,v $
# $State: Exp $
# ----------------------------------------------------------------------------
