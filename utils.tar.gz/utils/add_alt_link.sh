#!/usr/bin/ksh
# Author: Mahi Singh <MSingh24@ITS.JNJ.COM>
#
# $Revision: 1.1 $
# $Date: 2013/02/19 08:20:37 $
# $Header: /ncs/cvsroot/ncsbin/utils/add_alt_link.sh,v 1.1 2013/02/19 08:20:37 gdhaese1 Exp $
# $Id: add_alt_link.sh,v 1.1 2013/02/19 08:20:37 gdhaese1 Exp $
# $Locker:  $
# History: Check the bottom of the file for revision history
# ----------------------------------------------------------------------------

typeset -x PRGNAME=${0##*/}
typeset -x PRGDIR=${0%/*}
typeset -x PATH=$PATH:/usr/local/CPR/bin
typeset -x LOG=/var/adm/log/VG-alt-disk-addition-${VGNAME}-`date +%d%m%y`.log
typeset -r osver=`uname -r`
typeset -x VGNAME=""
typeset -x xpinfo=$(which xpinfo)

[[ $PRGDIR = /* ]] || PRGDIR=$(pwd) # Acquire absolute path to the script


# FUNCTIONS
###########
function add_disk {
PLINKS=/tmp/plinks.$$
$xpinfo -i > /tmp/XPI
ALTLINKS=/tmp/altlinks.$$
for VG in ${VGNAME}
do
           vgdisplay -v $VG|grep "PV Name"|grep -v Alt|awk '{print $3}'|sed 's/dsk/rdsk/'> $PLINKS

           for i in `cat $PLINKS`
           do
                grep -w $i /tmp/XPI | awk '{print $1 " "$6 " "$8}'|while read rdev culd xpframe
           do
                grep -w $culd /tmp/XPI |grep -v $i |grep -w $xpframe |awk '{print $1}'|sed 's/rdsk/dsk/' >> $ALTLINKS
           done
           done

           for pv in `cat $ALTLINKS`
                do
                        vgextend $VG $pv 1>>${LOG} 2>&1
                done

                echo > $ALTLINKS

           done

           rm $PLINKS $ALTLINKS
}



# ------------------------------------------------------------------------------
#                                   MAIN BODY
# ------------------------------------------------------------------------------

if [ $(whoami) != 'root' ]; then
        echo ".... Only <root> can run the script $PRGNAME\n\n"
        exit 1
fi

VGNAME=$1
if [[ -z "$VGNAME" ]]; then
	echo "ERROR: expecting as argument Volume Group name"
	exit 1
fi
if [[ ! -d $VGNAME ]]; then
	echo "ERROR: Volume group $VGNAME not found."
	exit 1
fi

# This script is no longer required on B.11.3*.
case $osver in
        B.11.3*)
              echo "WARNING: script $PRGNAME is deprecated on $osver.  Please, do not use it."
              exit 1
              ;;

             *)
             echo "........Creating alternate links ............."
             add_disk $VGNAME | tee -a ${LOG}
              ;;

esac

# ----------------------------------------------------------------------------
# $Log: add_alt_link.sh,v $
# Revision 1.1  2013/02/19 08:20:37  gdhaese1
# New script to add alternative links on HP-UX 11.11/11.23 based systems.
# Script was written by Mahi Singh.
#
#
# $RCSfile: add_alt_link.sh,v $
# $Source: /ncs/cvsroot/ncsbin/utils/add_alt_link.sh,v $
# $State: Exp $
# ----------------------------------------------------------------------------
