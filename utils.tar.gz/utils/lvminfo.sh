#!/bin/sh
#
# $Revision: 1.1.1.1 $
# $Date: 2005/10/05 12:32:26 $
# $Header: /ncs/cvsroot/ncsbin/utils/lvminfo.sh,v 1.1.1.1 2005/10/05 12:32:26 bmynars Stab $ 
# $Id: lvminfo.sh,v 1.1.1.1 2005/10/05 12:32:26 bmynars Stab $
# $Locker:  $
# History: Check the bottom of the file for revision history
# ----------------------------------------------------------------------------

#--------------------------------------------------------------------
# Purpose: display logical volume / disk layout information
#  Author: Greg Vaidman / Pete Conrad, Melillo Consulting
# Fixed: Boleslaw Mynarski/Rich Helmke (original version wasn't
#        handling fiber channel or disk size larger than
#        x size in Gb
#--------------------------------------------------------------------

case $(whoami) in
	root) : ;; # OK
	*)
		print "You Must Be Root To Run This Script"
		exit 1
	;;
esac

disp_size () {
typeset SZ=$1
typeset -R5 INFO

	if (( SZ > 9999999 )); then
		SZ=$(( SZ / 1024 / 1024 ))
		INFO="${SZ}G"
	elif (( SZ > 9999 )); then
		SZ=$(( SZ / 1024 ))
		INFO="${SZ}M"
	else
		INFO="${SZ}K"
	fi

	print "$INFO"
}

function _info_10 {

# width specifiers to make the output align better
typeset -L25 LVMINFO
typeset -L16 LV
typeset -L35 DISKINFO
typeset -R12 HW
typeset -R3  LU
typeset -R9  SZ
typeset -R5  SUM USE FRE
typeset -R5  DISK
typeset -L8  CTLR
typeset -Z3  ID
typeset -L1  FLAG_ALNK F_MIRR

PATH="/usr/sbin:/sbin:/usr/bin:$PATH"

	ioscan -kfC disk | awk '/^disk/{print $2,$3,$8}' |&
	while read -p ID HW_PATH TYPE; do

		count=0

		# We do not care about the length of hardware
		# address.  The last two are the target and lun
				
		for element in $(echo $HW_PATH | tr '.' '\n'); do
			count=$(($count+1))
			HWPATH[$count]="$element"
		done

		EXT_BUS=''
		j=0
			
		while [ $j -lt $((${#HWPATH[@]}-2)) ]; do
			j=$(($j+1))
			EXT_BUS="${EXT_BUS}.${HWPATH[$j]}"
		done
			
		EXT_BUS=${EXT_BUS#.}
		lUN=${#HWPATH[@]}
		tGT=$((${#HWPATH[@]}-1))
		LUN=${HWPATH[$lUN]}
		TGT=${HWPATH[$tGT]}	

		unset HWPATH[@]

		BUS_ID=$( ioscan -kfH $EXT_BUS -C ext_bus |
			awk '/^ext_bus/{print $2}' )

		DEV=/dev/dsk/c${BUS_ID}t${TGT}d${LUN}
		RDEV=/dev/rdsk/c${BUS_ID}t${TGT}d${LUN}

		typeset -l tYPE
		tYPE=$TYPE
		
		case "$tYPE" in
			*rom*) continue ;;
		esac
		

		CTLR=$( basename $DEV )

		if pvdisplay -v ${DEV} 2>&1 | grep -q $DEV.*Alternate.L; then
			F_ALNK="a"
		else
			F_ALNK=" "
		fi
			
		typeset -L35 hW_PATH
			
		hW_PATH=$HW_PATH
		DISKINFO="${ID} $CTLR ${F_ALNK}${hW_PATH} $TYPE"

		PVD=$( pvdisplay -v ${DEV} 2>&1 |
			awk '/Physical extents/{exit}{print $0}' )
		if print -- "$PVD" | grep -q "find the volume group"; then
			# This clause is for NON LVM disks
			#echo "\$RDEV: $RDEV - \$SZ: $SZ" >> /var/tmp/disk_size.txt
				
			SZ=$( diskinfo $RDEV | awk '/size:/{print $2}' )
			INFO=$(disp_size $SZ)
			LVMINFO="NonLVM disk      - ${INFO}"

			print "${LVMINFO}${DISKINFO}"
			#print "${LVMINFO}${DISKINFO} ${DEV}"
		else
			# This clause is for LVM disks
				
			print -- "$PVD" | awk '
				/PE Size/	{ sz=$NF }
				/Total PE/	{ pe=$NF }
				/Free PE/	{ fr=$NF }
				/VG Name/	{ vg=$NF }
				END { print sz,pe,fr,vg }' |
			read PE TOT FRE VG
			VG=$( basename $VG )

			print -- "$PVD" | sed '1,/^   LV Name/d' |
			while read LVNAME tok USE; do
				lvdisplay -v $LVNAME | 
					awk '$1 ~ /0000|00000/ {
						print $2,$5,$8 
					}'| read M1DSK M2DSK M3DSK

				case $DEV in
					$M1DSK)	F_MIRR="p"	;;
					$M2DSK)	F_MIRR="m"	;;
					$M3DSK)	F_MIRR="M"	;;
					*)		F_MIRR="?"	;;
				esac

				lvdisplay -v $LVNAME | 
					grep -q "Mirror copies *0 *$" &&
					F_MIRR="-"
					LV="$VG/$(basename $LVNAME)"
				DISK=$(disp_size $((1024*USE*PE)))
				#echo "\$RDEV: $RDEV - \$SZ: $SZ - \$USE: $USE - \$PE: $PE - \$DISK: $DISK" >> /var/tmp/disk_info.txt

				LVMINFO="${LV} ${F_MIRR} ${DISK}"
				grep "^$LVNAME " /etc/mnttab |
					awk '{ print $2,$3 }' |
					read SYSUSE FSTYPE
					if [[ -z $SYSUSE ]]; then
						swapinfo |
						grep -q " $LVNAME$" && 
						SYSUSE="[swap]"
					fi

					[[ $SYSUSE = "[swap]" ]] ||
					case $FSTYPE in
						cdfs)	SYSUSE="C$SYSUSE";;
						hfs)	SYSUSE="H$SYSUSE";;
						vxfs)	SYSUSE="V$SYSUSE";;
						nfs)	SYSUSE="N$SYSUSE";;
						*)	SYSUSE="?$SYSUSE";;
					esac

				print "$LVMINFO$DISKINFO $SYSUSE"
			done
			
			if (( FRE > 0 )); then
				LV="$VG/UNUSED"
				DISK=$( disp_size $(( 1024*FRE*PE )) )
				LVMINFO="$LV - ${DISK}"
				print "$LVMINFO$DISKINFO"
			fi
		fi
	done
}

OS_TYPE=$(uname -s)
OS_REL=$(uname -r)

case ${OS_TYPE} in
	(HP-UX)
		case ${OS_REL} in
			B.1[01].*) _info_10 ;;
			(*)
				print "ERROR: invalid O/S version \"${OS_REL}\""
				exit 1
				;;
		esac
		;;
	(*)
		print "ERROR: invalid O/S type \"${OS_TYPE}\""
		exit 1
		;;
esac

# ----------------------------------------------------------------------------
# $Log: lvminfo.sh,v $
# Revision 1.1.1.1  2005/10/05 12:32:26  bmynars
# Import
#
# Revision 1.1  2004/05/13 02:00:55  bmynars
# Initial checking
#
#
# $RCSfile: lvminfo.sh,v $
# $Source: /ncs/cvsroot/ncsbin/utils/lvminfo.sh,v $
# $State: Stab $
# ----------------------------------------------------------------------------
