#!/usr/dt/bin/dtksh
# Author: Bolek Mynarski <bmynars@its.jnj.com> 
#
# $Revision: 1.19 $
# $Date: 2013/10/01 13:41:51 $
# $Header: /ncs/cvsroot/ncsbin/utils/sarCheck.sh,v 1.19 2013/10/01 13:41:51 gdhaese1 Exp $
# $Id: sarCheck.sh,v 1.19 2013/10/01 13:41:51 gdhaese1 Exp $
# $Locker:  $
# History: Check the bottom of the file for revision history
# ----------------------------------------------------------------------------
# This script is meant mostly for HP-UX, or SUN system (with adjustements).
# It could be potentially executed on Linux as long as KORN-93 shell is available.
# There are too many syntax  differences between BASH and KORN93 in this script
# to 'fake' BASH install.

PS4='$LINENO:=> ' # This prompt will be used when script tracing is turned on
typeset -x PRGNAME=${0##*/}
typeset -x PRGDIR=${0%/*}
export PATH=$PATH:/usr/bin:/usr/sbin:/sbin

[[ $PRGDIR == /* ]] || PRGDIR=$(pwd) # Acquire absolute path

# ------------------------------------------------------------------------------
#                                   FUNCTIONS
# ------------------------------------------------------------------------------

function _note {
	echo " ** $*"
}

function _line {
	typeset -i i=0
	while (( i < ${1:-80} )); do
		(( i+=1 ))
		echo "=\c"
	done
	echo
}

function _ok {
	echo "[  OK  ]"
}

function _nok {
	echo "[FAILED]"
}

function _wait {
	typeset prg=$1
	typeset log=$2
	typeset -i i=0
	typeset p pid
	typeset slptime=3

	# This is how we will be able to provide visual queues while xpinfo or
	# other disk array tools.  Some of them listed below are no longer used
	# in JNJ.
	case $prg in
		*xpinfo*) $prg -i | sort -k6,6 -k5,5 > $log & ;;
		*inq*) $prg -no_dots -f_emc > $log & ;;
		*) $prg > $log & ;;
	esac

	# The is put in the background and we will be checking for its
	# PID before we continue.  This will give us an oportunity for visual
	# queues to the user.
	pid=$!
	p=${pid%%${pid#?}} # Extract first character from the pid

	echo "Progress: \c"

	while ps -ef | grep -q "[${p}]${pid#?}"; do
		echo "*\c"
		sleep $slptime
		(( i+=1 ))
		(( i % 80 == 0 )) && echo
	done

	echo
	echo "Total wait time: $(($i * $slptime)) second(s)"
	echo "--------------\n"
}


function _use {
	echo "USAGE\n"
	echo "   $PRGNAME [-r][-d sarlog][-x xpinfolog][-s HH:MM][-e HH:MM]\n"
	echo "   r - this is an optional parameter that will cause xpinfo to be"
	echo "       regenerated.  If not passed, it will be using its local"
	echo "       cached version located at $log."
	echo "   d - you can optionally pass a new sar log file for processing."
	echo "   x - you can optionally provide fully qualified path to xpinfo log."
	echo "   s - specify the beginning of the report where HH is hours and MM is"
	echo "       minutes"
	echo "   e - specify the end of the report where HH is hours and MM is"
	echo "       minutes.\n"
	_line
	echo " THIS SCRIPT IS ALL ABOUT AVERAGES!!!  THESE ARE NOT ABSOLUTE VALUES."
	_line
}

function _count {
	typeset n a b c d e A B C D
	typeset sarg earg

	if [ -n "$stime" ]; then
		sarg="-s $stime"
	fi

	if [ -n "$etime" ]; then
		earg="-e $etime"
	fi

	# Running total for sar averages.
	#n=$(sar -d -f $sardir/$sarlog $sarg $earg
	sar -d -f $sardir/$sarlog $sarg $earg | \
	awk "\$1 ~ /^Average/ && \$2 ~ /^${1}/ { blk = blk + \$6
	avwait = avwait + \$7
	avserv = avserv + \$8
	rwr = rwr + \$5
	} END {
		if ( rwr > 0 ) { iops = (( blk / 2 ) / rwr ) } else { iops = 0 }
		print blk, avwait, avserv, iops, rwr
	}" |\
	while read a b c d e; do
		A=$a; B=$b; C=$c; D=$d
	done
	#a=${n%%,*}
	#c=${n##*,}
	#b=${n#*,}
	#b=${b%,*}

	# This is the last ditch check to ensure that the data provided by awk
	# is valid.  We are checking for either digits or floating numbers
	# (the ones that include periods in them.).  If one of the two is not
	# returned, a 0 is automatically assigned.
	[[ $A == +([[:digit:]])?(\.+([[:digit:]])) ]] || A=0
	[[ $B == +([[:digit:]])?(\.+([[:digit:]])) ]] || B=0
	[[ $C == +([[:digit:]])?(\.+([[:digit:]])) ]] || C=0
	[[ $D == +([[:digit:]])?(\.+([[:digit:]])) ]] || D=0

	echo "${A}|${B}|${C}|$D"
}

function _dskAvg {
	typeset tmp
	sar -d -f $sardir/$sarlog $sarg $earg |\
	while read -A tmp; do
		[[ ${tmp[0]} == Average ]] || continue

		# Acquire number of disks per controller and assign it to
		# associative array xpC for further processing down the road.
		(( xpC[${tmp[1]%t*}]++ ))
	done
}

function _tb {
	typeset i="$1"
	i=${i//[![:digit:]]/}
	case $i in
		+([[:digit:]]))
			# Odd or even?
			(( i % 2 )) && i=T || i=B
		;; # OK
		*) i='?';; # This is not a number
	esac

	echo $i
}

# ============================================================================
#                              GLOBAL VARs
# ============================================================================

typeset xp=/usr/local/CPR/bin/xpinfo
typeset user=$(whoami)
typeset log=/var/tmp/xpinfo-${PRGNAME%???}-${user}.log
typeset sardir=/var/adm/sa
typeset sarlog="sa$(date +'%d')"
typeset lhost=$(uname -n)
typeset osVer=$(uname -r)
typeset -A fch  # controller hash
typeset -A xp2sar
typeset -A xpC # Count XP controllers
typeset -i count=0
typeset vginfo=/var/tmp/${PRGNAME%???}-${user}-vginfo.log
typeset tmpc=/var/tmp/${PRGNAME%???}-count-${user}.txt
typeset -F2 tutil="0.00" total="0.00" blk="0.00"
typeset xpdata="/var/adm/disk_status"
typeset xpfile="$(ls $xpdata/xpinfo.sort.$(date +'%m%d%y')_* 2> /dev/null | tail -1)"
typeset output=/var/tmp/${PRGNAME%???}-${user}.log
typeset refresh=1                         # Flag to refresh xpinfo
typeset stime etime                       # bounderies for sarsarCheck.sh
typeset aw av # Average wait and average server
typeset tb # Top or bottom fabric


# Two lines below can be enabled to allow for function tracing in case of
# troubleshooting.
#typeset -ft _dskAvg
#typeset -ft _count

> $tmpc

# ------------------------------------------------------------------------------
#                                   MAIN BODY
# ------------------------------------------------------------------------------

_use

# Process command line arguments/parameters.
while getopts ":e:s:x:d:r" opt; do
	case $opt in
		d) dsarlog=$OPTARG ;;
		r) refresh=0 ;;
		x) xplog="$OPTARG" ;;
		s) stime="$OPTARG" ;;
		e) etime="$OPTARG" ;;
		:)
			_note "$PRGNAME: $OPTARG requires a value\n"
			_use
			exit 2
		;;
		\?) _note "$PRGNAME: unknown option: $OPTARG\n\n"
			_use
			exit 2
		;;
	esac
done

shift $(( OPTIND-1 ))

if (( refresh == 0 )); then # Refresh xplog using our routine
	_wait $xp $log
elif [ -n "$xplog" ]; then # Verify that we can use existing xplog generated by
					       # by this script.
	if [ -s "$xplog" ]; then
		log=$xplog # File exist and not blank
	else
		_note "[$xplog] does not exist!"
		exit 1
	fi
else # if xplog does not exist that was generated by this script or we did not
	 # pass any other xplog file, we are checking for it in a standard lcoation
	 # with today's date.
	if [ -f "$xpfile" ]; then
		log="$xpfile"
	else
		if [ -s "$log" ]; then
			: # OK
		else
			if [ -x "$xp" ]; then
				_wait $xp $log
			else
				_note "[$user]: you must be root to sarCheck.shrun xpinfo.\n"
				exit 1
			fi
		fi
	fi
fi

# If a sar file is not passed, a default one is used.  Note: sar MUST BE
# configured to log the data.  If it is not, this script will abort.
[ -n "$dsarlog" ] && sarlog=$dsarlog

if [ ! -f "$sardir/$sarlog" ]; then
	_note "[$sarlog] does not exist on $lhost.  Choose a valid SAR file:\n"
	_line 80
	ls -l $sardir; echo
	exit
fi

{
echo "Collecting SAR disks.  Please, wait..."
_dskAvg; echo

_note "Process started: $(date +'%Y-%m-%d @ %H:%M:%S')"

# The sort and while loop below are at the heart of this script.  The sort
# makes sure that our XP array and culdev are sorted and the while loop uses
# a hash table to pair up all controllers.
sort -k8,8 -k6,6 -k5,5 $log |\
while read -A xpdat; do
        case ${osVer} in
          B.11.31) [[ ${xpdat[0]} == /dev/rdisk/d* ]] || continue
                   con=${xpdat[0]##*/} ;;
	        *) [[ ${xpdat[0]} == /dev/rdsk/c* ]]  || continue # feed only valid disks
	           con=${xpdat[0]##*/}; con=${con%t*} # only controller number with target nor destination
                   ;;
        esac
	prt=${xpdat[4]}; culdev=${xpdat[5]}; xpser=${xpdat[7]}

	# This hash will consists of culdev record that will have nested following
	# information in it:
	# - Any existing instance of self
	# - Disk controller instance
	# - XP Port number
	# - XP Serial number
	xp2sar["${culdev}.${xpser}"]="${xp2sar[${culdev}.${xpser}]},${con}"
done

# We could just pipe created hashes directly into the follow up loop.
# However, you send it first to a file just in case we needed to look at what
# was created.
for i in ${!xp2sar[@]}; do
	echo "${xp2sar[$i]#,}"
done | sort -u > $tmpc

# XPinfo pairs have been collected
echo "\n\n"
_line 100
printf "%8s | %10s | %10s | %10s | %10s | %10s | %11s | %10s\n" "Cntrls" "blks/s" \
"await Avg" "aserv Avg" "IO/sec Avg" "Total %" "Port" "XP Array"
_line 100; echo

while IFS=, read -A rec; do
	typeset -A fch
	# Assign total fch value to each controller
	for i in ${rec[@]}; do
		fch[$i]="$(_count $i)"
	done

	# This first loop is required so we could provide relative % for the
	# block per second count for the controllers.
	total=0
	typeset -F2 awtotal=0 avtotal=0
	for i in ${!fch[@]}; do

		blk=${fch[$i]%%\|*}

		# Running total
		total=$(( $total + $blk ))
	done

	blk=0
	# Calculate values
	for i in ${!fch[@]}; do
		echo "${fch[$i]}" | \
		while IFS='|' read a b c d; do
			blk=$a
			#blk=${fch[$i]%%\|*} # blk/sec total per controller
			aw=$b
			#aw=${fch[$i]#*\|}; aw=${aw%\|*} # Acquire await number
			av=$c
			#av=${fch[$i]##*\|} # Acquire average server number
			iops=$d
		done

		#[ -n "$awtotal" ] || awtotal=0
		#[ -n "$avtotal" ] || avtotal=0

		awtotal=$(( $awtotal + $aw )) # Average wait per controller
		avtotal=$(( $avtotal + $av )) # Average service per controller
		aw=0 av=0

		# If block transfer is 0, there is no point of trying to figure output
		# percentages as it will be always 0.
		if (( $blk > 0 )); then
			tutil=$(( $blk * 100 / $total ))
		else
			tutil=0
		fi

		#echo "$i: ${xpC[$i]} - $avtotal"

		# If our collection of sar average disk does not find its equivalent
		# from xpinfo dump (for whatever reason), we need to protect ourselves
		# from a primitive check below complaining about a missing token.  Also,
		# if we do not find it, 0 is automatically assigned.
		(( ${#xpC[$i]} > 0 )) && awtotal=$(( $awtotal / ${xpC[$i]} )) || awtotal=0
		(( ${#xpC[$i]} > 0 )) && avtotal=$(( $avtotal / ${xpC[$i]} )) || avtotal=0
		#echo "Total $i: ${xpC[$i]}"

                case $osVer in
                  B.11.31) serial=$(awk "\$1 ~ /\/dev\/rdisk\/${i}/ { print \$5, \$NF }" $log | tail -1) ;;
		        *) serial=$(awk "\$1 ~ /\/dev\/rdsk\/${i}t/ { print \$5, \$NF }" $log | tail -1) ;;
                esac
		port=${serial% *}; tb=$(_tb $port)
		serial=${serial#* }
                case $osVer in
                  B.11.31) sar -d -f $sardir/$sarlog $sarg $earg | \
                            awk "\$1 ~ /^Average/ && \$2 ~ /^${i}/ { print }" | grep -q ${i} && \
                            printf "%8s | %10.0f | %10.2f | %10.2f | %10.1f | %10.2f | %11s | %10s\n" \
                            "$i" "$blk" "$awtotal" "$avtotal" "$iops" "$tutil" "$port ($tb)" "${serial:-NONE}"
                            ;;
		        *) printf "%8s | %10.0f | %10.2f | %10.2f | %10.1f | %10.2f | %11s | %10s\n" \
			    "$i" "$blk" "$awtotal" "$avtotal" "$iops" "$tutil" "$port ($tb)" "${serial:-NONE}"
                           ;;
                esac
		iops=0
	done
	unset fch
	#echo "\n"
done < $tmpc

echo
_line 88
_note "Output file can be found in [$output]"
[ -n "$xplog" ] && _note "[$xplog] used."
[ -n "$sarlog" ] && _note "[$sardir/$sarlog] used, day ${sarlog#??} of the month." || \
_note "Day ${sarlog#??} of the month used."
[ -n "$stime" ] && _note "Start time: $stime" || _note "Start time: 00:00"
[ -n "$etime" ] && _note "End time: $etime" || _note "End time: $(date +'%H:%M')"
_line 88
_note "Process ended: $(date +'%Y-%m-%d @ %H:%M:%S')"
} | tee $output

# ----------------------------------------------------------------------------
# $Log: sarCheck.sh,v $
# Revision 1.19  2013/10/01 13:41:51  gdhaese1
# added utils/lprequeue.sh and update utils/sarCheck.sh (both belonging to NCS_UTILS)
#
# Revision 1.18  2010/05/28 13:51:20  bmynars
# Added name of the author
#
# Revision 1.17  2010/05/22 18:50:01  bmynars
# Removed debug check
#
# Revision 1.16  2010/05/22 18:48:47  bmynars
# Added IO/sec column calculation.
#
# Revision 1.15  2010/05/22 16:41:28  bmynars
# Added IO/sec column
#
# Revision 1.14  2010/05/19 20:22:52  bmynars
# Added top or bottom to the fabrick and added time if defaults used.
#
# Revision 1.13  2010/05/08 14:58:45  bmynars
# Added comments for self documenting.
#
# Revision 1.12  2010/05/07 21:22:21  bmynars
# Fixed average calc
#
# Revision 1.11  2010/05/07 19:01:50  bmynars
# Changed calculation to be based on averages from sar
#
# Revision 1.10  2010/05/07 17:31:00  bmynars
# Updated calculations for avwait and avserver
#
# Revision 1.9  2010/05/07 14:42:15  bmynars
# Added average wait and average service times
#
# Revision 1.8  2010/05/06 21:23:45  bmynars
# Updated
#
# Revision 1.7  2010/05/06 21:00:59  bmynars
# Updated footer of the script
#
# Revision 1.6  2010/05/06 20:53:17  bmynars
# Updated.  Added time constraints if needed
#
# Revision 1.5  2010/05/06 18:45:26  bmynars
# Fixed minor errors
#
# Revision 1.4  2010/05/06 18:29:50  bmynars
# Productio ready prototype.
#
# Revision 1.3  2010/05/06 15:56:15  bmynars
# Another draft
#
# Revision 1.2  2010/05/06 00:37:40  bmynars
# Draft version
#
#
# $RCSfile: sarCheck.sh,v $
# $Source: /ncs/cvsroot/ncsbin/utils/sarCheck.sh,v $
# $State: Exp $
# ----------------------------------------------------------------------------
